/*
 * Symbolic names in file written by DEVICE raster
 */
#define RASTER_EOF -1			/* End Of File */
#define RASTER_SET_CTYPE -2		/* define colours */
#define RASTER_CTYPE -3			/* set a colour */
