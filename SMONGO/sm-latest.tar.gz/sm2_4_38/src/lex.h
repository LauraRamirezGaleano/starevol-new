#include "copyright.h"
#define ENDMARK 0
#define LEXINT (1 + 0177)
#define LEXFLOAT (2 + 0177)
#define LEXSTRING (3 + 0177)
#define LEXWORD (4 + 0177)
