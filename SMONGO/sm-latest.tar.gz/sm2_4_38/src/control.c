/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     WORD = 258,
     STRING = 259,
     _FLOAT = 260,
     INTEGER = 261,
     ABORT = 262,
     APROPOS = 263,
     BREAK = 264,
     CHDIR = 265,
     DEFINE = 266,
     DELETE = 267,
     DO = 268,
     EDIT = 269,
     ELSE = 270,
     FOREACH = 271,
     HELP = 272,
     HISTORY = 273,
     IF = 274,
     KEY = 275,
     LIST = 276,
     LOCAL = 277,
     MACRO = 278,
     OVERLOAD = 279,
     PRINT = 280,
     PROMPT = 281,
     QUIT = 282,
     READ = 283,
     RESTORE = 284,
     SAVE = 285,
     SET = 286,
     SNARK = 287,
     STANDARD = 288,
     TERMTYPE = 289,
     VERBOSE = 290,
     WHILE = 291,
     WRITE = 292,
     ANGLE = 293,
     ASPECT = 294,
     AXIS = 295,
     BOX = 296,
     CONNECT = 297,
     CONTOUR = 298,
     CTYPE = 299,
     CURSOR = 300,
     DATA = 301,
     DEVICE = 302,
     DOT = 303,
     DRAW = 304,
     DITHER = 305,
     ERASE = 306,
     ERRORBAR = 307,
     EXPAND = 308,
     FORMAT = 309,
     GRID = 310,
     HISTOGRAM = 311,
     IMAGE = 312,
     LABEL = 313,
     LEVELS = 314,
     LIMITS = 315,
     LINES = 316,
     LOCATION = 317,
     LTYPE = 318,
     LWEIGHT = 319,
     MINMAX = 320,
     NOTATION = 321,
     PAGE = 322,
     POINTS = 323,
     PTYPE = 324,
     PUTLABEL = 325,
     RANGE = 326,
     RELOCATE = 327,
     RETURN = 328,
     SHADE = 329,
     SORT = 330,
     SPLINE = 331,
     SURFACE = 332,
     TABLE = 333,
     TICKSIZE = 334,
     USER = 335,
     VIEWPOINT = 336,
     WHATIS = 337,
     WINDOW = 338,
     XLABEL = 339,
     YLABEL = 340,
     FLOAT = 341,
     META = 342,
     OLD = 343,
     ROW = 344,
     ABS = 345,
     ACOS = 346,
     ASIN = 347,
     ATAN = 348,
     ATAN2 = 349,
     CONCAT = 350,
     COS = 351,
     DIMEN = 352,
     EXP = 353,
     FFT = 354,
     GAMMA = 355,
     INT = 356,
     LG = 357,
     LN = 358,
     PI = 359,
     RANDOM = 360,
     SIN = 361,
     SQRT = 362,
     SUM = 363,
     TAN = 364,
     LEFT_SHIFT_SYMBOL = 365,
     RIGHT_SHIFT_SYMBOL = 366,
     POWER_SYMBOL = 367,
     ATOF = 368,
     INDEX = 369,
     LENGTH = 370,
     SPRINTF = 371,
     STRLEN = 372,
     SUBSTR = 373,
     OR = 374,
     AND = 375,
     UNARY = 376
   };
#endif
/* Tokens.  */
#define WORD 258
#define STRING 259
#define _FLOAT 260
#define INTEGER 261
#define ABORT 262
#define APROPOS 263
#define BREAK 264
#define CHDIR 265
#define DEFINE 266
#define DELETE 267
#define DO 268
#define EDIT 269
#define ELSE 270
#define FOREACH 271
#define HELP 272
#define HISTORY 273
#define IF 274
#define KEY 275
#define LIST 276
#define LOCAL 277
#define MACRO 278
#define OVERLOAD 279
#define PRINT 280
#define PROMPT 281
#define QUIT 282
#define READ 283
#define RESTORE 284
#define SAVE 285
#define SET 286
#define SNARK 287
#define STANDARD 288
#define TERMTYPE 289
#define VERBOSE 290
#define WHILE 291
#define WRITE 292
#define ANGLE 293
#define ASPECT 294
#define AXIS 295
#define BOX 296
#define CONNECT 297
#define CONTOUR 298
#define CTYPE 299
#define CURSOR 300
#define DATA 301
#define DEVICE 302
#define DOT 303
#define DRAW 304
#define DITHER 305
#define ERASE 306
#define ERRORBAR 307
#define EXPAND 308
#define FORMAT 309
#define GRID 310
#define HISTOGRAM 311
#define IMAGE 312
#define LABEL 313
#define LEVELS 314
#define LIMITS 315
#define LINES 316
#define LOCATION 317
#define LTYPE 318
#define LWEIGHT 319
#define MINMAX 320
#define NOTATION 321
#define PAGE 322
#define POINTS 323
#define PTYPE 324
#define PUTLABEL 325
#define RANGE 326
#define RELOCATE 327
#define RETURN 328
#define SHADE 329
#define SORT 330
#define SPLINE 331
#define SURFACE 332
#define TABLE 333
#define TICKSIZE 334
#define USER 335
#define VIEWPOINT 336
#define WHATIS 337
#define WINDOW 338
#define XLABEL 339
#define YLABEL 340
#define FLOAT 341
#define META 342
#define OLD 343
#define ROW 344
#define ABS 345
#define ACOS 346
#define ASIN 347
#define ATAN 348
#define ATAN2 349
#define CONCAT 350
#define COS 351
#define DIMEN 352
#define EXP 353
#define FFT 354
#define GAMMA 355
#define INT 356
#define LG 357
#define LN 358
#define PI 359
#define RANDOM 360
#define SIN 361
#define SQRT 362
#define SUM 363
#define TAN 364
#define LEFT_SHIFT_SYMBOL 365
#define RIGHT_SHIFT_SYMBOL 366
#define POWER_SYMBOL 367
#define ATOF 368
#define INDEX 369
#define LENGTH 370
#define SPRINTF 371
#define STRLEN 372
#define SUBSTR 373
#define OR 374
#define AND 375
#define UNARY 376




/* Copy the first part of user declarations.  */
/* #line 1 "control.y" */

#  include "copyright.h"
#  include "options.h"
#  include <math.h>
#  include <stdio.h>
#  include <ctype.h>
#  include <assert.h>
#ifndef INTEGER
#  include "control.h"
#endif
#  include "stack.h"
#  include "vectors.h"
#  include "yaccun.h"
#  include "devices.h"
#  include "sm_declare.h"
#  include "sm.h"
#  if defined(_IBMR2)
#     pragma alloca
#  endif

#define bcopy(S1,S2,N) memcpy(S2,S1,N)	/* use memcpy instead */
#define Pi 3.141592653589793238
/*
 * And some variables of my own:
 * The Auto Variables get moved into yyparse and made auto when control.y
 * is built (under unix, that is. Under vms, this won't happen).
 */
int yydebug;
   static char data_file[CHARMAX], /* name of current data file */
               table_fmt[CHARMAX]; /* format of current TABLE */
   extern char prompt[],	/* system prompt */
               user_name[];	/* name of user of programme */
   extern FILE *logfil;		/* where to log all terminal input */
   static float xy_range,	/* range for this axis (x or y) */
                x_range = 0,	/* Ranges for the x */
		y_range = 0;	/* and y axes */
   static int in_graphics = 0,	/* are graphics active? */
              graph_mode,	/* terminal is set to graph mode */
	      line_1,line_2,	/* line numbers to use in data_file */
              number_is_int,	/* last <number> was an int */
              subtable = -1;	/* which sub-table to read */
   static LONG intval;		/* value of last <number> if an int */
   extern int abort_plot,	/* abort current plot */
              in_quote,		/* am I in a quoted string? */
   	      sm_interrupt,	/* do you want to interrupt something ? */
   	      noexpand,		/* expand @#$ ? */
	      plength,		/* number of printing chars in prompt */
	      recurse_lvl,	/* how deeply nested are we? */
   	      sm_verbose;	/* produce lots of output */
/*
  This grammar generates 15 Shift/Reduce and 6 Reduce/Reduce conflicts.
  They are (approximately; state numbers may vary):
State 9 contains 2 shift/reduce conflicts.	DELETE . HISTORY/WORD ...
State 25 contains 1 shift/reduce conflicts.	RESTORE . word_or_space
State 26 contains 1 shift/reduce conflicts.	SAVE . word_or_space
State 69 contains 2 shift/reduce conflicts.	DELETE . '!'
State 146 contains 2 reduce/reduce conflicts.   '-' . expr
State 149 contains 1 shift/reduce conflict.	ANGLE expr . '!' ...
State 153 contains 1 shift/reduce conflict.	expr . '!' ...
State 162 contains 1 shift/reduce conflict.	EXPAND expr . '!' ...
State 171 contains 1 shift/reduce conflict.	LEVELS expr . '!' ...
State 207 contains 2 shift/reduce conflicts.	GRID . integer_or_space ...
State 404 contains 2 shift/reduce conflict.	expr . [ IF ... ]
State 418 contains 2 reduce/reduce conflicts.   WORD ( WORD . )
State 500 contains 1 shift/reduce conflict.	plot pexpr pexpr . [ IF ... ]
State 578 contains 1 shift/reduce conflict.	SURFACE INTEGER .
State 593 contains 2 reduce/reduce conflicts.   WORD ( arg_list , WORD . )
 */


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
/* #line 422 "y.tab.c" */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   3261

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  143
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  43
/* YYNRULES -- Number of rules.  */
#define YYNRULES  322
/* YYNRULES -- Number of states.  */
#define YYNSTATES  784

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   376

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     135,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   126,     2,     2,     2,   133,   124,     2,
     139,   140,   131,   129,   136,   130,     2,   132,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   120,     2,
     127,   125,   128,   119,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   141,     2,   142,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   137,   123,   138,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   121,   122,   134
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     4,     7,     9,    11,    13,    16,    18,
      21,    24,    27,    30,    34,    37,    41,    42,    48,    50,
      53,    57,    60,    64,    68,    73,    76,    79,    83,    86,
      93,   104,   105,   109,   111,   114,   121,   128,   132,   135,
     136,   139,   141,   143,   146,   155,   167,   171,   177,   182,
     185,   189,   198,   209,   220,   233,   241,   248,   259,   262,
     263,   264,   270,   272,   276,   277,   281,   287,   290,   295,
     299,   304,   308,   312,   316,   321,   327,   331,   335,   341,
     345,   351,   353,   357,   360,   365,   368,   370,   374,   378,
     383,   388,   392,   396,   401,   406,   409,   411,   414,   422,
     426,   436,   446,   456,   466,   476,   480,   484,   489,   490,
     497,   505,   515,   517,   520,   526,   529,   533,   538,   544,
     548,   551,   554,   557,   562,   568,   570,   576,   584,   592,
     602,   604,   608,   612,   615,   621,   625,   626,   628,   632,
     634,   638,   640,   644,   646,   648,   653,   658,   662,   665,
     671,   676,   681,   686,   691,   698,   703,   707,   712,   719,
     728,   733,   737,   741,   745,   749,   753,   757,   761,   765,
     769,   773,   778,   781,   786,   791,   796,   800,   805,   809,
     814,   819,   824,   831,   838,   845,   852,   859,   866,   873,
     880,   885,   890,   895,   900,   902,   904,   909,   914,   919,
     926,   931,   936,   941,   946,   955,   960,   964,   968,   972,
     976,   978,   981,   985,   987,   988,   992,   994,   996,  1007,
    1018,  1030,  1032,  1036,  1042,  1044,  1048,  1051,  1054,  1056,
    1060,  1066,  1068,  1074,  1078,  1080,  1083,  1086,  1090,  1092,
    1097,  1101,  1109,  1112,  1116,  1122,  1127,  1132,  1139,  1141,
    1143,  1145,  1148,  1150,  1151,  1153,  1156,  1157,  1160,  1163,
    1166,  1169,  1172,  1177,  1182,  1187,  1189,  1191,  1192,  1195,
    1197,  1201,  1203,  1205,  1207,  1209,  1210,  1211,  1213,  1215,
    1217,  1218,  1220,  1221,  1226,  1227,  1232,  1234,  1240,  1245,
    1246,  1249,  1252,  1255,  1259,  1261,  1263,  1266,  1270,  1272,
    1274,  1275,  1277,  1282,  1283,  1285,  1286,  1288,  1290,  1292,
    1299,  1301,  1304,  1308,  1310,  1312,  1315,  1317,  1321,  1322,
    1324,  1325,  1327
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     144,     0,    -1,    -1,   144,   145,    -1,   135,    -1,   126,
      -1,     7,    -1,    38,   154,    -1,     8,    -1,    39,   173,
      -1,    10,     3,    -1,    45,   135,    -1,    45,    28,    -1,
      45,     3,     3,    -1,    46,     3,    -1,    11,   182,   183,
      -1,    -1,    22,    11,   182,   146,   183,    -1,    12,    -1,
      12,   161,    -1,    12,   161,   161,    -1,    12,    18,    -1,
      12,    18,   126,    -1,    12,    18,   161,    -1,    12,    18,
     161,   161,    -1,    12,     3,    -1,    47,     6,    -1,    47,
      87,     3,    -1,    47,     3,    -1,    50,     3,     3,   165,
     165,   161,    -1,    13,   182,   125,   173,   136,   173,   167,
     137,   179,   138,    -1,    -1,    14,   147,   177,    -1,     1,
      -1,    53,   154,    -1,    99,   165,   168,   168,     3,     3,
      -1,    16,   182,   159,   137,   179,   138,    -1,    54,   166,
     166,    -1,    54,   135,    -1,    -1,   148,   160,    -1,    17,
      -1,    18,    -1,    18,   130,    -1,    19,   139,   173,   140,
     137,   179,   138,   135,    -1,    19,   139,   173,   140,   137,
     179,   138,    15,   137,   179,   138,    -1,    57,    45,   135,
      -1,    57,    45,     3,     3,     3,    -1,    57,    11,   182,
     166,    -1,    57,    12,    -1,    57,   162,     3,    -1,    57,
     162,     3,   141,   131,   120,   131,   142,    -1,    57,   162,
       3,   141,     6,   136,     6,   120,   131,   142,    -1,    57,
     162,     3,   141,   131,   120,     6,   136,     6,   142,    -1,
      57,   162,     3,   141,     6,   136,     6,   120,     6,   136,
       6,   142,    -1,    57,   162,     3,   165,   165,   165,   165,
      -1,    57,   139,   165,   136,   165,   140,    -1,    57,   139,
     165,   136,   165,   140,   165,   165,   165,   165,    -1,    59,
     154,    -1,    -1,    -1,    60,   149,   163,   150,   163,    -1,
      20,    -1,    61,     6,     6,    -1,    -1,    21,   151,   178,
      -1,    62,     6,     6,     6,     6,    -1,    64,   165,    -1,
      23,     3,   185,   156,    -1,    23,     3,    12,    -1,    23,
       3,   161,   161,    -1,    23,    14,     3,    -1,    23,    28,
       3,    -1,    23,    12,     3,    -1,    23,    37,     3,   135,
      -1,    23,    37,     3,   170,     3,    -1,    87,    28,     3,
      -1,    65,     3,     3,    -1,    66,   165,   165,   165,   165,
      -1,    24,   182,   161,    -1,    25,   170,   184,   181,   155,
      -1,    26,    -1,    69,     6,     6,    -1,    69,     3,    -1,
      69,   139,   154,   140,    -1,    69,   155,    -1,    27,    -1,
      71,   165,   165,    -1,    28,    14,     3,    -1,    28,    88,
       3,     3,    -1,    28,    89,     3,   166,    -1,    28,     3,
     166,    -1,    28,   158,   155,    -1,    28,   158,   180,   155,
      -1,    28,    78,   181,   155,    -1,    29,   184,    -1,    73,
      -1,    30,   184,    -1,    31,    97,   139,     3,   140,   125,
     166,    -1,    31,    17,     3,    -1,    31,    57,   139,   154,
     136,   154,   140,   125,   154,    -1,    31,    57,   141,   154,
     136,   154,   142,   125,   154,    -1,    31,    57,   141,   131,
     136,   154,   142,   125,   154,    -1,    31,    57,   141,   154,
     136,   131,   142,   125,   154,    -1,    31,    57,   141,   131,
     136,   131,   142,   125,   154,    -1,    31,   105,   165,    -1,
      31,     3,    22,    -1,    31,     3,   125,   176,    -1,    -1,
      22,    31,     3,   152,   125,   176,    -1,    31,     3,   141,
     154,   142,   125,   154,    -1,    31,     3,   141,   173,   136,
     173,   142,   125,   154,    -1,    32,    -1,    75,   155,    -1,
      76,     3,     3,     3,     3,    -1,    78,    12,    -1,    78,
     161,   135,    -1,    78,   162,   181,     3,    -1,    79,   165,
     165,   165,   165,    -1,    34,     3,   162,    -1,    80,     7,
      -1,    80,   161,    -1,    35,   165,    -1,    81,   165,   165,
     165,    -1,    36,   156,   137,   179,   138,    -1,     9,    -1,
      83,   161,   161,   161,   161,    -1,    83,   161,   161,   161,
     161,   120,   161,    -1,    83,   161,   161,   161,   120,   161,
     161,    -1,    83,   161,   161,   161,   120,   161,   161,   120,
     161,    -1,     3,    -1,    37,    18,     3,    -1,    37,    57,
       3,    -1,    37,    33,    -1,    37,    78,   170,     3,   155,
      -1,    37,   170,     3,    -1,    -1,     3,    -1,   153,   136,
       3,    -1,   154,    -1,   153,   136,   154,    -1,   155,    -1,
     154,    95,   154,    -1,     3,    -1,   180,    -1,     3,   139,
     153,   140,    -1,     3,   141,   154,   142,    -1,   139,   154,
     140,    -1,   130,   154,    -1,   154,   119,   154,   120,   154,
      -1,    90,   139,   154,   140,    -1,    91,   139,   154,   140,
      -1,    92,   139,   154,   140,    -1,    93,   139,   154,   140,
      -1,    94,   139,   154,   136,   154,   140,    -1,    96,   139,
     154,   140,    -1,    44,   139,   140,    -1,    44,   139,     4,
     140,    -1,    13,   139,   173,   136,   173,   140,    -1,    13,
     139,   173,   136,   173,   136,   173,   140,    -1,    98,   139,
     154,   140,    -1,   154,   129,   154,    -1,   154,   130,   154,
      -1,   154,   131,   154,    -1,   154,   132,   154,    -1,   154,
     112,   154,    -1,   154,   133,   154,    -1,   154,   124,   154,
      -1,   154,   123,   154,    -1,   154,   110,   154,    -1,   154,
     111,   154,    -1,   154,   125,   125,   154,    -1,   126,   154,
      -1,   154,   126,   125,   154,    -1,   154,   124,   124,   154,
      -1,   154,   123,   123,   154,    -1,   154,   128,   154,    -1,
     154,   128,   125,   154,    -1,   154,   127,   154,    -1,   154,
     127,   125,   154,    -1,   113,   139,   154,   140,    -1,    86,
     139,   154,   140,    -1,   100,   139,   154,   136,   154,   140,
      -1,    56,   139,   154,   120,   154,   140,    -1,    57,   139,
     154,   136,   154,   140,    -1,    57,   141,   154,   136,   154,
     142,    -1,    57,   141,   131,   136,   154,   142,    -1,    57,
     141,   154,   136,   131,   142,    -1,    57,   141,   131,   136,
     131,   142,    -1,   114,   139,   154,   136,   154,   140,    -1,
     101,   139,   154,   140,    -1,   115,   139,   154,   140,    -1,
     102,   139,   154,   140,    -1,   103,   139,   154,   140,    -1,
     165,    -1,   104,    -1,   105,   139,   173,   140,    -1,   106,
     139,   154,   140,    -1,    75,   139,   154,   140,    -1,   116,
     139,   154,   136,   154,   140,    -1,   107,   139,   154,   140,
      -1,     4,   139,   154,   140,    -1,     4,   127,     3,   128,
      -1,   117,   139,   154,   140,    -1,   118,   139,   154,   136,
     154,   136,   154,   140,    -1,   109,   139,   154,   140,    -1,
     127,   164,   128,    -1,   137,   164,   138,    -1,   127,   179,
     128,    -1,   137,   179,   138,    -1,    74,    -1,    74,    56,
      -1,    74,    56,    38,    -1,   126,    -1,    -1,   139,   164,
     140,    -1,   155,    -1,     3,    -1,    40,   165,   165,   165,
     165,     6,     6,     6,     6,     6,    -1,    40,   165,   165,
     168,   168,     6,     6,     6,     6,     6,    -1,    40,   165,
     165,   168,   168,     3,     6,     6,     6,     6,     6,    -1,
      41,    -1,    41,     6,     6,    -1,    41,     6,     6,     6,
       6,    -1,    43,    -1,    44,   125,   154,    -1,    44,     6,
      -1,    44,     3,    -1,    48,    -1,    49,   165,   165,    -1,
      49,   139,   165,   165,   140,    -1,    51,    -1,    52,   168,
     168,   154,     6,    -1,    55,   162,   162,    -1,    58,    -1,
      63,   165,    -1,    63,    51,    -1,    63,    53,   165,    -1,
      67,    -1,    56,    38,   168,   168,    -1,   169,   168,   168,
      -1,   169,   168,   168,    19,   139,   154,   140,    -1,    70,
       6,    -1,    72,   165,   165,    -1,    72,   139,   165,   165,
     140,    -1,   157,   165,   168,   168,    -1,    77,   161,   165,
     165,    -1,    77,   161,   165,   165,     3,     3,    -1,    84,
      -1,    85,    -1,     6,    -1,   130,     6,    -1,   161,    -1,
      -1,   168,    -1,   165,   165,    -1,    -1,   164,   166,    -1,
     164,   180,    -1,   164,   135,    -1,   172,     5,    -1,   172,
       6,    -1,    97,   139,   154,   140,    -1,   108,   139,   154,
     140,    -1,    82,   139,   177,   140,    -1,   165,    -1,     3,
      -1,    -1,   136,   173,    -1,     3,    -1,   139,   154,   140,
      -1,    42,    -1,    56,    -1,    68,    -1,   129,    -1,    -1,
      -1,   156,    -1,   130,    -1,   129,    -1,    -1,   154,    -1,
      -1,   173,   122,   174,   173,    -1,    -1,   173,   121,   175,
     173,    -1,   154,    -1,   154,    19,   139,   154,   140,    -1,
     173,   136,   173,   167,    -1,    -1,    11,   123,    -1,    11,
      57,    -1,    11,   135,    -1,    11,     3,     3,    -1,    47,
      -1,    14,    -1,    23,   135,    -1,    23,     3,     3,    -1,
      78,    -1,    31,    -1,    -1,     4,    -1,    17,   139,     3,
     140,    -1,    -1,   180,    -1,    -1,    12,    -1,    22,    -1,
     156,    -1,   156,   141,   161,   136,   161,   142,    -1,    57,
      -1,    28,     6,    -1,    28,     6,     6,    -1,   166,    -1,
     120,    -1,   119,   171,    -1,   123,    -1,   139,   154,   140,
      -1,    -1,     3,    -1,    -1,     6,    -1,     3,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   130,   130,   137,   140,   152,   168,   179,   185,   191,
     193,   218,   237,   242,   251,   271,   273,   273,   275,   280,
     282,   284,   286,   288,   290,   292,   294,   313,   321,   336,
     342,   354,   354,   356,   377,   383,   416,   433,   435,   440,
     440,   446,   477,   479,   481,   491,   514,   520,   526,   528,
     530,   532,   534,   536,   538,   540,   542,   545,   547,   553,
     553,   553,   555,   557,   564,   564,   565,   567,   575,   584,
     586,   588,   590,   601,   603,   618,   620,   622,   632,   634,
     636,   678,   691,   698,   722,   733,   745,   751,   756,   758,
     760,   772,   785,   961,  1034,  1133,  1135,  1137,  1139,  1162,
    1168,  1176,  1178,  1180,  1182,  1184,  1186,  1188,  1190,  1190,
    1192,  1202,  1229,  1248,  1379,  1381,  1383,  1390,  1408,  1410,
    1412,  1449,  1456,  1466,  1468,  1488,  1490,  1492,  1494,  1496,
    1498,  1530,  1532,  1534,  1539,  1582,  1609,  1614,  1623,  1638,
    1647,  1664,  1709,  1711,  1737,  1745,  1816,  1865,  1867,  1874,
    1876,  1878,  1880,  1882,  1884,  1886,  1888,  1893,  1898,  1907,
    1916,  1918,  1920,  1922,  1924,  1926,  1928,  1930,  1932,  1934,
    1936,  1938,  1940,  1947,  1949,  1951,  1953,  1955,  1957,  1959,
    1961,  1963,  1965,  1967,  1969,  1971,  1973,  1975,  1977,  1979,
    1981,  1983,  1985,  1987,  1989,  1997,  1999,  2001,  2003,  2056,
    2058,  2060,  2062,  2092,  2094,  2096,  2100,  2102,  2106,  2108,
    2112,  2114,  2116,  2120,  2123,  2126,  2128,  2130,  2174,  2177,
    2179,  2198,  2200,  2202,  2204,  2206,  2211,  2213,  2215,  2217,
    2219,  2221,  2229,  2270,  2272,  2280,  2282,  2284,  2292,  2294,
    2310,  2335,  2371,  2379,  2381,  2383,  2395,  2397,  2421,  2429,
    2439,  2441,  2445,  2448,  2451,  2511,  2525,  2526,  2539,  2552,
    2567,  2572,  2577,  2583,  2606,  2648,  2650,  2655,  2656,  2660,
    2672,  2680,  2682,  2684,  2688,  2691,  2695,  2701,  2705,  2707,
    2710,  2713,  2734,  2734,  2763,  2763,  2793,  2795,  2841,  2853,
    2881,  2886,  2891,  2902,  2907,  2917,  2919,  2924,  2926,  2944,
    2949,  3009,  3035,  3048,  3049,  3054,  3082,  3084,  3086,  3093,
    3121,  3127,  3137,  3147,  3149,  3163,  3198,  3210,  3237,  3238,
    3243,  3244,  3246
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "WORD", "STRING", "_FLOAT", "INTEGER",
  "ABORT", "APROPOS", "BREAK", "CHDIR", "DEFINE", "DELETE", "DO", "EDIT",
  "ELSE", "FOREACH", "HELP", "HISTORY", "IF", "KEY", "LIST", "LOCAL",
  "MACRO", "OVERLOAD", "PRINT", "PROMPT", "QUIT", "READ", "RESTORE",
  "SAVE", "SET", "SNARK", "STANDARD", "TERMTYPE", "VERBOSE", "WHILE",
  "WRITE", "ANGLE", "ASPECT", "AXIS", "BOX", "CONNECT", "CONTOUR", "CTYPE",
  "CURSOR", "DATA", "DEVICE", "DOT", "DRAW", "DITHER", "ERASE", "ERRORBAR",
  "EXPAND", "FORMAT", "GRID", "HISTOGRAM", "IMAGE", "LABEL", "LEVELS",
  "LIMITS", "LINES", "LOCATION", "LTYPE", "LWEIGHT", "MINMAX", "NOTATION",
  "PAGE", "POINTS", "PTYPE", "PUTLABEL", "RANGE", "RELOCATE", "RETURN",
  "SHADE", "SORT", "SPLINE", "SURFACE", "TABLE", "TICKSIZE", "USER",
  "VIEWPOINT", "WHATIS", "WINDOW", "XLABEL", "YLABEL", "FLOAT", "META",
  "OLD", "ROW", "ABS", "ACOS", "ASIN", "ATAN", "ATAN2", "CONCAT", "COS",
  "DIMEN", "EXP", "FFT", "GAMMA", "INT", "LG", "LN", "PI", "RANDOM", "SIN",
  "SQRT", "SUM", "TAN", "LEFT_SHIFT_SYMBOL", "RIGHT_SHIFT_SYMBOL",
  "POWER_SYMBOL", "ATOF", "INDEX", "LENGTH", "SPRINTF", "STRLEN", "SUBSTR",
  "'?'", "':'", "OR", "AND", "'|'", "'&'", "'='", "'!'", "'<'", "'>'",
  "'+'", "'-'", "'*'", "'/'", "'%'", "UNARY", "'\\n'", "','", "'{'", "'}'",
  "'('", "')'", "'['", "']'", "$accept", "line", "command", "@1", "@2",
  "@3", "@4", "@5", "@6", "@7", "arg_list", "expr", "delim_list",
  "delim_str_list", "fill", "exclamation_or_space", "for_list", "graphic",
  "integer", "integer_or_space", "limit_pair", "list", "number",
  "number_or_word", "optional", "pexpr", "plot", "plus_or_space", "prompt",
  "sign", "s_expr", "@8", "@9", "set_expr", "something",
  "something_to_list", "str_list", "string", "string_or_space", "variable",
  "variable_value", "word_or_space", "macro_narg", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,    63,
      58,   374,   375,   124,    38,    61,    33,    60,    62,    43,
      45,    42,    47,    37,   376,    10,    44,   123,   125,    40,
      41,    91,    93
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   143,   144,   144,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   146,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   147,   145,   145,   145,   145,   145,   145,   145,   148,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   149,
     150,   145,   145,   145,   151,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   152,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   145,   145,   145,   153,   153,   153,   153,
     153,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   155,   155,   156,   156,
     157,   157,   157,   158,   158,   159,   159,   159,   160,   160,
     160,   160,   160,   160,   160,   160,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   160,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   160,   160,   160,   160,   160,
     161,   161,   162,   162,   163,   163,   164,   164,   164,   164,
     165,   165,   165,   165,   165,   166,   166,   167,   167,   168,
     168,   169,   169,   169,   170,   170,   171,   171,   172,   172,
     172,   173,   174,   173,   175,   173,   176,   176,   176,   177,
     178,   178,   178,   178,   178,   178,   178,   178,   178,   178,
     179,   180,   180,   181,   181,   182,   183,   183,   183,   183,
     183,   183,   183,   183,   183,   183,   183,   183,   184,   184,
     185,   185,   185
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     1,     1,     1,     2,     1,     2,
       2,     2,     2,     3,     2,     3,     0,     5,     1,     2,
       3,     2,     3,     3,     4,     2,     2,     3,     2,     6,
      10,     0,     3,     1,     2,     6,     6,     3,     2,     0,
       2,     1,     1,     2,     8,    11,     3,     5,     4,     2,
       3,     8,    10,    10,    12,     7,     6,    10,     2,     0,
       0,     5,     1,     3,     0,     3,     5,     2,     4,     3,
       4,     3,     3,     3,     4,     5,     3,     3,     5,     3,
       5,     1,     3,     2,     4,     2,     1,     3,     3,     4,
       4,     3,     3,     4,     4,     2,     1,     2,     7,     3,
       9,     9,     9,     9,     9,     3,     3,     4,     0,     6,
       7,     9,     1,     2,     5,     2,     3,     4,     5,     3,
       2,     2,     2,     4,     5,     1,     5,     7,     7,     9,
       1,     3,     3,     2,     5,     3,     0,     1,     3,     1,
       3,     1,     3,     1,     1,     4,     4,     3,     2,     5,
       4,     4,     4,     4,     6,     4,     3,     4,     6,     8,
       4,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     4,     2,     4,     4,     4,     3,     4,     3,     4,
       4,     4,     6,     6,     6,     6,     6,     6,     6,     6,
       4,     4,     4,     4,     1,     1,     4,     4,     4,     6,
       4,     4,     4,     4,     8,     4,     3,     3,     3,     3,
       1,     2,     3,     1,     0,     3,     1,     1,    10,    10,
      11,     1,     3,     5,     1,     3,     2,     2,     1,     3,
       5,     1,     5,     3,     1,     2,     2,     3,     1,     4,
       3,     7,     2,     3,     5,     4,     4,     6,     1,     1,
       1,     2,     1,     0,     1,     2,     0,     2,     2,     2,
       2,     2,     4,     4,     4,     1,     1,     0,     2,     1,
       3,     1,     1,     1,     1,     0,     0,     1,     1,     1,
       0,     1,     0,     4,     0,     4,     1,     5,     4,     0,
       2,     2,     2,     3,     1,     1,     2,     3,     1,     1,
       0,     1,     4,     0,     1,     0,     1,     1,     1,     6,
       1,     2,     3,     1,     1,     2,     1,     3,     0,     1,
       0,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       2,     0,     1,    33,   130,     6,     8,   125,     0,   305,
      18,   305,    31,   305,    41,    42,     0,    62,    64,     0,
       0,   305,   275,    81,    86,   214,   318,   318,     0,   112,
       0,   280,     0,   275,   280,   280,     0,     0,     0,     0,
     280,   280,   253,   280,    59,     0,     0,   280,     0,   280,
       0,   280,    96,     0,     0,   253,   280,     0,   280,     0,
       0,   280,     5,     4,     3,     0,    10,   280,    25,   250,
      21,     0,    19,     0,   289,     0,    43,   280,     0,   305,
       0,   320,     0,     0,     0,     0,     0,   274,   318,   280,
       0,   303,     0,     0,   213,     0,   319,    95,    97,     0,
       0,     0,     0,   280,   253,     0,     0,     0,   279,   278,
     122,     0,   300,   300,     0,     0,   133,     0,   275,     0,
     143,   301,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     195,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   280,   256,   278,   256,   280,     7,   141,   194,   144,
     281,     9,     0,    12,    11,    14,    28,    26,     0,     0,
      34,   266,    38,   265,   280,   305,    49,     0,   280,   252,
       0,    58,   280,     0,     0,    67,     0,   280,    83,     0,
     280,    85,   280,   113,     0,   115,   252,   303,   280,   120,
     121,   280,     0,     0,     0,   280,   221,   271,   224,     0,
     228,   280,   231,     0,   253,   272,   234,   280,   238,   273,
       0,   280,   210,     0,   248,   249,   280,    40,     0,   306,
     307,     0,   310,   276,   314,   316,   280,   308,   313,    15,
      22,    23,   251,    20,   280,    32,   217,   256,   216,     0,
       0,     0,   295,     0,   299,   294,   298,    65,    16,   108,
     322,   250,    69,     0,     0,    73,    71,    72,   275,    79,
     303,    91,    88,   301,   304,     0,     0,   280,    92,     0,
     106,   280,   280,    99,   280,   280,     0,   105,   119,   289,
     280,   280,   260,   261,     0,     0,   300,   131,   132,     0,
     135,   136,   280,     0,   280,   280,     0,     0,   280,   280,
     280,   280,   280,   280,   280,   280,   280,   280,   280,   280,
     280,   280,   280,   280,   280,   280,   280,   280,   280,   280,
     280,   280,   280,   280,   172,   280,   148,   280,     0,   280,
     280,   280,   280,   280,   280,   280,     0,     0,   280,   280,
     280,   280,   280,   280,   280,   284,   282,    13,    27,   280,
      37,   280,     0,    46,     0,    50,   269,   280,    60,   280,
     254,    63,     0,    77,   280,    82,     0,    87,     0,   116,
       0,   280,   280,     0,    76,     0,   280,     0,   227,   226,
     280,   280,   280,     0,   253,     0,   236,   280,   235,   242,
     280,   280,   211,   280,     0,     0,   311,   277,   315,     0,
       0,    24,     0,   280,   300,     0,     0,   291,   290,   292,
       0,   296,   280,     0,    70,    68,    74,     0,     0,    94,
      89,    90,    93,   286,     0,   107,   281,     0,     0,     0,
       0,     0,     0,     0,     0,   208,   209,     0,     0,   143,
       0,   139,     0,     0,     0,     0,     0,     0,   156,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   206,   259,   257,   258,
     207,   147,   142,   169,   170,   165,     0,   280,   168,   280,
     167,   280,   280,   280,   178,   280,   176,   161,   162,   163,
     164,   166,   280,   280,   280,    48,     0,   280,     0,   280,
       0,   280,   255,     0,   280,    84,     0,   117,   280,   123,
       0,     0,   280,   222,   225,   280,   229,   280,   233,     0,
     237,   280,   243,   212,   280,     0,   240,   312,   317,     0,
     280,   215,     0,   300,   293,   297,    17,   280,    75,    80,
       0,   280,     0,   280,   280,   280,   280,     0,   264,   262,
     263,   124,   134,   280,   145,   146,   202,   201,   280,   302,
     157,   280,   280,   280,   280,   198,   181,   150,   151,   152,
     153,   280,   155,   160,   280,   190,   192,   193,   196,   197,
     200,   205,   180,   280,   191,   280,   203,   280,   280,   175,
     174,   171,   173,   179,   177,   285,   283,     0,    47,     0,
       0,     0,   280,   270,    61,    66,    78,   114,   118,     0,
     126,     0,   280,     0,     0,     0,     0,   239,     0,   246,
     245,     0,     0,   267,    36,     0,   109,   280,   267,   280,
       0,     0,     0,     0,     0,     0,   280,   143,   140,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   149,    29,    56,     0,     0,   280,     0,     0,    35,
       0,     0,   223,   230,   232,   244,     0,   280,     0,   280,
       0,     0,     0,   288,   110,     0,     0,     0,     0,     0,
       0,    98,   280,   158,   183,   184,   188,   186,   187,   185,
     154,   182,   189,   199,   280,   280,     0,     0,     0,    55,
     128,   127,     0,     0,     0,   247,     0,   309,   268,   300,
       0,    44,   287,   280,   280,   280,   280,   280,   280,     0,
       0,   280,     0,     0,    51,     0,     0,     0,     0,   241,
       0,   300,   111,   100,   104,   102,   103,   101,   159,   204,
     280,     0,     0,     0,   129,     0,     0,     0,    30,     0,
      57,     0,    52,    53,     0,     0,     0,    45,     0,   218,
       0,   219,    54,   220
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    64,   422,    74,    65,   182,   521,    78,   423,
     450,   160,   157,   237,   226,    95,   249,   227,   179,   180,
     368,   335,   158,   488,   690,   370,   228,    88,   408,   111,
     434,   513,   512,   435,   245,   257,   294,   159,   275,    67,
     239,    97,   264
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -161
static const yytype_int16 yypact[] =
{
    -161,  1641,  -161,  -161,  -161,  -161,  -161,  -161,    26,  -161,
      64,  -161,  -161,  -161,  -161,   -87,   -12,  -161,  -161,    55,
     491,  -161,     6,  -161,  -161,   126,   122,   122,   142,  -161,
     136,   275,   -46,   336,  1442,  1442,    30,   143,    62,   161,
    1442,    76,    63,  1442,  -161,   168,   175,   275,   224,   275,
      51,   275,  -161,   -18,   225,    77,   275,    78,   275,    66,
     228,   275,  -161,  -161,  -161,  1913,  -161,   404,  -161,  -161,
     106,   260,    66,   147,  -161,    50,  -161,  1442,   485,  -161,
     273,    91,   277,   294,   304,   305,    66,  -161,   122,   262,
     307,   216,   317,   329,  -161,    23,  -161,  -161,  -161,   109,
     331,    84,   202,   275,    66,   208,   212,   213,  -161,  -161,
    -161,    46,  -161,  -161,   221,   359,  -161,   365,     6,   373,
     101,   -32,   239,   245,   255,   269,   132,   278,   288,   292,
     297,   298,   299,   300,   301,   318,   321,   325,   330,   334,
    -161,   338,   340,   341,   343,   346,   348,   350,   361,   372,
     374,  1442,  -161,  1442,  -161,  1442,  3054,  -161,  -161,  -161,
    3054,   127,   385,  -161,  -161,  -161,  -161,  -161,   392,   425,
    3054,  -161,  -161,  -161,   262,  -161,  -161,    -1,   275,  -161,
     440,  3054,     8,   498,   508,  -161,   514,   275,  -161,   516,
    1442,  -161,   275,  -161,   523,  -161,   394,   216,   275,  -161,
    -161,   275,    66,   532,     3,   275,   536,  -161,  -161,    58,
    -161,   443,  -161,     3,    66,   515,  -161,   439,  -161,  -161,
     546,   462,   502,    66,  -161,  -161,   275,  -161,     3,  -161,
    -161,   554,  -161,   -46,  -161,  -161,  1442,   420,  -161,  -161,
    -161,    66,  -161,  -161,  1442,  -161,  -161,  -161,  -161,   428,
      -7,    47,  -161,    33,  -161,  -161,  -161,  -161,  -161,  -161,
    -161,   -14,  -161,    66,   -46,  -161,  -161,  -161,   108,  -161,
     216,  -161,  -161,  -161,  -161,   -18,   568,   262,  -161,   -18,
    -161,  1442,  1442,  -161,  1442,   741,   576,  -161,  -161,  -161,
    1442,  1442,  -161,  -161,   465,   452,  -161,  -161,  -161,   591,
    -161,   675,  1442,   592,  1442,  1442,   597,    13,  1442,  1442,
     807,  1442,  1442,  1442,  1442,  1442,  1442,  1442,  1442,  1442,
    1442,  1442,  1442,  1442,  1442,  1442,  1442,  1442,  1442,  1442,
    1442,  1442,  1442,  1442,   493,   480,   493,   333,  1882,  1442,
    1442,  1442,  1442,  1442,   873,   980,   486,   487,  1046,  1112,
    1442,  1442,  1442,  1442,  1442,  -161,  -161,  -161,  -161,   275,
    -161,   262,   610,  -161,   478,    14,  -161,  1442,  -161,   275,
    -161,  -161,   611,  -161,   275,  -161,  1907,  -161,   613,  -161,
     615,   275,   275,    66,  -161,     3,   275,   618,  -161,  -161,
    1442,   275,   275,     3,    66,     3,  -161,   275,  -161,  -161,
     275,   275,   583,   275,     3,     3,   619,  -161,  -161,  1932,
      66,  -161,   124,    89,  -161,   489,   624,  -161,  -161,  -161,
     625,  -161,   404,   504,  -161,  -161,  -161,   628,   -18,  -161,
    -161,  -161,  -161,   323,   209,  -161,  1693,   276,  2732,   497,
    2759,   499,   500,  1957,  1982,  -161,  -161,   503,   -18,   409,
     -92,  3054,  1718,   509,  2007,   345,   505,   517,  -161,  3002,
    2786,   506,  2813,  2032,  2057,  2082,  2107,  2132,  2157,  2840,
    2182,  2207,  2867,  2232,  2257,  2282,    -4,  2307,  2332,  2357,
    2382,  2894,  2407,  2921,  2432,  2948,  -161,  -161,  -161,  -161,
    -161,  -161,   291,   454,   454,  -161,  3028,  1442,  3104,  1442,
    3128,  1442,  1442,  1442,   541,  1442,   541,   249,   249,   493,
     493,   493,  1442,  1442,   275,  -161,   635,   275,    36,   275,
    2457,     8,  -161,   637,   275,  -161,   641,  -161,   275,  -161,
      92,   646,     8,   648,  3079,   275,  -161,  1442,  -161,     3,
    -161,   275,  -161,  -161,   275,     3,   636,  -161,  -161,   522,
    1442,  -161,   521,  -161,  -161,  -161,  -161,  1442,  -161,  -161,
     525,  1442,   537,  1442,  1442,  1178,  1244,   540,  -161,  -161,
    -161,  -161,  -161,  1508,  -161,  -161,  -161,  -161,  1442,  -161,
    -161,  1442,  1442,  1310,  1376,  -161,  -161,  -161,  -161,  -161,
    -161,  1442,  -161,  -161,  1442,  -161,  -161,  -161,  -161,  -161,
    -161,  -161,  -161,  1442,  -161,  1442,  -161,  1442,  1442,  3104,
    3128,   541,   541,   541,   541,   539,  -161,    66,  -161,   526,
     533,   555,   275,  -161,  -161,  -161,  -161,  -161,  -161,    66,
     556,   674,   275,     3,   676,   543,  1668,  -161,   544,   682,
    -161,   547,    66,   453,  -161,   552,  -161,  1442,   453,  1442,
     -21,  2482,   549,  1743,   551,  1768,   262,   463,  3054,   289,
    2507,  2532,   553,  1793,   557,  1818,  2557,  2582,  2607,  2632,
    2975,  3054,  -161,   256,   688,    49,   275,    66,    66,  -161,
     690,   151,  -161,  -161,  -161,  -161,   694,  1442,   558,  1442,
     561,    16,  2657,  -161,  3079,   577,   578,   579,   580,   587,
     588,  -161,  1442,  -161,  -161,  -161,  -161,  -161,  -161,  -161,
    -161,  -161,  -161,  -161,  1442,   275,   581,   582,   572,  -161,
     596,  -161,   711,   714,   715,  -161,  2682,  -161,   127,  -161,
     585,  -161,  -161,  1442,  1442,  1442,  1442,  1442,  1442,    95,
    2707,   275,    67,   717,  -161,    66,   718,   719,   720,  -161,
     589,  -161,  3079,  3079,  3079,  3079,  3079,  3079,  -161,  -161,
     275,   593,   586,   594,  -161,   724,   727,   731,  -161,   600,
    -161,   733,  -161,  -161,   734,   735,   736,  -161,   601,  -161,
     740,  -161,  -161,  -161
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -161,  -161,  -161,  -161,  -161,  -161,  -161,  -161,  -161,  -161,
    -161,   -27,   -49,   -23,  -161,  -161,  -161,  -161,   -10,   -45,
     226,  -115,   -26,   -33,   100,  -126,  -161,   -30,  -161,  -161,
      85,  -161,  -161,   192,   464,  -161,   -95,   -67,  -160,     1,
     337,    11,  -161
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -322
static const yytype_int16 yytable[] =
{
      72,   191,   362,   119,   193,   110,   366,   156,   174,   114,
     197,   366,    73,   170,    75,   173,   181,   457,   295,  -280,
    -280,   185,    86,   187,   274,   192,   248,   273,   279,    66,
     198,   730,   201,   162,   238,   204,   420,   380,    98,   337,
     123,   173,   620,    76,   573,   196,   278,   200,   574,   202,
     416,   292,   293,   246,   188,   717,   271,   189,   163,   288,
     241,   388,   243,   173,   389,   166,    79,    68,   167,    69,
      69,   263,    69,   761,   175,   176,   269,   287,   385,   171,
     258,   112,    70,    69,    69,   199,    80,   393,   299,   195,
     105,   113,   171,   273,   260,   303,   105,   261,    69,   270,
     355,   356,   405,   262,   417,   106,   123,   304,   177,   152,
     428,   106,    69,  -321,   355,   356,   107,   355,   356,   154,
     161,   695,   107,  -321,   334,    96,   336,    77,   338,    89,
     274,   280,   413,   415,   363,    87,   598,   108,   109,   104,
      90,   360,   367,   108,   109,    99,   165,   367,   173,   168,
     152,   731,   364,   458,   723,   518,   369,   724,   105,   100,
     154,   374,   250,   376,   169,   164,   377,   621,   421,   394,
     418,   105,   381,   106,   183,   382,   361,   152,   152,   386,
     718,   184,   419,   390,   107,   392,   106,   154,   154,   247,
     190,   398,   383,    71,    71,   401,    71,   107,   762,   101,
     404,   447,   178,   274,    91,   108,   109,    71,    71,   409,
     407,   172,   629,   403,    92,    93,   355,   356,   108,   109,
     273,    71,    71,   284,   487,   285,   429,   186,   194,   551,
     432,   411,   240,   123,   281,   758,    71,    87,   427,   102,
     301,   425,   302,   426,   431,   355,   356,   103,   355,   356,
     282,   173,    94,   424,   433,   436,   203,   438,   440,   531,
     550,  -280,  -280,   443,   444,   171,   242,   537,   489,   539,
     489,   309,   244,   310,   451,   452,   259,   454,   545,   546,
     265,   459,   460,   462,   463,   464,   465,   466,   467,   468,
     469,   470,   471,   472,   473,   474,   475,   266,   477,   478,
     479,   480,   481,   482,   483,   484,   485,   267,   268,   173,
     272,   173,   492,   493,   494,   495,   496,   498,   500,   552,
     276,   504,   506,   507,   508,   509,   510,   511,   515,   412,
     355,   356,   277,   514,   283,   173,   171,   273,   105,   519,
     520,   286,   560,   522,   105,   561,   489,   289,   524,   538,
     123,   290,   291,   106,   115,   528,   529,   105,   296,   106,
     532,   342,   297,   534,   107,   535,   536,   437,   298,   116,
     107,   540,   106,   530,   541,   542,   300,   544,   305,   559,
     352,   353,   354,   107,   306,   108,   109,   173,   357,   238,
     455,   108,   109,   117,   307,   358,   173,   355,   356,   572,
     549,   340,   341,   342,   108,   109,   633,   171,   308,   476,
     355,   356,   563,   637,   118,   105,   229,   311,   339,   640,
     350,   351,   352,   353,   354,   702,   230,   312,   359,   703,
     106,   313,   231,   340,   341,   342,   314,   315,   316,   317,
     318,   107,   343,   365,  -281,  -281,   344,   345,   346,   347,
     348,   349,   350,   351,   352,   353,   354,   319,   645,  -281,
     320,   232,   108,   109,   321,    87,   355,   356,   487,   322,
     609,   490,   610,   323,   611,   612,   613,   324,   614,   325,
     326,   578,   327,   171,   273,   328,   105,   329,   617,   330,
     396,   619,   397,   622,    81,   369,   251,   123,   626,   252,
     331,   106,   628,    82,   371,    83,   632,   681,   253,   635,
     636,   332,   107,   333,   372,   638,   254,   373,   639,    84,
     630,   105,   375,   233,   234,   105,   378,   235,    85,   379,
     433,   112,   255,   108,   109,   384,   106,   651,   653,   655,
     106,   113,   387,   236,   105,  -137,   658,   107,   301,  -137,
     302,   107,   399,   395,   660,   661,   663,   665,   402,   106,
     406,   410,   105,   256,   666,   414,   342,   667,   108,   109,
     107,   430,   108,   109,   355,   356,   668,   106,   669,   441,
     670,   671,   391,   350,   351,   352,   353,   354,   107,   689,
     446,   108,   109,   445,   448,   453,   676,   615,   616,  -138,
     456,   400,   301,  -138,   302,   342,   680,   672,   486,   108,
     109,   501,   502,   516,   517,   487,   526,   523,   527,   677,
     692,   543,   694,   701,   533,   547,   553,   554,   555,   557,
     173,   558,   688,   565,   750,   643,   339,   576,   618,   567,
     568,   571,   583,   625,   627,   579,   648,   715,   650,   631,
     719,   340,   341,   342,   634,   641,   769,   580,   642,   644,
     726,   356,   649,   659,   647,   656,   673,   720,   721,   674,
     350,   351,   352,   353,   354,   675,   678,   679,   449,   121,
    -280,  -280,   682,   683,   685,   686,   687,   740,   122,   741,
     691,   697,   123,   699,   716,   706,   722,   725,   729,   708,
     727,   742,   733,   734,   735,   736,   752,   753,   754,   755,
     756,   757,   737,   738,   744,   760,   745,   746,   743,   124,
     747,   748,   751,   763,   765,   766,   767,   768,   772,   771,
     774,   125,   126,   775,   770,   764,   773,   776,   777,   778,
     779,   780,   781,   782,   120,   121,   783,   624,   693,   646,
     127,     0,     0,   442,   122,     0,     0,   105,   123,   556,
       0,   128,     0,     0,     0,   129,   130,   131,   132,   133,
       0,   134,   106,   135,   728,   136,   137,   138,   139,   140,
     141,   142,   143,   107,   144,   124,     0,   739,   145,   146,
     147,   148,   149,   150,     0,     0,     0,   125,   126,     0,
       0,   151,   152,     0,   108,   153,     0,     0,     0,     0,
     120,   121,   154,     0,   155,     0,   127,     0,     0,     0,
     122,     0,     0,   105,   123,     0,     0,   128,     0,     0,
       0,   129,   130,   131,   132,   133,     0,   134,   106,   135,
       0,   136,   137,   138,   139,   140,   141,   142,   143,   107,
     144,   124,     0,     0,   145,   146,   147,   148,   149,   150,
       0,     0,     0,   125,   126,     0,     0,   151,   152,     0,
     108,   153,   439,     0,     0,     0,   120,   121,   154,     0,
     155,     0,   127,     0,     0,     0,   122,     0,     0,   105,
     123,     0,     0,   128,     0,     0,     0,   129,   130,   131,
     132,   133,     0,   134,   106,   135,     0,   136,   137,   138,
     139,   140,   141,   142,   143,   107,   144,   124,     0,     0,
     145,   146,   147,   148,   149,   150,     0,     0,     0,   125,
     126,     0,     0,   151,   152,     0,   108,   153,   461,     0,
       0,     0,     0,     0,   154,     0,   155,     0,   127,     0,
       0,     0,     0,     0,     0,   105,     0,     0,     0,   128,
       0,     0,     0,   129,   130,   131,   132,   133,     0,   134,
     106,   135,     0,   136,   137,   138,   139,   140,   141,   142,
     143,   107,   144,   120,   121,     0,   145,   146,   147,   148,
     149,   150,     0,   122,     0,     0,   497,   123,     0,   151,
     152,     0,   108,   153,     0,     0,     0,     0,     0,     0,
     154,     0,   155,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   124,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   125,   126,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   120,
     121,     0,     0,     0,     0,   127,     0,     0,     0,   122,
       0,     0,   105,   123,     0,     0,   128,     0,     0,     0,
     129,   130,   131,   132,   133,     0,   134,   106,   135,     0,
     136,   137,   138,   139,   140,   141,   142,   143,   107,   144,
     124,     0,     0,   145,   146,   147,   148,   149,   150,     0,
       0,     0,   125,   126,   499,     0,   151,   152,     0,   108,
     153,     0,     0,     0,     0,   120,   121,   154,     0,   155,
       0,   127,     0,     0,     0,   122,     0,     0,   105,   123,
       0,     0,   128,     0,     0,     0,   129,   130,   131,   132,
     133,     0,   134,   106,   135,     0,   136,   137,   138,   139,
     140,   141,   142,   143,   107,   144,   124,     0,     0,   145,
     146,   147,   148,   149,   150,     0,     0,     0,   125,   126,
       0,   503,   151,   152,     0,   108,   153,     0,     0,     0,
       0,   120,   121,   154,     0,   155,     0,   127,     0,     0,
       0,   122,     0,     0,   105,   123,     0,     0,   128,     0,
       0,     0,   129,   130,   131,   132,   133,     0,   134,   106,
     135,     0,   136,   137,   138,   139,   140,   141,   142,   143,
     107,   144,   124,     0,     0,   145,   146,   147,   148,   149,
     150,     0,     0,     0,   125,   126,     0,   505,   151,   152,
       0,   108,   153,     0,     0,     0,     0,   120,   121,   154,
       0,   155,     0,   127,     0,     0,     0,   122,     0,     0,
     105,   123,     0,     0,   128,     0,     0,     0,   129,   130,
     131,   132,   133,     0,   134,   106,   135,     0,   136,   137,
     138,   139,   140,   141,   142,   143,   107,   144,   124,     0,
       0,   145,   146,   147,   148,   149,   150,     0,     0,     0,
     125,   126,     0,     0,   151,   152,     0,   108,   153,   652,
       0,     0,     0,   120,   121,   154,     0,   155,     0,   127,
       0,     0,     0,   122,     0,     0,   105,   123,     0,     0,
     128,     0,     0,     0,   129,   130,   131,   132,   133,     0,
     134,   106,   135,     0,   136,   137,   138,   139,   140,   141,
     142,   143,   107,   144,   124,     0,     0,   145,   146,   147,
     148,   149,   150,     0,     0,     0,   125,   126,     0,     0,
     151,   152,     0,   108,   153,   654,     0,     0,     0,   120,
     121,   154,     0,   155,     0,   127,     0,     0,     0,   122,
       0,     0,   105,   123,     0,     0,   128,     0,     0,     0,
     129,   130,   131,   132,   133,     0,   134,   106,   135,     0,
     136,   137,   138,   139,   140,   141,   142,   143,   107,   144,
     124,     0,     0,   145,   146,   147,   148,   149,   150,     0,
       0,     0,   125,   126,     0,     0,   151,   152,     0,   108,
     153,   662,     0,     0,     0,   120,   121,   154,     0,   155,
       0,   127,     0,     0,     0,   122,     0,     0,   105,   123,
       0,     0,   128,     0,     0,     0,   129,   130,   131,   132,
     133,     0,   134,   106,   135,     0,   136,   137,   138,   139,
     140,   141,   142,   143,   107,   144,   124,     0,     0,   145,
     146,   147,   148,   149,   150,     0,     0,     0,   125,   126,
       0,     0,   151,   152,     0,   108,   153,   664,     0,     0,
       0,   657,   121,   154,     0,   155,     0,   127,     0,     0,
       0,   122,     0,     0,   105,   123,     0,     0,   128,     0,
       0,     0,   129,   130,   131,   132,   133,     0,   134,   106,
     135,     0,   136,   137,   138,   139,   140,   141,   142,   143,
     107,   144,   124,     0,     0,   145,   146,   147,   148,   149,
     150,     0,     0,     0,   125,   126,     0,     0,   151,   152,
       0,   108,   153,     0,     0,     0,     0,     0,     0,   154,
       0,   155,     0,   127,     0,     0,     0,     0,     0,     0,
     105,     0,     0,     0,   128,     0,     0,     0,   129,   130,
     131,   132,   133,     0,   134,   106,   135,     0,   136,   137,
     138,   139,   140,   141,   142,   143,   107,   144,     0,     0,
       0,   145,   146,   147,   148,   149,   150,     0,     0,     0,
       0,     0,     0,     0,   151,   152,     0,   108,   153,     0,
       0,     2,     3,     0,     4,   154,     0,   155,     5,     6,
       7,     8,     9,    10,    11,    12,     0,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,   684,    30,    31,    32,    33,    34,
      35,   -39,   -39,   -39,   -39,   -39,    36,    37,    38,   -39,
     -39,    39,   -39,   -39,    40,    41,   -39,   -39,    42,   -39,
      43,    44,    45,    46,   -39,    47,    48,    49,   -39,   -39,
      50,   -39,    51,   -39,    52,   -39,    53,    54,   -39,    55,
      56,    57,    58,     0,    59,   -39,   -39,     0,    60,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      61,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   339,     0,     0,     0,    62,     0,     0,
       0,     0,     0,     0,     0,     0,    63,     0,   340,   341,
     342,     0,     0,     0,     0,     0,     0,   343,   339,     0,
       0,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,     0,   340,   341,   342,     0,     0,     0,     0,
       0,     0,   343,   339,     0,     0,   344,   345,   346,   347,
     348,   349,   350,   351,   352,   353,   354,     0,   340,   341,
     342,     0,     0,     0,     0,   562,     0,   343,   339,     0,
       0,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,     0,   340,   341,   342,     0,     0,     0,     0,
     575,     0,   343,   339,     0,     0,   344,   345,   346,   347,
     348,   349,   350,   351,   352,   353,   354,     0,   340,   341,
     342,     0,     0,     0,     0,   698,     0,   343,   339,     0,
       0,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,     0,   340,   341,   342,     0,     0,     0,     0,
     700,     0,   343,   339,     0,     0,   344,   345,   346,   347,
     348,   349,   350,   351,   352,   353,   354,     0,   340,   341,
     342,     0,     0,     0,     0,   707,     0,   343,     0,     0,
       0,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,     0,   205,   206,   207,   208,   209,     0,     0,
     709,   210,   211,     0,   212,   213,     0,     0,   214,   215,
       0,   216,     0,     0,     0,     0,   217,   339,     0,     0,
     218,   219,     0,   220,     0,   221,     0,   222,     0,     0,
     223,     0,   340,   341,   342,     0,     0,   224,   225,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   491,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   525,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   548,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   569,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   570,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   577,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   585,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   586,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   587,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   588,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   589,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   590,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   592,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   593,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   595,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   596,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   597,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   599,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   600,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   601,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   602,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   604,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   606,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   623,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   696,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   704,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   705,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   710,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   711,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   712,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   713,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   732,     0,     0,
       0,   343,   339,     0,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,   340,   341,   342,
       0,     0,   749,     0,     0,     0,   343,   339,     0,     0,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,   340,   341,   342,     0,     0,   759,     0,     0,
       0,   343,     0,     0,   339,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,     0,   564,   340,
     341,   342,     0,     0,     0,     0,     0,     0,   343,     0,
       0,   339,   344,   345,   346,   347,   348,   349,   350,   351,
     352,   353,   354,     0,     0,   566,   340,   341,   342,     0,
       0,     0,     0,     0,     0,   343,     0,     0,   339,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
       0,     0,   582,   340,   341,   342,     0,     0,     0,     0,
       0,     0,   343,     0,     0,   339,   344,   345,   346,   347,
     348,   349,   350,   351,   352,   353,   354,     0,     0,   584,
     340,   341,   342,     0,     0,     0,     0,     0,     0,   343,
       0,     0,   339,   344,   345,   346,   347,   348,   349,   350,
     351,   352,   353,   354,     0,     0,   591,   340,   341,   342,
       0,     0,     0,     0,     0,     0,   343,     0,     0,   339,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,     0,     0,   594,   340,   341,   342,     0,     0,     0,
       0,     0,     0,   343,     0,     0,   339,   344,   345,   346,
     347,   348,   349,   350,   351,   352,   353,   354,     0,     0,
     603,   340,   341,   342,     0,     0,     0,     0,     0,     0,
     343,     0,     0,   339,   344,   345,   346,   347,   348,   349,
     350,   351,   352,   353,   354,     0,     0,   605,   340,   341,
     342,     0,     0,     0,     0,     0,     0,   343,     0,     0,
     339,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,     0,     0,   607,   340,   341,   342,     0,     0,
       0,     0,     0,     0,   343,     0,     0,   339,   344,   345,
     346,   347,   348,   349,   350,   351,   352,   353,   354,     0,
       0,   714,   340,   341,   342,     0,     0,     0,     0,     0,
       0,   343,   581,   339,     0,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,     0,     0,   340,   341,
     342,     0,     0,     0,     0,     0,     0,   343,   608,   339,
       0,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,     0,     0,   340,   341,   342,     0,     0,     0,
       0,     0,     0,   343,   339,     0,     0,   344,   345,   346,
     347,   348,   349,   350,   351,   352,   353,   354,     0,   340,
     341,   342,     0,     0,     0,     0,     0,     0,   343,   339,
       0,     0,   344,   345,   346,     0,   348,   349,   350,   351,
     352,   353,   354,     0,   340,   341,   342,     0,     0,     0,
       0,     0,     0,   339,     0,     0,     0,     0,   345,   346,
     347,   348,   349,   350,   351,   352,   353,   354,   340,   341,
     342,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   346,   347,   348,   349,   350,   351,   352,
     353,   354
};

static const yytype_int16 yycheck[] =
{
      10,    50,     3,    33,    53,    31,     3,    34,    41,    32,
      55,     3,    11,    40,    13,    41,    43,     4,   113,     5,
       6,    47,    21,    49,    91,    51,    75,     4,    95,     3,
      56,    15,    58,     3,    67,    61,     3,   197,    27,   154,
      17,    67,     6,   130,   136,    55,    95,    57,   140,    59,
       3,     5,     6,     3,     3,     6,    89,     6,    28,   104,
      70,     3,    72,    89,     6,     3,    11,     3,     6,     6,
       6,    81,     6,     6,    11,    12,    86,   103,   204,     3,
      79,   127,    18,     6,     6,     7,    31,   213,   118,    12,
      82,   137,     3,     4,     3,   127,    82,     6,     6,    88,
     121,   122,   228,    12,    57,    97,    17,   139,    45,   127,
     270,    97,     6,   127,   121,   122,   108,   121,   122,   137,
      35,   142,   108,   137,   151,     3,   153,   139,   155,     3,
     197,    22,   247,   140,   135,   129,   140,   129,   130,     3,
      14,   174,   139,   129,   130,     3,     3,   139,   174,    87,
     127,   135,   178,   140,     3,   141,   182,     6,    82,    17,
     137,   187,    77,   190,     3,   135,   192,   131,   135,   214,
     123,    82,   198,    97,     6,   201,   175,   127,   127,   205,
     131,     6,   135,   125,   108,   211,    97,   137,   137,   139,
     139,   217,   202,   130,   130,   221,   130,   108,   131,    57,
     226,   296,   139,   270,    78,   129,   130,   130,   130,   236,
     233,   135,   120,   223,    88,    89,   121,   122,   129,   130,
       4,   130,   130,   139,   135,   141,   275,     3,     3,   140,
     279,   241,   126,    17,   125,   140,   130,   129,   268,    97,
     139,   264,   141,   135,   277,   121,   122,   105,   121,   122,
     141,   277,   126,   263,   281,   282,    28,   284,   285,   385,
     136,     5,     6,   290,   291,     3,     6,   393,   335,   395,
     337,   139,   125,   141,   301,   302,     3,   304,   404,   405,
       3,   308,   309,   310,   311,   312,   313,   314,   315,   316,
     317,   318,   319,   320,   321,   322,   323,     3,   325,   326,
     327,   328,   329,   330,   331,   332,   333,     3,     3,   335,
       3,   337,   339,   340,   341,   342,   343,   344,   345,   414,
       3,   348,   349,   350,   351,   352,   353,   354,   361,   244,
     121,   122,     3,   359,     3,   361,     3,     4,    82,   365,
     367,   139,    19,   369,    82,   136,   413,   139,   374,   394,
      17,   139,   139,    97,    18,   381,   382,    82,   137,    97,
     386,   112,     3,   390,   108,   391,   392,   282,     3,    33,
     108,   397,    97,   383,   400,   401,     3,   403,   139,   428,
     131,   132,   133,   108,   139,   129,   130,   413,     3,   422,
     305,   129,   130,    57,   139,     3,   422,   121,   122,   448,
     410,   110,   111,   112,   129,   130,   532,     3,   139,   324,
     121,   122,   136,   539,    78,    82,    12,   139,    95,   545,
     129,   130,   131,   132,   133,   136,    22,   139,     3,   140,
      97,   139,    28,   110,   111,   112,   139,   139,   139,   139,
     139,   108,   119,     3,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,   139,   553,   136,
     139,    57,   129,   130,   139,   129,   121,   122,   135,   139,
     497,   138,   499,   139,   501,   502,   503,   139,   505,   139,
     139,   136,   139,     3,     4,   139,    82,   139,   514,   139,
      51,   517,    53,   519,     3,   521,    11,    17,   524,    14,
     139,    97,   528,    12,     6,    14,   532,   633,    23,   535,
     537,   139,   108,   139,     6,   541,    31,     3,   544,    28,
     530,    82,     6,   119,   120,    82,     3,   123,    37,   135,
     557,   127,    47,   129,   130,     3,    97,   564,   565,   566,
      97,   137,     6,   139,    82,   136,   573,   108,   139,   140,
     141,   108,     6,    38,   581,   582,   583,   584,    56,    97,
       6,   141,    82,    78,   591,   137,   112,   594,   129,   130,
     108,     3,   129,   130,   121,   122,   603,    97,   605,     3,
     607,   608,   139,   129,   130,   131,   132,   133,   108,   136,
     138,   129,   130,   128,     3,     3,   622,   512,   513,   136,
       3,   139,   139,   140,   141,   112,   632,   617,   128,   129,
     130,   125,   125,     3,   136,   135,     3,     6,     3,   629,
     647,    38,   649,   656,     6,     6,   137,     3,     3,   125,
     656,     3,   642,   136,   729,   550,    95,   128,     3,   140,
     140,   138,   136,     6,     3,   140,   561,   673,   563,     3,
     676,   110,   111,   112,     6,    19,   751,   140,   136,   138,
     687,   122,   125,   578,   139,   125,   140,   677,   678,   136,
     129,   130,   131,   132,   133,   120,   120,     3,     3,     4,
       5,     6,     6,   140,   140,     3,   139,   714,    13,   715,
     138,   142,    17,   142,     6,   142,     6,     3,   137,   142,
     142,   120,   125,   125,   125,   125,   733,   734,   735,   736,
     737,   738,   125,   125,   142,   741,   120,     6,   136,    44,
       6,     6,   137,     6,     6,     6,     6,   138,   142,   136,
       6,    56,    57,     6,   760,   745,   142,     6,   138,     6,
       6,     6,     6,   142,     3,     4,     6,   521,   648,   557,
      75,    -1,    -1,   289,    13,    -1,    -1,    82,    17,   422,
      -1,    86,    -1,    -1,    -1,    90,    91,    92,    93,    94,
      -1,    96,    97,    98,   689,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,    44,    -1,   702,   113,   114,
     115,   116,   117,   118,    -1,    -1,    -1,    56,    57,    -1,
      -1,   126,   127,    -1,   129,   130,    -1,    -1,    -1,    -1,
       3,     4,   137,    -1,   139,    -1,    75,    -1,    -1,    -1,
      13,    -1,    -1,    82,    17,    -1,    -1,    86,    -1,    -1,
      -1,    90,    91,    92,    93,    94,    -1,    96,    97,    98,
      -1,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,    44,    -1,    -1,   113,   114,   115,   116,   117,   118,
      -1,    -1,    -1,    56,    57,    -1,    -1,   126,   127,    -1,
     129,   130,   131,    -1,    -1,    -1,     3,     4,   137,    -1,
     139,    -1,    75,    -1,    -1,    -1,    13,    -1,    -1,    82,
      17,    -1,    -1,    86,    -1,    -1,    -1,    90,    91,    92,
      93,    94,    -1,    96,    97,    98,    -1,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,    44,    -1,    -1,
     113,   114,   115,   116,   117,   118,    -1,    -1,    -1,    56,
      57,    -1,    -1,   126,   127,    -1,   129,   130,   131,    -1,
      -1,    -1,    -1,    -1,   137,    -1,   139,    -1,    75,    -1,
      -1,    -1,    -1,    -1,    -1,    82,    -1,    -1,    -1,    86,
      -1,    -1,    -1,    90,    91,    92,    93,    94,    -1,    96,
      97,    98,    -1,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,     3,     4,    -1,   113,   114,   115,   116,
     117,   118,    -1,    13,    -1,    -1,   123,    17,    -1,   126,
     127,    -1,   129,   130,    -1,    -1,    -1,    -1,    -1,    -1,
     137,    -1,   139,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    56,    57,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,
       4,    -1,    -1,    -1,    -1,    75,    -1,    -1,    -1,    13,
      -1,    -1,    82,    17,    -1,    -1,    86,    -1,    -1,    -1,
      90,    91,    92,    93,    94,    -1,    96,    97,    98,    -1,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
      44,    -1,    -1,   113,   114,   115,   116,   117,   118,    -1,
      -1,    -1,    56,    57,   124,    -1,   126,   127,    -1,   129,
     130,    -1,    -1,    -1,    -1,     3,     4,   137,    -1,   139,
      -1,    75,    -1,    -1,    -1,    13,    -1,    -1,    82,    17,
      -1,    -1,    86,    -1,    -1,    -1,    90,    91,    92,    93,
      94,    -1,    96,    97,    98,    -1,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,    44,    -1,    -1,   113,
     114,   115,   116,   117,   118,    -1,    -1,    -1,    56,    57,
      -1,   125,   126,   127,    -1,   129,   130,    -1,    -1,    -1,
      -1,     3,     4,   137,    -1,   139,    -1,    75,    -1,    -1,
      -1,    13,    -1,    -1,    82,    17,    -1,    -1,    86,    -1,
      -1,    -1,    90,    91,    92,    93,    94,    -1,    96,    97,
      98,    -1,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,    44,    -1,    -1,   113,   114,   115,   116,   117,
     118,    -1,    -1,    -1,    56,    57,    -1,   125,   126,   127,
      -1,   129,   130,    -1,    -1,    -1,    -1,     3,     4,   137,
      -1,   139,    -1,    75,    -1,    -1,    -1,    13,    -1,    -1,
      82,    17,    -1,    -1,    86,    -1,    -1,    -1,    90,    91,
      92,    93,    94,    -1,    96,    97,    98,    -1,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,    44,    -1,
      -1,   113,   114,   115,   116,   117,   118,    -1,    -1,    -1,
      56,    57,    -1,    -1,   126,   127,    -1,   129,   130,   131,
      -1,    -1,    -1,     3,     4,   137,    -1,   139,    -1,    75,
      -1,    -1,    -1,    13,    -1,    -1,    82,    17,    -1,    -1,
      86,    -1,    -1,    -1,    90,    91,    92,    93,    94,    -1,
      96,    97,    98,    -1,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,    44,    -1,    -1,   113,   114,   115,
     116,   117,   118,    -1,    -1,    -1,    56,    57,    -1,    -1,
     126,   127,    -1,   129,   130,   131,    -1,    -1,    -1,     3,
       4,   137,    -1,   139,    -1,    75,    -1,    -1,    -1,    13,
      -1,    -1,    82,    17,    -1,    -1,    86,    -1,    -1,    -1,
      90,    91,    92,    93,    94,    -1,    96,    97,    98,    -1,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
      44,    -1,    -1,   113,   114,   115,   116,   117,   118,    -1,
      -1,    -1,    56,    57,    -1,    -1,   126,   127,    -1,   129,
     130,   131,    -1,    -1,    -1,     3,     4,   137,    -1,   139,
      -1,    75,    -1,    -1,    -1,    13,    -1,    -1,    82,    17,
      -1,    -1,    86,    -1,    -1,    -1,    90,    91,    92,    93,
      94,    -1,    96,    97,    98,    -1,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,    44,    -1,    -1,   113,
     114,   115,   116,   117,   118,    -1,    -1,    -1,    56,    57,
      -1,    -1,   126,   127,    -1,   129,   130,   131,    -1,    -1,
      -1,     3,     4,   137,    -1,   139,    -1,    75,    -1,    -1,
      -1,    13,    -1,    -1,    82,    17,    -1,    -1,    86,    -1,
      -1,    -1,    90,    91,    92,    93,    94,    -1,    96,    97,
      98,    -1,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,    44,    -1,    -1,   113,   114,   115,   116,   117,
     118,    -1,    -1,    -1,    56,    57,    -1,    -1,   126,   127,
      -1,   129,   130,    -1,    -1,    -1,    -1,    -1,    -1,   137,
      -1,   139,    -1,    75,    -1,    -1,    -1,    -1,    -1,    -1,
      82,    -1,    -1,    -1,    86,    -1,    -1,    -1,    90,    91,
      92,    93,    94,    -1,    96,    97,    98,    -1,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,    -1,    -1,
      -1,   113,   114,   115,   116,   117,   118,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   126,   127,    -1,   129,   130,    -1,
      -1,     0,     1,    -1,     3,   137,    -1,   139,     7,     8,
       9,    10,    11,    12,    13,    14,    -1,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,     6,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    -1,    83,    84,    85,    -1,    87,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      99,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    95,    -1,    -1,    -1,   126,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   135,    -1,   110,   111,
     112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    95,    -1,
      -1,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,   110,   111,   112,    -1,    -1,    -1,    -1,
      -1,    -1,   119,    95,    -1,    -1,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,    -1,   110,   111,
     112,    -1,    -1,    -1,    -1,   142,    -1,   119,    95,    -1,
      -1,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,   110,   111,   112,    -1,    -1,    -1,    -1,
     142,    -1,   119,    95,    -1,    -1,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,    -1,   110,   111,
     112,    -1,    -1,    -1,    -1,   142,    -1,   119,    95,    -1,
      -1,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,   110,   111,   112,    -1,    -1,    -1,    -1,
     142,    -1,   119,    95,    -1,    -1,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,    -1,   110,   111,
     112,    -1,    -1,    -1,    -1,   142,    -1,   119,    -1,    -1,
      -1,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,    40,    41,    42,    43,    44,    -1,    -1,
     142,    48,    49,    -1,    51,    52,    -1,    -1,    55,    56,
      -1,    58,    -1,    -1,    -1,    -1,    63,    95,    -1,    -1,
      67,    68,    -1,    70,    -1,    72,    -1,    74,    -1,    -1,
      77,    -1,   110,   111,   112,    -1,    -1,    84,    85,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    95,    -1,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   110,   111,   112,
      -1,    -1,   140,    -1,    -1,    -1,   119,    95,    -1,    -1,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   110,   111,   112,    -1,    -1,   140,    -1,    -1,
      -1,   119,    -1,    -1,    95,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,    -1,   136,   110,
     111,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,
      -1,    95,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   132,   133,    -1,    -1,   136,   110,   111,   112,    -1,
      -1,    -1,    -1,    -1,    -1,   119,    -1,    -1,    95,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
      -1,    -1,   136,   110,   111,   112,    -1,    -1,    -1,    -1,
      -1,    -1,   119,    -1,    -1,    95,   123,   124,   125,   126,
     127,   128,   129,   130,   131,   132,   133,    -1,    -1,   136,
     110,   111,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,
      -1,    -1,    95,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,    -1,    -1,   136,   110,   111,   112,
      -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,    -1,    95,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,    -1,   136,   110,   111,   112,    -1,    -1,    -1,
      -1,    -1,    -1,   119,    -1,    -1,    95,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,    -1,    -1,
     136,   110,   111,   112,    -1,    -1,    -1,    -1,    -1,    -1,
     119,    -1,    -1,    95,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,    -1,    -1,   136,   110,   111,
     112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    -1,    -1,
      95,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,    -1,   136,   110,   111,   112,    -1,    -1,
      -1,    -1,    -1,    -1,   119,    -1,    -1,    95,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,    -1,
      -1,   136,   110,   111,   112,    -1,    -1,    -1,    -1,    -1,
      -1,   119,   120,    95,    -1,   123,   124,   125,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,    -1,   110,   111,
     112,    -1,    -1,    -1,    -1,    -1,    -1,   119,   120,    95,
      -1,   123,   124,   125,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,    -1,   110,   111,   112,    -1,    -1,    -1,
      -1,    -1,    -1,   119,    95,    -1,    -1,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,    -1,   110,
     111,   112,    -1,    -1,    -1,    -1,    -1,    -1,   119,    95,
      -1,    -1,   123,   124,   125,    -1,   127,   128,   129,   130,
     131,   132,   133,    -1,   110,   111,   112,    -1,    -1,    -1,
      -1,    -1,    -1,    95,    -1,    -1,    -1,    -1,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   110,   111,
     112,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   125,   126,   127,   128,   129,   130,   131,
     132,   133
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,   144,     0,     1,     3,     7,     8,     9,    10,    11,
      12,    13,    14,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      34,    35,    36,    37,    38,    39,    45,    46,    47,    50,
      53,    54,    57,    59,    60,    61,    62,    64,    65,    66,
      69,    71,    73,    75,    76,    78,    79,    80,    81,    83,
      87,    99,   126,   135,   145,   148,     3,   182,     3,     6,
      18,   130,   161,   182,   147,   182,   130,   139,   151,    11,
      31,     3,    12,    14,    28,    37,   182,   129,   170,     3,
      14,    78,    88,    89,   126,   158,     3,   184,   184,     3,
      17,    57,    97,   105,     3,    82,    97,   108,   129,   130,
     165,   172,   127,   137,   156,    18,    33,    57,    78,   170,
       3,     4,    13,    17,    44,    56,    57,    75,    86,    90,
      91,    92,    93,    94,    96,    98,   100,   101,   102,   103,
     104,   105,   106,   107,   109,   113,   114,   115,   116,   117,
     118,   126,   127,   130,   137,   139,   154,   155,   165,   180,
     154,   173,     3,    28,   135,     3,     3,     6,    87,     3,
     154,     3,   135,   165,   166,    11,    12,    45,   139,   161,
     162,   154,   149,     6,     6,   165,     3,   165,     3,     6,
     139,   155,   165,   155,     3,    12,   161,   162,   165,     7,
     161,   165,   161,    28,   165,    40,    41,    42,    43,    44,
      48,    49,    51,    52,    55,    56,    58,    63,    67,    68,
      70,    72,    74,    77,    84,    85,   157,   160,   169,    12,
      22,    28,    57,   119,   120,   123,   139,   156,   166,   183,
     126,   161,     6,   161,   125,   177,     3,   139,   155,   159,
     173,    11,    14,    23,    31,    47,    78,   178,   182,     3,
       3,     6,    12,   161,   185,     3,     3,     3,     3,   161,
     184,   166,     3,     4,   180,   181,     3,     3,   155,   180,
      22,   125,   141,     3,   139,   141,   139,   165,   162,   139,
     139,   139,     5,     6,   179,   179,   137,     3,     3,   170,
       3,   139,   141,   127,   139,   139,   139,   139,   139,   139,
     141,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   154,   164,   154,   164,   154,    95,
     110,   111,   112,   119,   123,   124,   125,   126,   127,   128,
     129,   130,   131,   132,   133,   121,   122,     3,     3,     3,
     166,   182,     3,   135,   165,     3,     3,   139,   163,   165,
     168,     6,     6,     3,   165,     6,   154,   165,     3,   135,
     181,   165,   165,   161,     3,   168,   165,     6,     3,     6,
     125,   139,   165,   168,   162,    38,    51,    53,   165,     6,
     139,   165,    56,   161,   165,   168,     6,   156,   171,   154,
     141,   161,   173,   164,   137,   140,     3,    57,   123,   135,
       3,   135,   146,   152,   161,   156,   135,   170,   181,   155,
       3,   166,   155,   154,   173,   176,   154,   173,   154,   131,
     154,     3,   177,   154,   154,   128,   138,   179,     3,     3,
     153,   154,   154,     3,   154,   173,     3,     4,   140,   154,
     154,   131,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   173,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   128,   135,   166,   180,
     138,   140,   154,   154,   154,   154,   154,   123,   154,   124,
     154,   125,   125,   125,   154,   125,   154,   154,   154,   154,
     154,   154,   175,   174,   165,   166,     3,   136,   141,   165,
     154,   150,   165,     6,   165,   140,     3,     3,   165,   165,
     161,   168,   165,     6,   154,   165,   165,   168,   162,   168,
     165,   165,   165,    38,   165,   168,   168,     6,   140,   161,
     136,   140,   179,   137,     3,     3,   183,   125,     3,   155,
      19,   136,   142,   136,   136,   136,   136,   140,   140,   140,
     140,   138,   155,   136,   140,   142,   128,   140,   136,   140,
     140,   120,   136,   136,   136,   140,   140,   140,   140,   140,
     140,   136,   140,   140,   136,   140,   140,   140,   140,   140,
     140,   140,   140,   136,   140,   136,   140,   136,   120,   154,
     154,   154,   154,   154,   154,   173,   173,   165,     3,   165,
       6,   131,   165,   140,   163,     6,   165,     3,   165,   120,
     161,     3,   165,   168,     6,   165,   154,   168,   165,   165,
     168,    19,   136,   173,   138,   179,   176,   139,   173,   125,
     173,   154,   131,   154,   131,   154,   125,     3,   154,   173,
     154,   154,   131,   154,   131,   154,   154,   154,   154,   154,
     154,   154,   161,   140,   136,   120,   165,   161,   120,     3,
     165,   168,     6,   140,     6,   140,     3,   139,   161,   136,
     167,   138,   154,   167,   154,   142,   140,   142,   142,   142,
     142,   166,   136,   140,   140,   140,   142,   142,   142,   142,
     140,   140,   140,   140,   136,   165,     6,     6,   131,   165,
     161,   161,     6,     3,     6,     3,   154,   142,   173,   137,
      15,   135,   140,   125,   125,   125,   125,   125,   125,   173,
     154,   165,   120,   136,   142,   120,     6,     6,     6,   140,
     179,   137,   154,   154,   154,   154,   154,   154,   140,   140,
     165,     6,   131,     6,   161,     6,     6,     6,   138,   179,
     165,   136,   142,   142,     6,     6,     6,   138,     6,     6,
       6,     6,   142,     6
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
Static Const char Far * Const Far 
yystpcpy (char *yydest, const char *yysrc)
#else
Static Const char Far * Const Far 
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */






/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
    char buff[MACROSIZE + 1],	/* buffer for reading macros */
	       word[CHARMAX];		/* buffer for storing WORD */
   char variable_name[CHARMAX];		/* name of variable being defined */
  /* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;

  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
/* #line 130 "control.y" */
    {
#if defined(YYFAIL)
#  undef  YYERROR			/* work around for Bison bug */
#  define YYERROR YYFAIL		/* must be here, not in preamble */
#endif
	    start_line();
	 }
    break;

  case 4:
/* #line 141 "control.y" */
    {
	    fflush(stdout); fflush(stderr);
	    if(buff_is_empty()) {	/* no characters on input buffer */
	       if(graph_mode) {
		  IDLE();		/* out of graphics mode */
		  graph_mode = 0;
	       }
	       return(1);
	    }
	    start_line();		/* start a new line in tokens.c */
	 }
    break;

  case 5:
/* #line 153 "control.y" */
    {
	    char cmd[200];		/* command to execute */
	    char *shell;		/* the shell to use */

	    reset_term();
	    (void)mgets(cmd,MACROSIZE);	/* read rest of line */
	    if(*(shell = print_var("SHELL")) != '\0' &&
						strcmp(shell,"/bin/sh") != 0) {
	       sprintf(buff,"%s -c \"%s\"",shell,cmd);
	       set_exit_status(system(buff));
	    } else {
	       set_exit_status(system(cmd));
	    }
	    set_term();
	 }
    break;

  case 6:
/* #line 169 "control.y" */
    {
	    abort_plot = 1;
	    if(graph_mode) { IDLE(); graph_mode = 0; }
	    CLOSE(); stg_close();
	    devnum = NODEVICE;
	    SETUP("");
	    if(in_graphics) { ENABLE(); graph_mode = 1; }
	    set_dev();
	    abort_plot = 0;
	 }
    break;

  case 7:
/* #line 180 "control.y" */
    {
	    vec_convert_float(&(yyvsp[(2) - (2)].vector));
	    set_angle((yyvsp[(2) - (2)].vector).vec.f,(yyvsp[(2) - (2)].vector).dimen);
	    vec_free(&(yyvsp[(2) - (2)].vector));
	 }
    break;

  case 8:
/* #line 186 "control.y" */
    {
	    (void)mgets(buff,CHARMAX);	/* read rest of line */
	    help_apropos(&buff[1]);
	    macro_apropos(&buff[1]);
	 }
    break;

  case 9:
/* #line 192 "control.y" */
    { set_aspect( (yyvsp[(2) - (2)].floatval) ); }
    break;

  case 10:
/* #line 194 "control.y" */
    {
	    if((yyvsp[(2) - (2)].charval)[0] == '~') {
	       if(getenv("HOME") == NULL) {
		  msg("can't expand ~  : HOME is not defined\n");
		  (void)strcpy(buff,(yyvsp[(2) - (2)].charval));
	       }
	       (void)sprintf(buff,"%s%s",getenv("HOME"),&(yyvsp[(2) - (2)].charval)[1]);
	    } else {
	       (void)strcpy(buff,(yyvsp[(2) - (2)].charval));
	    }
#if 0 && defined(VMS)			/* let's see if this works */
	    msg("Chdir is not currently provided, due to a VMS bug\n");
	    break;
#endif
#if defined(__MSDOS__)
	    if(buff[1] == ':') {
	       setdisk(isupper(buff[0]) ? tolower(buff[0]) : buff[0]);
	       if(buff[2] == '\0') break;
	    }
#endif
	    if(chdir(buff) != 0) {
	       perror("Error in CHDIR ");
	    }
	 }
    break;

  case 11:
/* #line 219 "control.y" */
    {
	    int key;

	    if(sm_verbose) {
	       msg("Hit 'e' to exit, 'q' to quit\n");
	    }
	    key = sm_cursor(0);
	    sm_disable();
            (void)unput('\n');

	    if(key == 'e') {
	       (void)sprintf(buff,"relocate %g %g",
			     (xp - ffx)/fsx, (yp - ffy)/fsy);
	       replace_last_command(buff);
	    } else {
	       delete_last_history(1);
	    }
	 }
    break;

  case 12:
/* #line 238 "control.y" */
    {
	    sm_cursor(-1);
	    sm_disable();
	 }
    break;

  case 13:
/* #line 243 "control.y" */
    {
	    if(sm_verbose) {
	       msg_2s("%s%s\n", "Enter a `e' or `m' to mark a point, ",
		      "`p' to mark a point and exit, `q' to quit");
	    }
	    set_cursor_vectors((yyvsp[(2) - (3)].charval),(yyvsp[(3) - (3)].charval),(char *)NULL);
	    sm_disable();
	 }
    break;

  case 14:
/* #line 252 "control.y" */
    {
#if defined(HAVE_ACCESS)
	    if(access((yyvsp[(2) - (2)].charval), R_OK) != 0) {
	       msg_1s("Denied access to open %s\n",(yyvsp[(2) - (2)].charval));
	    }
#else
	    FILE *fil;

	    if((fil = fopen((yyvsp[(2) - (2)].charval),"r")) == NULL) {
	       msg_1s("Can't open %s\n",(yyvsp[(2) - (2)].charval));
	    } else {
	       (void)fclose(fil);
	    }
#endif
	    (void)strncpy(data_file,(yyvsp[(2) - (2)].charval),CHARMAX); /* the file to read data */
	    line_1 = line_2 = 0;	/* no lines specified */
	    subtable = -1;		/* we aren't reading a table */
	    set_data_file((yyvsp[(2) - (2)].charval));
	 }
    break;

  case 15:
/* #line 272 "control.y" */
    { ; }
    break;

  case 16:
/* #line 273 "control.y" */
    { if(variable_name[0] != '\0') make_local_variable(variable_name); }
    break;

  case 17:
/* #line 274 "control.y" */
    { ; }
    break;

  case 18:
/* #line 276 "control.y" */
    {
	    delete_last_history(1);	/* forget this command */
	    delete_last_history(1);	/* and the last one too */
	 }
    break;

  case 19:
/* #line 281 "control.y" */
    { delete_history((yyvsp[(2) - (2)].intval),(yyvsp[(2) - (2)].intval),1); }
    break;

  case 20:
/* #line 283 "control.y" */
    { delete_history((yyvsp[(2) - (3)].intval),(yyvsp[(3) - (3)].intval),1); }
    break;

  case 21:
/* #line 285 "control.y" */
    { delete_last_history(0); }
    break;

  case 22:
/* #line 287 "control.y" */
    { delete_last_history(1); }
    break;

  case 23:
/* #line 289 "control.y" */
    { delete_history((yyvsp[(3) - (3)].intval),(yyvsp[(3) - (3)].intval),0); }
    break;

  case 24:
/* #line 291 "control.y" */
    { delete_history((yyvsp[(3) - (4)].intval),(yyvsp[(4) - (4)].intval),0); }
    break;

  case 25:
/* #line 293 "control.y" */
    { (void)free_vector((yyvsp[(2) - (2)].charval)); }
    break;

  case 26:
/* #line 295 "control.y" */
    {
	      if(graph_mode) IDLE();
	      CLOSE(); stg_close();
	      devnum = NODEVICE;

	      (void)mgets(word,CHARMAX); /* read rest of line */
	      if((yyvsp[(2) - (2)].intval) >= 0 && (yyvsp[(2) - (2)].intval) < ndev) {
		 if((*devices[(yyvsp[(2) - (2)].intval)].dev_setup)(word) >= 0) {
		    devnum = (yyvsp[(2) - (2)].intval);
		 } else {
		    msg_1s("No such device %s\n",word);
		 }
	      } else {
	         msg_1d("No such device %d\n",(yyvsp[(2) - (2)].intval));
	      }
	      ENABLE(); graph_mode = 1;
	      set_dev();
	   }
    break;

  case 27:
/* #line 314 "control.y" */
    {
	      if(strcmp((yyvsp[(3) - (3)].charval),"close") == 0 || strcmp((yyvsp[(3) - (3)].charval),"CLOSE") == 0) {
		 close_metafile();
	      } else {
		 open_metafile((yyvsp[(3) - (3)].charval));
	      }
	   }
    break;

  case 28:
/* #line 322 "control.y" */
    {
    	      int len;

	      if(graph_mode) IDLE();

	      (void)sprintf(buff,"%s",(yyvsp[(2) - (2)].charval));
	      len = strlen(buff);
	      (void)mgets(&buff[len],MACROSIZE - len); /* read rest of line */
	      
	      set_device(buff);

	      ENABLE(); graph_mode = 1;
	      set_dev();
	   }
    break;

  case 29:
/* #line 337 "control.y" */
    {
	    if(sm_dither((yyvsp[(2) - (6)].charval), (yyvsp[(3) - (6)].charval), (yyvsp[(4) - (6)].floatval), (yyvsp[(5) - (6)].floatval), (yyvsp[(6) - (6)].intval)) < 0) {
	       break;
	    }
	 }
    break;

  case 30:
/* #line 343 "control.y" */
    {
	    if(variable_name[0] == '\0' || (yyvsp[(9) - (10)].strval).start == NULL) {
	       if((yyvsp[(9) - (10)].strval).start != NULL) free((yyvsp[(9) - (10)].strval).start);
	       break;
	    }

	    push_dstack(variable_name,(yyvsp[(4) - (10)].floatval),(yyvsp[(6) - (10)].floatval),(yyvsp[(7) - (10)].floatval)); /* set up DO variables */
	    if(next_do() == 0) {	/* set intial value of DO variable */
	       push((yyvsp[(9) - (10)].strval).start,S_DO);	/* push body of DO loop */
	    }
         }
    break;

  case 31:
/* #line 354 "control.y" */
    { (void)mscanstr((yyval.charval),CHARMAX); }
    break;

  case 32:
/* #line 355 "control.y" */
    { define_map((yyvsp[(2) - (3)].charval),(yyvsp[(3) - (3)].charval)); }
    break;

  case 33:
/* #line 357 "control.y" */
    {
	    lexflush();			/* flush lex buffer */
            yyerrok;
            yyclearin;			/* reset the parser */
	    start_line();		/* start a new line in tokens.c */
	    if(graph_mode) {
	       IDLE();
	       graph_mode = 0;
	    }
	    if(recurse_lvl) {
	       if(recurse_lvl > 1) {	/* keep on popping */
		  push("SNARK ",S_NORMAL);
	       }
	       recurse_lvl--;
	       return(1);
	    }
	    if(buff_is_empty()) {	/* no characters on input buffer */
	       return(1);
	    }
         }
    break;

  case 34:
/* #line 378 "control.y" */
    {
	    vec_convert_float(&(yyvsp[(2) - (2)].vector));
	    set_expand((yyvsp[(2) - (2)].vector).vec.f,(yyvsp[(2) - (2)].vector).dimen);
	    vec_free(&(yyvsp[(2) - (2)].vector));
	 }
    break;

  case 35:
/* #line 384 "control.y" */
    {
	    VECTOR *temp_r,*temp_i;
	    
	    if((yyvsp[(2) - (6)].floatval) != 1 && (yyvsp[(2) - (6)].floatval) != -1) {
	       msg_1f("You must specify 1 or -1 for an FFT, not %g\n",(yyvsp[(2) - (6)].floatval));
	       vec_free(&(yyvsp[(3) - (6)].vector));
	       vec_free(&(yyvsp[(4) - (6)].vector));
	       break;
	    }
	    if((yyvsp[(3) - (6)].vector).dimen != (yyvsp[(4) - (6)].vector).dimen) {
	       msg_2s("Vectors %s and %s have different dimensions\n",
		      (yyvsp[(3) - (6)].vector).name,(yyvsp[(4) - (6)].vector).name);
	       vec_free(&(yyvsp[(3) - (6)].vector));
	       vec_free(&(yyvsp[(4) - (6)].vector));
	       break;
	    }
	    if((temp_r = make_vector((yyvsp[(5) - (6)].charval),(yyvsp[(3) - (6)].vector).dimen,VEC_FLOAT)) == NULL) {
	       vec_free(&(yyvsp[(3) - (6)].vector));
	       vec_free(&(yyvsp[(4) - (6)].vector));
	       break;
	    }
	    if((temp_i = make_vector((yyvsp[(6) - (6)].charval),(yyvsp[(3) - (6)].vector).dimen,VEC_FLOAT)) == NULL) {
	       vec_free(&(yyvsp[(3) - (6)].vector));
	       vec_free(&(yyvsp[(4) - (6)].vector));
	       free_vector((yyvsp[(5) - (6)].charval));
	       break;
	    }
	    (void)fft((yyvsp[(3) - (6)].vector).vec.f,(yyvsp[(4) - (6)].vector).vec.f,temp_r->vec.f,temp_i->vec.f,(yyvsp[(3) - (6)].vector).dimen,
								      (int)(yyvsp[(2) - (6)].floatval));
	    vec_free(&(yyvsp[(3) - (6)].vector));
	    vec_free(&(yyvsp[(4) - (6)].vector));
	 }
    break;

  case 36:
/* #line 417 "control.y" */
    {
	    if(variable_name[0] == '\0' || (yyvsp[(3) - (6)].t_list) == NULL || (yyvsp[(5) - (6)].strval).start == NULL) {
	       freelist((yyvsp[(3) - (6)].t_list));
	       if((yyvsp[(5) - (6)].strval).start != NULL) free((yyvsp[(5) - (6)].strval).start);
	       break;
	    }
	    if((yyvsp[(3) - (6)].t_list)->nitem <= 0) {	/* Null list */
	       msg_1s("FOREACH %s variable list is empty\n",variable_name);
	       freelist((yyvsp[(3) - (6)].t_list));
	       free((yyvsp[(5) - (6)].strval).start);
	       break;
	    }
	    push_fstack(variable_name,(yyvsp[(3) - (6)].t_list));
	    (void)next_foreach();
	    push((yyvsp[(5) - (6)].strval).start,S_FOREACH);	/* $3 and $5 will be freed later */
         }
    break;

  case 37:
/* #line 434 "control.y" */
    { sm_format( (yyvsp[(2) - (3)].charval), (yyvsp[(3) - (3)].charval) ); }
    break;

  case 38:
/* #line 436 "control.y" */
    {
	    sm_format("1","1");
	    (void)unput('\n');
	 }
    break;

  case 39:
/* #line 440 "control.y" */
    {
	   in_graphics = 1;
	   if(!graph_mode) { ENABLE(); graph_mode = 1; }
        }
    break;

  case 40:
/* #line 445 "control.y" */
    { in_graphics = 0; GFLUSH(); }
    break;

  case 41:
/* #line 447 "control.y" */
    {
	    char *var;
	    int i,j;

	    if(graph_mode) { IDLE(); graph_mode = 0; }
            (void)mgets(word,CHARMAX);	/* will have leading ' ' */
	    for(j = strlen(word) - 1;j >= 0 && isspace(word[j]);j--) {
	       word[j] = '\0';
	    }
	    for(i = 0;i < j && isspace(word[i]);i++) continue;
	    if(word[i] == '\0') {
	       (void)strcpy(word,"help");
	       i = 0;
	    }
            if((j = help(&word[i])) < 0) {	/* in help directory? */
	       break;
	    }
            j += (what_is(&word[i]) == 0);	/* maybe it's a macro */
	    var = print_var(&word[i]);
	    j += (var[0] != '\0');		/* or a variable? */
	    if(var[0] != '\0') {
	       (void)printf("Variable : %s\n",var);
	    }
	    j += (help_vector(&word[i]) == 0);	/* maybe a vector? */
	    if(j == 0) {			/* nothing we know about */
	       (void)fprintf(stderr,"I'm sorry %s, %s\n",user_name,
					  "but I can't help you with that.");
            }
	    fflush(stdout);
         }
    break;

  case 42:
/* #line 478 "control.y" */
    { history_list(1); }
    break;

  case 43:
/* #line 480 "control.y" */
    { history_list(-1); }
    break;

  case 44:
/* #line 482 "control.y" */
    {
	    (void)unput('\n');
	    if((yyvsp[(6) - (8)].strval).start == NULL) break;
	    if((yyvsp[(3) - (8)].floatval)) {
	       push((yyvsp[(6) - (8)].strval).start,S_TEMP);
	    } else {
	       free((yyvsp[(6) - (8)].strval).start);
	    }
	 }
    break;

  case 45:
/* #line 492 "control.y" */
    {
	    char *if_body;
	    
	    if((yyvsp[(6) - (11)].strval).start == NULL) {
	       if((yyvsp[(10) - (11)].strval).start != NULL) free((yyvsp[(10) - (11)].strval).start);
	       break;
	    }
	    if((yyvsp[(10) - (11)].strval).start == NULL) {
	       free((yyvsp[(6) - (11)].strval).start);
	       break;
	    }
	    
	    if((yyvsp[(3) - (11)].floatval)) {
	       free((yyvsp[(10) - (11)].strval).start);
	       if_body = (yyvsp[(6) - (11)].strval).start;
	    } else {
	       free((yyvsp[(6) - (11)].strval).start);
	       if_body = (yyvsp[(10) - (11)].strval).start;
	    }

	    push(if_body,S_TEMP);
	 }
    break;

  case 46:
/* #line 515 "control.y" */
    {
	    sm_cursor(1);
	    sm_disable();
            (void)unput('\n');
	 }
    break;

  case 47:
/* #line 521 "control.y" */
    {
	    set_cursor_vectors((yyvsp[(3) - (5)].charval),(yyvsp[(4) - (5)].charval),(yyvsp[(5) - (5)].charval));
	    sm_disable();
            (void)unput('\n');
	 }
    break;

  case 48:
/* #line 527 "control.y" */
    { if(variable_name[0] != '\0') set_image_variable(variable_name,(yyvsp[(4) - (4)].charval)); }
    break;

  case 49:
/* #line 529 "control.y" */
    { (void)sm_delimage(); }
    break;

  case 50:
/* #line 531 "control.y" */
    { (void)read_image((yyvsp[(3) - (3)].charval),(yyvsp[(2) - (3)].intval),0.0,0.0,0.0,0.0, -1, -1, -1, -1); }
    break;

  case 51:
/* #line 533 "control.y" */
    { (void)read_image((yyvsp[(3) - (8)].charval),(yyvsp[(2) - (8)].intval),0.0,0.0,0.0,0.0, -1, -1, -1, -1); }
    break;

  case 52:
/* #line 535 "control.y" */
    { (void)read_image((yyvsp[(3) - (10)].charval),(yyvsp[(2) - (10)].intval),0.0,0.0,0.0,0.0, (yyvsp[(5) - (10)].intval), (yyvsp[(7) - (10)].intval), -1, -1); }
    break;

  case 53:
/* #line 537 "control.y" */
    { (void)read_image((yyvsp[(3) - (10)].charval),(yyvsp[(2) - (10)].intval),0.0,0.0,0.0,0.0, -1, -1, (yyvsp[(7) - (10)].intval), (yyvsp[(9) - (10)].intval)); }
    break;

  case 54:
/* #line 539 "control.y" */
    { (void)read_image((yyvsp[(3) - (12)].charval),(yyvsp[(2) - (12)].intval),0.0,0.0,0.0,0.0, (yyvsp[(5) - (12)].intval), (yyvsp[(7) - (12)].intval), (yyvsp[(9) - (12)].intval), (yyvsp[(11) - (12)].intval)); }
    break;

  case 55:
/* #line 541 "control.y" */
    { (void)read_image((yyvsp[(3) - (7)].charval),(yyvsp[(2) - (7)].intval),(yyvsp[(4) - (7)].floatval),(yyvsp[(5) - (7)].floatval),(yyvsp[(6) - (7)].floatval),(yyvsp[(7) - (7)].floatval), -1,-1,-1,-1); }
    break;

  case 56:
/* #line 543 "control.y" */
    { create_image((int)((yyvsp[(3) - (6)].floatval) + 1e-5),(int)((yyvsp[(5) - (6)].floatval) + 1e-5),
			0.0,(float)(yyvsp[(3) - (6)].floatval) - 1,0.0,(float)(yyvsp[(5) - (6)].floatval) - 1); }
    break;

  case 57:
/* #line 546 "control.y" */
    { create_image((int)((yyvsp[(3) - (10)].floatval) + 1e-5),(int)((yyvsp[(5) - (10)].floatval) + 1e-5),(yyvsp[(7) - (10)].floatval),(yyvsp[(8) - (10)].floatval),(yyvsp[(9) - (10)].floatval),(yyvsp[(10) - (10)].floatval)); }
    break;

  case 58:
/* #line 548 "control.y" */
    {
	    vec_convert_float(&(yyvsp[(2) - (2)].vector));
	    sm_levels((yyvsp[(2) - (2)].vector).vec.f,(int)(yyvsp[(2) - (2)].vector).dimen);
	    vec_free(&(yyvsp[(2) - (2)].vector));
         }
    break;

  case 59:
/* #line 553 "control.y" */
    { xy_range = x_range; }
    break;

  case 60:
/* #line 553 "control.y" */
    { xy_range = y_range; }
    break;

  case 61:
/* #line 554 "control.y" */
    { (void)sm_limits( (yyvsp[(3) - (5)].pairval).a, (yyvsp[(3) - (5)].pairval).b, (yyvsp[(5) - (5)].pairval).a, (yyvsp[(5) - (5)].pairval).b ); }
    break;

  case 62:
/* #line 556 "control.y" */
    { key_macro(); }
    break;

  case 63:
/* #line 558 "control.y" */
    {
	    line_1 = (yyvsp[(2) - (3)].intval);
	    line_2 = (yyvsp[(3) - (3)].intval);
	    sprintf(buff,"%d",line_1); setvar("_l1",buff);
	    sprintf(buff,"%d",line_2); setvar("_l2",buff);
	 }
    break;

  case 64:
/* #line 564 "control.y" */
    { disable_overload(); }
    break;

  case 65:
/* #line 564 "control.y" */
    { allow_overload(); }
    break;

  case 66:
/* #line 566 "control.y" */
    { (void)sm_location( (yyvsp[(2) - (5)].intval), (yyvsp[(3) - (5)].intval), (yyvsp[(4) - (5)].intval), (yyvsp[(5) - (5)].intval)); }
    break;

  case 67:
/* #line 568 "control.y" */
    {
	    if((yyvsp[(2) - (2)].floatval) < 0) {
	       msg("LWEIGHT cannot be negative; setting to zero\n");
	       (yyvsp[(2) - (2)].floatval) = 0;
	    }
	    sm_lweight((yyvsp[(2) - (2)].floatval));
	 }
    break;

  case 68:
/* #line 576 "control.y" */
    {
	    if((yyvsp[(4) - (4)].strval).start == NULL) break;
            *((yyvsp[(4) - (4)].strval).end) = '\0';		/* remove '\n' */

            (void)define_s((yyvsp[(2) - (4)].charval),(yyvsp[(4) - (4)].strval).start,(yyvsp[(3) - (4)].charval));

            free((yyvsp[(4) - (4)].strval).start);
         }
    break;

  case 69:
/* #line 585 "control.y" */
    { (void)define((yyvsp[(2) - (3)].charval),"delete",0,0,0); }
    break;

  case 70:
/* #line 587 "control.y" */
    { (void)define_history_macro((yyvsp[(2) - (4)].charval),(yyvsp[(3) - (4)].intval),(yyvsp[(4) - (4)].intval));}
    break;

  case 71:
/* #line 589 "control.y" */
    { (void)macro_edit((yyvsp[(3) - (3)].charval)); }
    break;

  case 72:
/* #line 591 "control.y" */
    {
	    FILE *fil;

	    if((fil = fopen((yyvsp[(3) - (3)].charval),"r")) == NULL) {
	       msg_1s("can't open %s\n",(yyvsp[(3) - (3)].charval));
	       break;
	    }
	    (void)read_macros(fil);
	    (void)fclose(fil);
	 }
    break;

  case 73:
/* #line 602 "control.y" */
    { (void)undefine_macros((yyvsp[(3) - (3)].charval)); }
    break;

  case 74:
/* #line 604 "control.y" */
    {
	    FILE *fil;

            (void)unput('\n');
	    if(would_clobber((yyvsp[(3) - (4)].charval))) {
	       break;
	    }
	    if((fil = fopen((yyvsp[(3) - (4)].charval),"w")) == NULL) {
	       msg_1s("can't open %s\n",(yyvsp[(3) - (4)].charval));
	       break;
	    }
            (void)write_macros(fil,1);	/* write all macros */
	    (void)fclose(fil);
         }
    break;

  case 75:
/* #line 619 "control.y" */
    { (void)write_one_macro((yyvsp[(3) - (5)].charval),(yyvsp[(5) - (5)].charval),((yyvsp[(4) - (5)].intval) == '+')); }
    break;

  case 76:
/* #line 621 "control.y" */
    { playback_metafile((yyvsp[(3) - (3)].charval)); }
    break;

  case 77:
/* #line 623 "control.y" */
    {
	    float min,max;

	    sm_minmax(&min,&max);
	    (void)sprintf(buff,"%.10g",min);
	    setvar((yyvsp[(2) - (3)].charval),buff);
	    (void)sprintf(buff,"%.10g",max);
	    setvar((yyvsp[(3) - (3)].charval),buff);
	 }
    break;

  case 78:
/* #line 633 "control.y" */
    { sm_notation( (yyvsp[(2) - (5)].floatval), (yyvsp[(3) - (5)].floatval), (yyvsp[(4) - (5)].floatval), (yyvsp[(5) - (5)].floatval) ); }
    break;

  case 79:
/* #line 635 "control.y" */
    { overload(variable_name,(yyvsp[(3) - (3)].intval)); }
    break;

  case 80:
/* #line 637 "control.y" */
    {
	    int append = ((yyvsp[(2) - (5)].intval) == '+');  
	    int dimen = 0,i,nvec;
	    VECTOR **temp;

	    if(!append && would_clobber((yyvsp[(3) - (5)].charval))) {
	       break;
	    }
	    if(graph_mode) { graph_mode = 0; IDLE(); }

	    nvec = (yyvsp[(5) - (5)].t_list)->nitem;
	    if((temp = (VECTOR **)malloc(nvec*sizeof(VECTOR *))) == NULL) {
	       msg("Can't allocate storage for temp\n");
	       break;
	    }

	    for(i = 0;i < nvec && !sm_interrupt;i++) {	/* get vectors */
	       if((temp[i] = get_vector_ptr((yyvsp[(5) - (5)].t_list)->i_list[i]->str)) == NULL) {
		  break;
	       }
	       if(i == 0) {
		  dimen = temp[0]->dimen;
	       } else if(temp[i]->dimen != dimen) {
		  if(sm_verbose > 1)
		     msg("Vectors are different sizes\n");
		  if(dimen < temp[i]->dimen) {
		     dimen = temp[i]->dimen;
		  }
	       }
	    }
	    if(i < nvec) {
	       free((char *)temp);
               freelist((yyvsp[(5) - (5)].t_list));
	       break;
	    }

	    print_vec((yyvsp[(3) - (5)].charval),append ? "a" : "w",(yyvsp[(4) - (5)].charval),nvec,temp,dimen);
	    
	    free((char *)temp);
            freelist((yyvsp[(5) - (5)].t_list));
	 }
    break;

  case 81:
/* #line 679 "control.y" */
    {
	    int i;

	    (void)mgets(buff,100);
	    for(plength = 0,i = 0;buff[i + 1] != '\0';i++) {
	       prompt[i] = buff[i + 1];
	       if(prompt[i] == '*') prompt[i] = '\007'; /* replace * with ^G */
	       if(isprint(prompt[i])) plength++;
	    }
	    plength++;			/* allow for ' ' */
	    prompt[i] = '\0';
         }
    break;

  case 82:
/* #line 692 "control.y" */
    {
	    REAL pstyle[1];

	    pstyle[0] = 10*(yyvsp[(2) - (3)].intval) + (yyvsp[(3) - (3)].intval);
	    sm_ptype( pstyle, 1 );
	 }
    break;

  case 83:
/* #line 699 "control.y" */
    {
	    VECTOR *tptr;

	    if((tptr = get_vector_ptr((yyvsp[(2) - (2)].charval))) == NULL) {
	       break;
	    }
	    switch (tptr->type) {
	     case VEC_FLOAT:
	       sm_ptype(tptr->vec.f,tptr->dimen);
	       break;
	     case VEC_LONG:
	       vec_convert_float(tptr);
	       sm_ptype(tptr->vec.f,tptr->dimen);
	       break;
	     case VEC_STRING:
	       ptype_str(tptr->name,tptr->vec.s.s_s,tptr->dimen);
	       break;
	     default:
	       msg_1s("%s is an ",(yyvsp[(2) - (2)].charval));
	       msg_1d("unknown type of vector: %d\n",tptr->type);
	       break;
	    }
	 }
    break;

  case 84:
/* #line 723 "control.y" */
    {
	    if((yyvsp[(3) - (4)].vector).type == VEC_STRING) {
	       msg_1s("%s is not an arithmetic expression\n",(yyvsp[(3) - (4)].vector).name);
	       break;
	    }
	    
	    vec_convert_float(&(yyvsp[(3) - (4)].vector));
	    sm_ptype( (yyvsp[(3) - (4)].vector).vec.f, (yyvsp[(3) - (4)].vector).dimen );
	    vec_free(&(yyvsp[(3) - (4)].vector));
	 }
    break;

  case 85:
/* #line 734 "control.y" */
    {
	    if((yyvsp[(2) - (2)].t_list) == NULL) break;
	    if((yyvsp[(2) - (2)].t_list)->nitem <= 0) {	/* Null symbol list */
	       msg("Symbol definition list is empty\n");
	       freelist((yyvsp[(2) - (2)].t_list));
	       break;
	    }	       

	    setsym((yyvsp[(2) - (2)].t_list));
	    freelist((yyvsp[(2) - (2)].t_list));
	 }
    break;

  case 86:
/* #line 746 "control.y" */
    {
	    if(graph_mode) IDLE();
	    CLOSE(); stg_close();
	    return(-1);
	 }
    break;

  case 87:
/* #line 752 "control.y" */
    {
	    x_range = (yyvsp[(2) - (3)].floatval);
	    y_range = (yyvsp[(3) - (3)].floatval);
	 }
    break;

  case 88:
/* #line 757 "control.y" */
    { (void)read_map((yyvsp[(3) - (3)].charval)); }
    break;

  case 89:
/* #line 759 "control.y" */
    { read_old((yyvsp[(3) - (4)].charval),(yyvsp[(4) - (4)].charval)); }
    break;

  case 90:
/* #line 761 "control.y" */
    {
	    int col;
	    VECTOR temp;

	    col = atoi((yyvsp[(4) - (4)].charval));
	    temp.type = parse_qualifier((yyvsp[(4) - (4)].charval));
	    temp.name = (yyvsp[(3) - (4)].charval);
	    if(read_row(data_file,col,&temp) == 0) {
	       copy_vector(temp.name,temp);
	    }
	 }
    break;

  case 91:
/* #line 773 "control.y" */
    {
	    int col;
	    VECTOR *tptr,temp;

	    tptr = &temp;
	    col = atoi((yyvsp[(3) - (3)].charval));
	    temp.name = (yyvsp[(2) - (3)].charval);
	    temp.type = parse_qualifier((yyvsp[(3) - (3)].charval));
	    if(read_column(0,data_file,&col,&tptr,1,line_1,line_2,"") == 1) {
	       copy_vector(temp.name,temp);
	    }
	 }
    break;

  case 92:
/* #line 786 "control.y" */
    {
	    int *cols,			/* desired columns */
	        extra,			/* extra i_list items processed */
	        i,j,k,
	        ncol,nvec,
	        n1,n2,			/* range of columns for a vector */
	        size_cols;		/* size of cols, temp */
	    VECTOR **temp, *temp_s;	/* temporary vectors */

	    (yyvsp[(2) - (3)].intval) = ((yyvsp[(2) - (3)].intval) == '!') ? 1 : 0;
	    if((yyvsp[(3) - (3)].t_list) == NULL) break;
	    ncol = (yyvsp[(3) - (3)].t_list)->nitem;

	    size_cols = ncol;		/* initially assume no ranges */
	    if((cols = (int *)malloc(size_cols*sizeof(int))) == NULL) {
	       msg("Can't allocate space for columns list\n");
	       break;
	    }
	    if((temp = (VECTOR **)malloc(size_cols*sizeof(VECTOR *))) == NULL){
	       msg("Can't allocate storage for temp\n");
	       free((char *)cols);
	       break;
	    }
	    if((temp_s = (VECTOR *)malloc(size_cols*sizeof(VECTOR))) == NULL){
	       msg("Can't allocate storage for temp_s\n");
	       free((char *)temp);
	       free((char *)cols);
	       break;
	    }
	    for(i = 0;i < size_cols;i++) {
	       temp[i] = temp_s + i;
	       temp[i]->name = temp[i]->descrip + 1;
	    }

	    for(i = j = 0;i < ncol;i += 2 + extra) {
	       if(i + 1 == ncol) {
		  msg_1s("Ignoring extra field at end of READ list: %s\n",
			 (yyvsp[(3) - (3)].t_list)->i_list[i]->str);
		  break;
	       }
	       extra = 0;
	       if(strchr((yyvsp[(3) - (3)].t_list)->i_list[i + 1]->str,'-') != NULL) {
		  char *ptr = (yyvsp[(3) - (3)].t_list)->i_list[i + 1]->str;
		  if(*ptr == '-') {	/* a single -ve number */
		     n1 = n2 = atoi(ptr);
		  } else {
		     n1 = atoi(ptr); while(*ptr != '-') ptr++;
		     ptr++;
		     if(isdigit(*ptr)) {
			n2 = atoi(ptr);
		     } else {
			msg_1s("Malformed column specification: %s\n",
			       (yyvsp[(3) - (3)].t_list)->i_list[i + 1]->str);
			n2 = 0;
		     }
		  }
	       } else if(i + 2 < ncol && (yyvsp[(3) - (3)].t_list)->i_list[i + 2]->str[0] == '-') {
		  n1 = atoi((yyvsp[(3) - (3)].t_list)->i_list[i + 1]->str);
		  n2 = atoi((yyvsp[(3) - (3)].t_list)->i_list[i + 2]->str + 1);
		  extra = 1;		/* we parsed an extra field */
	       } else {
		  n1 = n2 = atoi((yyvsp[(3) - (3)].t_list)->i_list[i + 1]->str);
	       }
	       
	       for(k = n1;k <= n2;k++) {
		  if(j >= size_cols) {	/* we need more space */
		     int l;
		     
		     if(sm_verbose > 2) {
			msg("Reallocating space in READ { ... }\n");
		     }
		     size_cols += 10;
		     if((cols = (int *)realloc((char *)cols,
					     size_cols*sizeof(int))) == NULL) {
			msg("Can't allocate space for columns list\n");
			free((char *)temp_s); free((char *)temp);
			break;
		     }
		     if((temp_s = (VECTOR *)realloc((char *)temp_s,
			   		  size_cols*sizeof(VECTOR))) == NULL) {
			msg("Can't reallocate storage for temp_s\n");
			free((char *)temp);
			free((char *)cols);
			cols = NULL;
			break;
		     }
		     free((char *)temp);
		     if((temp = (VECTOR **)malloc(size_cols*sizeof(VECTOR *)))
								     == NULL) {
			msg("Can't reallocate storage for temp\n");
			free((char *)cols);
			free((char *)temp_s);
			cols = NULL;
			break;
		     }
		     for(l = 0;l < size_cols;l++) {
			temp[l] = temp_s + l;
			temp[l]->name = temp[l]->descrip + 1;
		     }
		  }

		  temp[j]->type = parse_qualifier((yyvsp[(3) - (3)].t_list)->i_list[i + 1]->str);
		  if(n1 == n2) {
		     sprintf(temp[j]->descrip,"\001%s",(yyvsp[(3) - (3)].t_list)->i_list[i]->str);
		  } else {
		     if(temp[j]->type != VEC_FLOAT) {
			msg_1s("Multi-column vectors must be numeric (%s)\n",
			       (yyvsp[(3) - (3)].t_list)->i_list[i]->str);
			continue;
		     }
		     if(k == n1) {
			sprintf(temp[j]->descrip,"\001+%s",(yyvsp[(3) - (3)].t_list)->i_list[i]->str);
		     } else {
			sprintf(temp[j]->descrip,"\001|%s%d",
				(yyvsp[(3) - (3)].t_list)->i_list[i]->str,k - n1);
		     }
		  }
		  cols[j++] = k;
	       }
	       if(cols == NULL) {	/* realloc failed */
		  break;
	       }
	    }
	    freelist((yyvsp[(3) - (3)].t_list));
	    if(cols == NULL) {		/* realloc failed */
	       break;
	    }

	    nvec = read_column((yyvsp[(2) - (3)].intval),data_file,cols,temp,j,line_1,line_2,"");
	    free((char *)cols);

	    for(i = 0;i < nvec;i++) {
	       if(*temp[i]->name != '+') {
		  copy_vector(temp[i]->name,*temp[i]);
	       } else {
		  int nmerge;
		  VECTOR merged;

		  for(j = i + 1;j < nvec && *temp[j]->name == '|';j++)continue;
		  nmerge = j - i;
		  merged.type = temp[i]->type;
		  
		  if(vec_malloc(&merged,nmerge*temp[i]->dimen) != 0) {
		     msg_1s("Can't get space for %s\n",temp[i]->name + 1);
		  } else {
		     for(j = 0;j < nmerge;j++) {
			if(merged.type == VEC_FLOAT) {
			   for(k = 0;k < temp[i]->dimen;k++) {
			      merged.vec.f[j + nmerge*k] =
							 temp[i + j]->vec.f[k];
			   }
			} else if(merged.type == VEC_LONG) {
			   for(k = 0;k < temp[i]->dimen;k++) {
			      merged.vec.l[j + nmerge*k] =
							 temp[i + j]->vec.l[k];
			   }
			} else if(merged.type == VEC_STRING) {
			   for(k = 0;k < temp[i]->dimen;k++) {
			      strcpy(merged.vec.s.s[j + nmerge*k],
						      temp[i + j]->vec.s.s[k]);
			   }
			}
		     }
		     copy_vector(temp[i]->name + 1,merged);
		  }
		  
		  vec_free(temp[i++]);
		  while(i < nvec && *temp[i]->name == '|') {
		     vec_free(temp[i]);
		  }
	       }
	    }
	    free((char *)temp_s);
	    free((char *)temp);
	 }
    break;

  case 93:
/* #line 962 "control.y" */
    {
	    int i,*cols,nvec;
	    int null_fmt = ((yyvsp[(3) - (4)].charval)[0] == '\0') ? 1 : 0;
	    char *ptr;
	    VECTOR **vecs, *s_vecs;

	    (yyvsp[(2) - (4)].intval) = ((yyvsp[(2) - (4)].intval) == '!') ? 1 : 0;
	    if((yyvsp[(4) - (4)].t_list) == NULL) break;

	    if((vecs = (VECTOR **)malloc((yyvsp[(4) - (4)].t_list)->nitem*sizeof(VECTOR *)))== NULL ||
	       (s_vecs = (VECTOR *)malloc((yyvsp[(4) - (4)].t_list)->nitem*sizeof(VECTOR))) == NULL) {
	       msg("Can't allocate storage for vecs in READ string { ... }\n");
	       if(vecs != NULL) free((char *)vecs);
	       freelist((yyvsp[(4) - (4)].t_list));
	       break;
	    }
	    nvec = 0;
	    for(i = 0;i < (yyvsp[(4) - (4)].t_list)->nitem;i++) {
	       int vec_type = null_fmt ? VEC_FLOAT : VEC_NULL;
	       if(null_fmt && strcmp((yyvsp[(4) - (4)].t_list)->i_list[i]->str, ".") == 0) {
		  vecs[nvec++] = NULL; /* skip this column */
		  continue;
	       } else if(isdigit((yyvsp[(4) - (4)].t_list)->i_list[i]->str[0])) {
		  msg_1s("%s isn't a valid name for a vector\n",(yyvsp[(4) - (4)].t_list)->i_list[i]->str);
		  continue;
	       }
	       if((ptr = strchr((yyvsp[(4) - (4)].t_list)->i_list[i]->str, '.')) != NULL) {
		  if(null_fmt) {
		     vec_type = parse_qualifier(ptr);
		     *ptr = '\0';
		  } else {
		     msg_1s("%s isn't a valid name for a vector\n",
			    (yyvsp[(4) - (4)].t_list)->i_list[i]->str);
		     continue;
		  }
	       }
	       
	       vecs[nvec] = s_vecs + nvec;
	       vecs[nvec++]->name = (yyvsp[(4) - (4)].t_list)->i_list[i]->str; /* type will come from fmt*/
	       if(null_fmt) {
		  vecs[i]->type = vec_type;
	       }
	    }

	    if((cols = (int *)malloc(nvec*sizeof(int))) == NULL) {
	       msg("Can't allocate space for columns list\n");
	       break;
	    }
/*
 * Special format '' reads all specified vectors; columns to be skipped
 * are specified as ., which has become a NULL vector at this point
 */
	    if(null_fmt) {
	       int ii = 0;
	       for(i = 0; i < nvec; i++) {
		  if(vecs[i] != NULL) {
		     cols[ii] = i + 1;
		     vecs[ii++] = vecs[i];
		  }
	       }
	       nvec = ii;
	    } else {
	       cols[0] = 1;		/* not 0; used by read_column() */
	    }
	    nvec = read_column((yyvsp[(2) - (4)].intval),data_file,cols,vecs,nvec,line_1,line_2,(yyvsp[(3) - (4)].charval));

	    for(i = 0;i < nvec;i++) {
	       copy_vector(vecs[i]->name,*vecs[i]);
	    }
	    free((char *)cols); free((char *)vecs); free((char *)s_vecs);
            freelist((yyvsp[(4) - (4)].t_list));
	 }
    break;

  case 94:
/* #line 1035 "control.y" */
    {
	    int i, j;
	    int nvec;			/* number of vector's names */
	    int nextra;			/* number of extra vectors implied
					   by names like sky[0-3] */
	    VECTOR **vecs, *s_vecs;

	    if((yyvsp[(4) - (4)].t_list) == NULL) break;

	    nextra = nvec = 0;
	    if(strcmp((yyvsp[(3) - (4)].charval),"bycolumn") == 0) { /* a list of WORD id ... */
	       for(i = 0;i < (yyvsp[(4) - (4)].t_list)->nitem - 1;i += 2) {
		  if(isdigit((yyvsp[(4) - (4)].t_list)->i_list[i]->str[0])) {
		     msg_1s("%s isn't a valid name for a vector\n",
			    (yyvsp[(4) - (4)].t_list)->i_list[i]->str);
		  } else {
		     nvec++;
		  }
	       }
	       if(i != (yyvsp[(4) - (4)].t_list)->nitem) {
		  msg_1s("Ignoring junk at end of READ TABLE list: %s\n",
			 (yyvsp[(4) - (4)].t_list)->i_list[(yyvsp[(4) - (4)].t_list)->nitem - 1]->str);
	       }
	    } else {
	       for(i = 0;i < (yyvsp[(4) - (4)].t_list)->nitem;i++) {
		  if(isdigit((yyvsp[(4) - (4)].t_list)->i_list[i]->str[0])) {
		     msg_1s("%s isn't a valid name for a vector\n",
								(yyvsp[(4) - (4)].t_list)->i_list[i]->str);
		  } else {
		     char *val0;	/* pointer to "0" in "name[0-1]" */
		     char *val1;	/* pointer to "1" in "name[0-1]" */
		     if((val0 = strchr((yyvsp[(4) - (4)].t_list)->i_list[i]->str,'[')) != NULL) {
			val1 = ++val0;
			if(*val1 == '-') val1++;
			while(isdigit(*val1)) val1++;
			if(*val1 == '-') {
			   val1++;
			   if(isdigit(*val1)) {	/* OK, a range */
			      int n = atoi(val1) - atoi(val0);
			      if(n < 0 || nextra > 100) {
				 msg_1d("I don't believe that you want %d",
								   n + 1);
				 msg_1s(" vectors from %s\n",(yyvsp[(4) - (4)].t_list)->i_list[i]->str);
			      } else {
				 nextra += n;
			      }
			   }
			}
		     }
		     nvec++;
		  }
	       }
	    }

	    if((vecs = (VECTOR **)malloc((nvec + nextra)*sizeof(VECTOR *))) ==
									NULL ||
	       (s_vecs = (VECTOR *)malloc((nvec + nextra)*sizeof(VECTOR))) ==
									NULL) {
	       msg("Can't allocate storage for vecs in READ TABLE {...}\n");
	       if(vecs != NULL) free((char *)vecs);
	       freelist((yyvsp[(4) - (4)].t_list));
	       break;
	    }
	    for(j = 0;j < nvec + nextra;j++) {
	       vecs[j] = s_vecs + j;
	       vecs[j]->name = vecs[j]->descrip; /* use descrip as scratch */
	       *vecs[j]->name = '\0';
	    }
	    
	    if(strcmp((yyvsp[(3) - (4)].charval),"bycolumn") == 0) { /* a list of WORD id ... */
	       for(i = j = 0;i < (yyvsp[(4) - (4)].t_list)->nitem - 1;i += 2) {
		  if(isdigit((yyvsp[(4) - (4)].t_list)->i_list[i]->str[0])) {
		     continue;
		  }
		  vecs[j]->type = 0;	/* real type will come from table */
		  strncpy(vecs[j]->descrip,(yyvsp[(4) - (4)].t_list)->i_list[i]->str,VEC_DESCRIP_SIZE);
		  j++;
	       }
	    } else {
	       for(i = j = 0;i < (yyvsp[(4) - (4)].t_list)->nitem;i++) {
		  if(isdigit((yyvsp[(4) - (4)].t_list)->i_list[i]->str[0])) { /* we already warned them */
		     continue;
		  }
		  vecs[j]->type = 0;	/* real type will come from table */
		  strncpy(vecs[j]->descrip,(yyvsp[(4) - (4)].t_list)->i_list[i]->str,VEC_DESCRIP_SIZE);
		  j++;
	       }
	    }

	    nvec = read_table(data_file, subtable, vecs, nvec, nextra,
			      line_1, line_2, (yyvsp[(3) - (4)].charval), table_fmt);
	    for(i = 0;i < nvec;i++) {
	       copy_vector(vecs[i]->name, *vecs[i]);
	    }

	    free((char *)vecs); free((char *)s_vecs);
            freelist((yyvsp[(4) - (4)].t_list));
	 }
    break;

  case 95:
/* #line 1134 "control.y" */
    { restore((yyvsp[(2) - (2)].charval)); }
    break;

  case 96:
/* #line 1136 "control.y" */
    { mac_return(); }
    break;

  case 97:
/* #line 1138 "control.y" */
    { save((yyvsp[(2) - (2)].charval),0); }
    break;

  case 98:
/* #line 1140 "control.y" */
    {
	    int dimension,i;
	    VECTOR *temp;

	    dimension = (int)(atof((yyvsp[(7) - (7)].charval)) + 0.5);
	    i = parse_qualifier((yyvsp[(7) - (7)].charval));
	    if((temp = make_vector((yyvsp[(4) - (7)].charval),dimension,i)) != NULL) {
	       if(temp->type == VEC_FLOAT) {
		  for(i = 0;i < dimension;i++) {
		     temp->vec.f[i] = 0;
		  }
	       } else if(temp->type == VEC_LONG) {
		  for(i = 0;i < dimension;i++) {
		     temp->vec.l[i] = 0;
		  }
	       } else {
		  for(i = 0;i < dimension;i++) {
		     temp->vec.s.s[i][0] = '\0';
		  }
	       }
	    }
	 }
    break;

  case 99:
/* #line 1163 "control.y" */
    {
	    if(*mgets(word,CHARMAX) != '\0') {
	       set_help_vector((yyvsp[(3) - (3)].charval),&word[1]);
	    }
	 }
    break;

  case 100:
/* #line 1169 "control.y" */
    {
	    if(sm_verbose) {
	       msg("\"set image(expr,expr) = expr\" is obsolete; ");
	       msg("please say \"image[expr,expr]\"\n");
	    }
	    vec_set_image_from_index(&(yyvsp[(4) - (9)].vector),&(yyvsp[(6) - (9)].vector),&(yyvsp[(9) - (9)].vector));
	 }
    break;

  case 101:
/* #line 1177 "control.y" */
    { vec_set_image_from_index(&(yyvsp[(4) - (9)].vector),&(yyvsp[(6) - (9)].vector),&(yyvsp[(9) - (9)].vector)); }
    break;

  case 102:
/* #line 1179 "control.y" */
    { vec_set_image_from_index(NULL,&(yyvsp[(6) - (9)].vector),&(yyvsp[(9) - (9)].vector)); }
    break;

  case 103:
/* #line 1181 "control.y" */
    { vec_set_image_from_index(&(yyvsp[(4) - (9)].vector),NULL,&(yyvsp[(9) - (9)].vector)); }
    break;

  case 104:
/* #line 1183 "control.y" */
    { vec_set_image_from_index(NULL,NULL,&(yyvsp[(9) - (9)].vector)); }
    break;

  case 105:
/* #line 1185 "control.y" */
    { set_random((long)(yyvsp[(3) - (3)].floatval)); }
    break;

  case 106:
/* #line 1187 "control.y" */
    { make_local_vector((yyvsp[(2) - (3)].charval)); }
    break;

  case 107:
/* #line 1189 "control.y" */
    { (void)copy_vector((yyvsp[(2) - (4)].charval),(yyvsp[(4) - (4)].vector)); }
    break;

  case 108:
/* #line 1190 "control.y" */
    { make_local_vector((yyvsp[(3) - (3)].charval)); strcpy((yyval.charval), (yyvsp[(3) - (3)].charval)); }
    break;

  case 109:
/* #line 1191 "control.y" */
    { (void)copy_vector((yyvsp[(3) - (6)].charval),(yyvsp[(6) - (6)].vector)); }
    break;

  case 110:
/* #line 1193 "control.y" */
    {
	    VECTOR *x;

	    if((x = get_vector_ptr((yyvsp[(2) - (7)].charval))) == NULL) {
	       vec_free(&(yyvsp[(4) - (7)].vector)); vec_free(&(yyvsp[(7) - (7)].vector));
	       break;
	    }
	    vec_subscript(x,&(yyvsp[(4) - (7)].vector),&(yyvsp[(7) - (7)].vector));
	 }
    break;

  case 111:
/* #line 1203 "control.y" */
    {
	    VECTOR ind;			/* indices */
	    VECTOR *x;			/* vector $2 */

	    if(make_anon_vector(&ind, 0, VEC_LONG) != 0 ||
						 vec_do(&ind, (yyvsp[(4) - (9)].floatval), (yyvsp[(6) - (9)].floatval), 1) < 0) {
	       vec_free(&(yyvsp[(9) - (9)].vector));
	       break;
	    }
	    vec_convert_long(&ind);
	    
	    if((x = get_vector_ptr((yyvsp[(2) - (9)].charval))) == NULL) {
	       vec_free(&ind); vec_free(&(yyvsp[(9) - (9)].vector));
	       break;
	    }
	    if(x->dimen <= ind.vec.l[ind.dimen-1]) {
	       if(vec_realloc(x, ind.vec.l[ind.dimen-1] + 1) < 0) {
		  msg_1s("Can't extend %s\n", x->name);
		  vec_free(&ind); vec_free(&(yyvsp[(9) - (9)].vector));
		  break;
	       }
	    }
	    vec_subscript(x, &ind, &(yyvsp[(9) - (9)].vector));

	    vec_free(&ind); vec_free(&(yyvsp[(9) - (9)].vector));
	 }
    break;

  case 112:
/* #line 1230 "control.y" */
    {
	    int c;
	    
	    if((c = input()) != ' ') unput(c);
	    if(sm_verbose > 3) msg("Just the place for a snark!\n");
	    if(recurse_lvl == 0) {
	       break;
	    }
	    if(sm_interrupt && recurse_lvl > 1) {	/* keep on popping */
	       int save_interrupt = sm_interrupt;
	       sm_interrupt = 0;
	       start_line();		/* start a new line in tokens.c */
	       push("SNARK ",S_NORMAL);
	       sm_interrupt = save_interrupt;
	    }
	    recurse_lvl--;
	    return(1);
	 }
    break;

  case 113:
/* #line 1249 "control.y" */
    {
	    int dimen = 0,
	    	i,k,nvec,
	        n_float = 0,		/* number of float vectors */
	        n_long = 0,		/* number of long vectors */
	        n_string = 0,		/* number of string vectors */
		*sorted;		/* sorted indices */
	    VECTOR **temp;
	    VECTOR temp_f,temp_l,temp_s; /* temp vectors for rearranging */

	    if((nvec = (yyvsp[(2) - (2)].t_list)->nitem) == 0) {
	       freelist((yyvsp[(2) - (2)].t_list));
	    } else {
	       if((temp = malloc(nvec*sizeof(VECTOR *))) == NULL) {
		  msg("malloc returns NULL for SORT\n");
		  break;
	       }
	    }
	    

	    for(i = 0;i < nvec && !sm_interrupt;i++) {	/* get vectors */
	       if((temp[i] = get_vector_ptr((yyvsp[(2) - (2)].t_list)->i_list[i]->str)) == NULL) {
		  break;
	       }

	       if(temp[i]->type == VEC_FLOAT) {
		  n_float++;
	       } else if(temp[i]->type == VEC_LONG) {
		  n_long++;
	       } else if(temp[i]->type == VEC_STRING) {
		  n_string++;
	       } else {
		  msg_1d("Unknown vector type: %d",temp[i]->type);
		  msg_1s(" for vector %s\n",temp[i]->name);
	       }
	       if(i == 0) {
		  dimen = temp[0]->dimen;
	       } else if(temp[i]->dimen != dimen) {
		  msg("Vectors are different sizes\n");
		  break;
	       }
	    }
            freelist((yyvsp[(2) - (2)].t_list));
	    if(i < nvec) {
	       free((char *)temp);
	       break;
	    }

	    if(n_float == 1 && n_string == 0 && n_long == 0) { /*special case*/
	       sort_flt(temp[0]->vec.f, dimen);
	       free((char *)temp);
	       break;
	    }
	    
	    if((sorted = (int *)malloc((unsigned)dimen*sizeof(int))) == NULL) {
	       msg("malloc returns NULL for SORT\n");
	       free((char *)temp);
	       break;
	    }
	    if(n_float > 0) {
	       temp_f.type = VEC_FLOAT;
	       if(vec_malloc(&temp_f,dimen) == -1) {
		  msg("malloc returns NULL for SORT\n");
		  free((char *)temp);
		  free((char *)sorted);
		  break;
	       }
	    }
	    if(n_long > 0) {
	       temp_l.type = VEC_LONG;
	       if(vec_malloc(&temp_l,dimen) == -1) {
		  msg("malloc returns NULL for SORT\n");
		  free((char *)temp);
		  free((char *)sorted);
		  vec_free(&temp_f);
		  break;
	       }
	    }
	    if(n_string > 0) {
	       temp_s.type = VEC_STRING;
	       if(vec_malloc(&temp_s,dimen) == -1) {
		  msg("malloc returns NULL for SORT\n");
		  free((char *)temp);
		  free((char *)sorted);
		  vec_free(&temp_l);
		  vec_free(&temp_f);
		  break;
	       }
	    }
	    if(temp[0]->type == VEC_FLOAT) {
	       sort_flt_inds(temp[0]->vec.f,sorted,dimen);
	    } else if(temp[0]->type == VEC_LONG) {
	       sort_long_inds(temp[0]->vec.l,sorted,dimen);
	    } else if(temp[0]->type == VEC_STRING) {
	       sort_str_inds(temp[0]->vec.s.s,sorted,dimen);
	    } else {
	       msg("You can't get here. SORT.\n");
	    }

	    for(k = 0;!sm_interrupt && k < nvec;k++) {	/* for each vector */
	       if(temp[k]->type == VEC_FLOAT) {
		  (void)memcpy((Void *)temp_f.vec.f,
			     (Const Void *)temp[k]->vec.f,dimen*sizeof(REAL));

		  for(i = 0;i < dimen;i++) {		/* restore it sorted */
		     temp[k]->vec.f[i] = temp_f.vec.f[sorted[i]];
		  }
	       } else if(temp[k]->type == VEC_LONG) {
		  (void)memcpy((Void *)temp_l.vec.l,
			     (Const Void *)temp[k]->vec.l,dimen*sizeof(LONG));

		  for(i = 0;i < dimen;i++) {		/* restore it sorted */
		     temp[k]->vec.l[i] = temp_l.vec.l[sorted[i]];
		  }
	       } else {
		  (void)memcpy((Void *)temp_s.vec.s.s_s,
			  (Const Void *)temp[k]->vec.s.s_s,dimen*VEC_STR_SIZE);

		  for(i = 0;i < dimen;i++) {		/* restore it sorted */
		     strcpy(temp[k]->vec.s.s[i],temp_s.vec.s.s[sorted[i]]);
		  }
	       }
	    }

	    free((char *)temp);
	    free((char *)sorted);
	    if(n_float > 0) vec_free(&temp_f);
	    if(n_long > 0) vec_free(&temp_l);
	    if(n_string > 0) vec_free(&temp_s);
	 }
    break;

  case 114:
/* #line 1380 "control.y" */
    { (void)spline((yyvsp[(2) - (5)].charval),(yyvsp[(3) - (5)].charval),(yyvsp[(4) - (5)].charval),(yyvsp[(5) - (5)].charval)); }
    break;

  case 115:
/* #line 1382 "control.y" */
    { (void)sm_deltable(); }
    break;

  case 116:
/* #line 1384 "control.y" */
    {
	    (void)unput('\n');
	    
 	    line_1 = line_2 = 0;	/* no lines specified */
	    subtable = (yyvsp[(2) - (3)].intval);
	 }
    break;

  case 117:
/* #line 1391 "control.y" */
    {
	    FILE *fil;
	    
	    line_1 = line_2 = 0;	/* no lines specified */
	    if((fil = fopen((yyvsp[(4) - (4)].charval),"r")) == NULL) {
	       msg_1s("Can't open %s\n",(yyvsp[(4) - (4)].charval));
	    } else {
	       (void)fclose(fil);
	       set_data_file((yyvsp[(4) - (4)].charval));
	       
	       read_table_header((yyvsp[(4) - (4)].charval),(yyvsp[(2) - (4)].intval));
	    }
	    (void)strncpy(data_file,(yyvsp[(4) - (4)].charval),CHARMAX); /* the file to read data */
	    (void)strncpy(table_fmt,(yyvsp[(3) - (4)].charval),CHARMAX);
	    
	    subtable = (yyvsp[(2) - (4)].intval);
	 }
    break;

  case 118:
/* #line 1409 "control.y" */
    { sm_ticksize( (yyvsp[(2) - (5)].floatval), (yyvsp[(3) - (5)].floatval), (yyvsp[(4) - (5)].floatval), (yyvsp[(5) - (5)].floatval)); }
    break;

  case 119:
/* #line 1411 "control.y" */
    { (void)set_term_type((yyvsp[(2) - (3)].charval),(yyvsp[(3) - (3)].intval)); }
    break;

  case 120:
/* #line 1413 "control.y" */
    {
	    static int abort_depth = 0;	/* depth of nesting abort handlers */
	    char *ptr;
	    if((ptr = mgets(word,CHARMAX)) == NULL || *ptr == '\0') {
	       ptr = "USER ABORT";
	    } else {
	       ptr++;			/* skip initial space */
	    }

	    if(abort_depth++ == 100) {
	       msg("abort handler depth too great (100 max)\n");
	       abort_depth = 0;
	       start_line();

	       msg_1s("%s\n",ptr);
	       save_str("<user abort>");
	       YYERROR;
	    }

	    if(get_macro("abort_handler",
			 (int *)NULL,(int *)NULL,(int *)NULL) != NULL) {
	       push("\n",S_NORMAL);
	       push(ptr,S_NORMAL);
	       push("abort_handler ",S_NORMAL);
	       if(sm_verbose > 2) {
		  msg_1s(">> macro : abort_handler %s\n",ptr);
	       }
	       (void)yyparse();
	       push("\n",S_NORMAL);
	    } else {
	       start_line();
	       msg_1s("%s\n",ptr);
	       save_str("<user abort>");
	       YYERROR;
	    }
	 }
    break;

  case 121:
/* #line 1450 "control.y" */
    {
	     word[1] = '\0';
	     if(mgets(word,CHARMAX) != NULL) {
	        userfn(&(yyvsp[(2) - (2)].intval),&word[1]);
	     }
	  }
    break;

  case 122:
/* #line 1457 "control.y" */
    {
	    if((yyvsp[(2) - (2)].floatval) < 0) {
#if defined(YYDEBUG)
	       yydebug = 1 - yydebug;	/* toggle yydebug */
#endif
	       (yyvsp[(2) - (2)].floatval) = -(yyvsp[(2) - (2)].floatval);
	    }
	    sm_verbose = (yyvsp[(2) - (2)].floatval);
	 }
    break;

  case 123:
/* #line 1467 "control.y" */
    { sm_set_viewpoint((yyvsp[(2) - (4)].floatval),(yyvsp[(3) - (4)].floatval),(yyvsp[(4) - (4)].floatval)); }
    break;

  case 124:
/* #line 1469 "control.y" */
    {
	    char *cmd;
	    char *fmt = "IF(%s) { %s } ELSE { BREAK }\n ";
	    int len2, len4;

	    len2 = strlen((yyvsp[(2) - (5)].strval).start); (yyvsp[(2) - (5)].strval).start[len2 - 1] = '\0'; len2--;
	    len4 = strlen((yyvsp[(4) - (5)].strval).start); (yyvsp[(4) - (5)].strval).start[len4 - 1] = '\0'; len4--;

	    if((cmd = malloc(len2 + len4 + (strlen(fmt) - 4) + 1)) == NULL) {
	       msg("Can't allocate space for while loop\n");
	       free((char *)(yyvsp[(2) - (5)].strval).start); free((char *)(yyvsp[(4) - (5)].strval).start);
	       break;
	    }

	    sprintf(cmd,fmt,(yyvsp[(2) - (5)].strval).start,(yyvsp[(4) - (5)].strval).start);
	    push(cmd,S_WHILE);

	    free((char *)(yyvsp[(2) - (5)].strval).start); free((char *)(yyvsp[(4) - (5)].strval).start);
	 }
    break;

  case 125:
/* #line 1489 "control.y" */
    { end_while(); }
    break;

  case 126:
/* #line 1491 "control.y" */
    { sm_window( (yyvsp[(2) - (5)].intval), (yyvsp[(3) - (5)].intval), (yyvsp[(4) - (5)].intval), (yyvsp[(5) - (5)].intval), (yyvsp[(4) - (5)].intval), (yyvsp[(5) - (5)].intval)); }
    break;

  case 127:
/* #line 1493 "control.y" */
    { sm_window( (yyvsp[(2) - (7)].intval), (yyvsp[(3) - (7)].intval), (yyvsp[(4) - (7)].intval), (yyvsp[(5) - (7)].intval), (yyvsp[(4) - (7)].intval), (yyvsp[(7) - (7)].intval)); }
    break;

  case 128:
/* #line 1495 "control.y" */
    { sm_window( (yyvsp[(2) - (7)].intval), (yyvsp[(3) - (7)].intval), (yyvsp[(4) - (7)].intval), (yyvsp[(7) - (7)].intval), (yyvsp[(6) - (7)].intval), (yyvsp[(7) - (7)].intval)); }
    break;

  case 129:
/* #line 1497 "control.y" */
    { sm_window( (yyvsp[(2) - (9)].intval), (yyvsp[(3) - (9)].intval), (yyvsp[(4) - (9)].intval), (yyvsp[(7) - (9)].intval), (yyvsp[(6) - (9)].intval), (yyvsp[(9) - (9)].intval)); }
    break;

  case 130:
/* #line 1499 "control.y" */
    {
            if(execute((yyvsp[(1) - (1)].charval)) == 0) {	/* it's a macro */
	       start_line();		/* start a new line in tokens.c */
	       if(sm_verbose > 2) msg_1s(">> macro : %s\n",(yyvsp[(1) - (1)].charval));
	    } else {
	       if(!strcmp((yyvsp[(1) - (1)].charval),"\n")) {	/* probably in quotes by mistake */
		  msg("\"\\n\" is not a valid macro\n");
		  in_quote = noexpand = 0;
		  YYERROR;
	       } else {
		  if(get_macro("macro_error_handler",
			       (int *)NULL,(int *)NULL,(int *)NULL) == NULL) {
		     msg_1s("%s is not a macro\n",(yyvsp[(1) - (1)].charval));
		  } else {
		     static char name[60];
		     strcpy(name,(yyvsp[(1) - (1)].charval));
		     noexpand = 0;	/* we must be able to recognise the
					   error handler */
		     push(name,S_NORMAL);
		     push("macro_error_handler NOT_FOUND ",S_NORMAL);
		     if(sm_verbose > 2) {
			msg_1s(">> WORD : %s\n",name);
			msg(">> macro : macro_error_handler NOT_FOUND\n");
		     }
		     (void)yyparse();
		     push("\n",S_NORMAL);
		  }
	       }
	       break;
	    }
         }
    break;

  case 131:
/* #line 1531 "control.y" */
    { (void)read_history_macro((yyvsp[(3) - (3)].charval)); }
    break;

  case 132:
/* #line 1533 "control.y" */
    { write_image((yyvsp[(3) - (3)].charval)); }
    break;

  case 133:
/* #line 1535 "control.y" */
    {
	    (void)mgets(buff,MACROSIZE);
	    msg_1s("%s\n",&buff[*buff == '\0' ? 0 : 1]); /* skip ' ' */
         }
    break;

  case 134:
/* #line 1540 "control.y" */
    {
	    int append = ((yyvsp[(3) - (5)].intval) == '+');  
	    int dimen = 0, i, nvec;
	    Const VECTOR **temp;

	    if(graph_mode) { graph_mode = 0; IDLE(); }

	    if(!append && would_clobber((yyvsp[(4) - (5)].charval))) {
	       break;
	    }

	    nvec = (yyvsp[(5) - (5)].t_list)->nitem;
	    if((temp = (Const VECTOR **)malloc(nvec*sizeof(VECTOR *))) == NULL){
	       msg("Can't allocate storage for temp\n");
	       break;
	    }

	    for(i = 0;i < nvec && !sm_interrupt;i++) {	/* get vectors */
	       if((temp[i] = get_vector_ptr((yyvsp[(5) - (5)].t_list)->i_list[i]->str)) == NULL) {
		  break;
	       }
	       if(i == 0) {
		  dimen = temp[0]->dimen;
	       } else if(temp[i]->dimen != dimen) {
		  if(sm_verbose > 1)
		     msg("Vectors are different sizes\n");
		  if(dimen < temp[i]->dimen) {
		     dimen = temp[i]->dimen;
		  }
	       }
	    }
	    if(i < nvec) {
	       free((char *)temp);
               freelist((yyvsp[(5) - (5)].t_list));
	       break;
	    }

	    write_table((yyvsp[(4) - (5)].charval), append ? "a" : "w", nvec, temp, dimen);
	    
	    free((char *)temp);
            freelist((yyvsp[(5) - (5)].t_list));
	 }
    break;

  case 135:
/* #line 1583 "control.y" */
    {
	    static char file[80] = "";	/* name of file */
	    FILE *fil;

	    (void)mgets(buff,MACROSIZE);
	    if((yyvsp[(2) - (3)].intval) == '+') {		/* treat file as old and append */
	       (void)strcpy(file,(yyvsp[(3) - (3)].charval));
	    }
	    if(strcmp(file,(yyvsp[(3) - (3)].charval)) == 0) {	/* append to old file */
	       if((fil = fopen(file,"a")) == NULL) {
		  msg_1s("Can't reopen %s\n",file);
		  break;
	       }
	    } else {
	       if((fil = fopen((yyvsp[(3) - (3)].charval),"w")) == NULL) {
		  fprintf(stderr,"Can't open %s\n",(yyvsp[(3) - (3)].charval));
		  break;
	       }
	       (void)strcpy(file,(yyvsp[(3) - (3)].charval));
	    }
	    fprintf(fil,"%s\n",&buff[*buff == '\0' ? 0 : 1]);	/* skip ' ' */
	    fclose(fil);
         }
    break;

  case 136:
/* #line 1609 "control.y" */
    {
	    if(((yyval.t_list) = getlist((TOK_LIST *)NULL)) == NULL) {
	       break;
	    }
	 }
    break;

  case 137:
/* #line 1615 "control.y" */
    {
	    if(((yyval.t_list) = getlist((TOK_LIST *)NULL)) == NULL) {
	       break;
	    }

	    (yyval.t_list)->i_type[(yyval.t_list)->nitem] = TYPE_WORD;
	    (void)strncpy((yyval.t_list)->i_list[(yyval.t_list)->nitem++]->str,(yyvsp[(1) - (1)].charval),CHARMAX);
	 }
    break;

  case 138:
/* #line 1624 "control.y" */
    {
	    if((yyvsp[(1) - (3)].t_list) == NULL) {		/* couldn't get space */
	       (yyval.t_list) = NULL;
	       break;
	    }
            if((yyvsp[(1) - (3)].t_list)->nitem >= (yyvsp[(1) - (3)].t_list)->nmax) {	/* get some more space */
	       (yyval.t_list) = getlist((yyvsp[(1) - (3)].t_list));
	    } else {
	       (yyval.t_list) = (yyvsp[(1) - (3)].t_list);
	    }

	    (yyval.t_list)->i_type[(yyval.t_list)->nitem] = TYPE_WORD;
	    (void)strncpy((yyval.t_list)->i_list[(yyval.t_list)->nitem++]->str,(yyvsp[(3) - (3)].charval),CHARMAX);
	 }
    break;

  case 139:
/* #line 1639 "control.y" */
    {
	    if(((yyval.t_list) = getlist((TOK_LIST *)NULL)) == NULL) {
	       break;
	    }

	    (yyval.t_list)->i_type[(yyval.t_list)->nitem] = TYPE_VECTOR;
	    (yyval.t_list)->i_list[(yyval.t_list)->nitem++]->vec = (yyvsp[(1) - (1)].vector);
	 }
    break;

  case 140:
/* #line 1648 "control.y" */
    {
	    if((yyvsp[(1) - (3)].t_list) == NULL) {		/* couldn't get space */
	       (yyval.t_list) = NULL;
	       break;
	    }
            if((yyvsp[(1) - (3)].t_list)->nitem >= (yyvsp[(1) - (3)].t_list)->nmax) {	/* get some more space */
	       (yyval.t_list) = getlist((yyvsp[(1) - (3)].t_list));
	    } else {
	       (yyval.t_list) = (yyvsp[(1) - (3)].t_list);
	    }

	    (yyval.t_list)->i_type[(yyval.t_list)->nitem] = TYPE_VECTOR;
	    (yyval.t_list)->i_list[(yyval.t_list)->nitem++]->vec = (yyvsp[(3) - (3)].vector);
	 }
    break;

  case 141:
/* #line 1665 "control.y" */
    {
	    int i,j,
	    type = VEC_NULL;		/* type of vector */

	    if((yyvsp[(1) - (1)].t_list) == NULL) break;
	    for(i = 0; i < (yyvsp[(1) - (1)].t_list)->nitem; i++) { /* find type of vector */
	       if(i > 100) {		/* only check first fewish items */
		  break;
	       }

	       if((yyvsp[(1) - (1)].t_list)->i_list[i]->str[0] == '\n' && (yyvsp[(1) - (1)].t_list)->i_list[i]->str[1] == '\0') {
		  continue;			/* skip \n */
	       }
	       
	       switch (num_or_word((yyvsp[(1) - (1)].t_list)->i_list[i]->str)) {
		case 1: if(type == VEC_NULL) {type = VEC_LONG;} break;
		case 2: type = VEC_FLOAT; break;
		default: type = VEC_STRING; break;
	       }
	       if(type == VEC_STRING) {
		  break;		/* if any are string, all are */
	       }
	    }
	    
	    if(make_anon_vector(&(yyval.vector),(yyvsp[(1) - (1)].t_list)->nitem,type) != 0) {
	       (yyval.vector).type = VEC_NULL;
	       j = 0;
	    } else {
	       for(i = j = 0;i < (yyvsp[(1) - (1)].t_list)->nitem;i++) {
		  if((yyvsp[(1) - (1)].t_list)->i_list[i]->str[0] == '\n' && (yyvsp[(1) - (1)].t_list)->i_list[i]->str[1] == '\0') {
		     continue;			/* skip \n */
		  }
		  if(type == VEC_LONG) {
		     (yyval.vector).vec.l[j++] = atoi((yyvsp[(1) - (1)].t_list)->i_list[i]->str);
		  } else if(type == VEC_FLOAT) {
		     (yyval.vector).vec.f[j++] = atof2((yyvsp[(1) - (1)].t_list)->i_list[i]->str);
		  } else {
		     (void)strncpy((yyval.vector).vec.s.s[j++],(yyvsp[(1) - (1)].t_list)->i_list[i]->str,VEC_STR_SIZE);
		  }
	       }
	    }
	    (yyval.vector).dimen = j;		/* don't bother to realloc storage */
            freelist((yyvsp[(1) - (1)].t_list));
	 }
    break;

  case 142:
/* #line 1710 "control.y" */
    { vec_concat(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 143:
/* #line 1712 "control.y" */
    {
	    if((yyvsp[(1) - (1)].charval)[0] == '0') {		/* may be a hex or octal constant */
	       LONG val;
	       if((val = atof2((yyvsp[(1) - (1)].charval))) == 0) {
		  if(strncmp((yyvsp[(1) - (1)].charval),"0x0", 3) == 0) { /* the only non-word == 0 */
		     char *ptr = (yyvsp[(1) - (1)].charval) + 3;
		     while(*ptr == '0') ptr++; /* 0x0000 is allowed */
		     if(*ptr != '\0') {
			msg_1s("Illegal vector name: %s\n",(yyvsp[(1) - (1)].charval));
			make_anon_vector(&(yyval.vector), 0, VEC_FLOAT);
			(yyval.vector) = *zero_vec();
			break;
		     }
		  } else {
		     msg_1s("Illegal vector name: %s\n",(yyvsp[(1) - (1)].charval));
		     make_anon_vector(&(yyval.vector), 0, VEC_FLOAT);
		     (yyval.vector) = *zero_vec();
		     break;
		  }
	       }
	       (void)vec_ivalue(&(yyval.vector),val);
	    } else if(get_vector((yyvsp[(1) - (1)].charval),&(yyval.vector)) < 0) {
	       break;
	    }
	 }
    break;

  case 144:
/* #line 1738 "control.y" */
    {
	    if(make_anon_vector(&(yyval.vector),1,VEC_STRING) == 0) {
	       (void)strncpy((yyval.vector).vec.s.s[0],(yyvsp[(1) - (1)].charval),VEC_STR_SIZE);
	    } else {
	       (yyval.vector).type = VEC_NULL;
	    }
	 }
    break;

  case 145:
/* #line 1746 "control.y" */
    {
	    char *mtext;		/* body of macro */
	    int i,narg_min,narg_max;
	    VECTOR tmp;

	    if((mtext = get_macro((yyvsp[(1) - (4)].charval),&narg_min,&narg_max,(int *)NULL)) ==
									NULL) {
	       msg_1s("Macro %s is not defined\n",(yyvsp[(1) - (4)].charval));
	       (yyval.vector).type = VEC_NULL;
	       vec_free(&(yyval.vector));
	       freelist((yyvsp[(3) - (4)].t_list));
	       break;
	    } else if((yyvsp[(3) - (4)].t_list)->nitem < narg_min || (yyvsp[(3) - (4)].t_list)->nitem > narg_max) {
	       msg_1s("Macro %s expects ",(yyvsp[(1) - (4)].charval));
	       msg_1d("%d <= narg <= ",narg_min);
	       msg_1d("%d, ",narg_max);
	       msg_1d("%d provided\n",(yyvsp[(3) - (4)].t_list)->nitem);
	       (yyval.vector).type = VEC_NULL; (yyval.vector).dimen = 0;
	       (yyval.vector).name = "(macro())";
	       freelist((yyvsp[(3) - (4)].t_list));
	       break;
	    }

	    push("\nSNARK",S_NORMAL);
	    push_mstack((yyvsp[(1) - (4)].charval),0,0,0);
	    
	    for(i = 0;i < (yyvsp[(3) - (4)].t_list)->nitem;i++) {
	       if((yyvsp[(3) - (4)].t_list)->i_type[i] == TYPE_WORD) {
		  if(strncmp((yyvsp[(3) - (4)].t_list)->i_list[i]->str,"__",2) == 0 &&
					 get_vector((yyvsp[(3) - (4)].t_list)->i_list[i]->str,&tmp) >= 0) {
		     sprintf(buff,"__%s_arg%d",(yyvsp[(1) - (4)].charval), i + 1);
		     make_local_vector(buff);
		     (void)copy_vector(buff,tmp);
		     add_marg(i + 1,buff);
		  } else {
		     add_marg(i + 1,(yyvsp[(3) - (4)].t_list)->i_list[i]->str);
		  }
	       } else if((yyvsp[(3) - (4)].t_list)->i_type[i] == TYPE_VECTOR) {
		  if((yyvsp[(3) - (4)].t_list)->i_list[i]->vec.dimen == 1 &&
		     strcmp((yyvsp[(3) - (4)].t_list)->i_list[i]->vec.name,"(scalar)") == 0) {
		     if((yyvsp[(3) - (4)].t_list)->i_list[i]->vec.type == VEC_FLOAT) {
			sprintf(buff,"%.10g",(yyvsp[(3) - (4)].t_list)->i_list[i]->vec.vec.f[0]);
		     } else if((yyvsp[(3) - (4)].t_list)->i_list[i]->vec.type == VEC_LONG) {
			char *dl[] = { "", "%d", "%ld" };	/* do we need a %l format? */
			assert(sizeof(LONG)/4 < 3);
			sprintf(buff,dl[sizeof(LONG)/4],(yyvsp[(3) - (4)].t_list)->i_list[i]->vec.vec.l[0]);
		     } else if((yyvsp[(3) - (4)].t_list)->i_list[i]->vec.type == VEC_STRING) {
			strcpy(buff,(yyvsp[(3) - (4)].t_list)->i_list[i]->vec.vec.s.s[0]);
		     } else {
			strcpy(buff,"(null)");
		     }
		  } else {
		     sprintf(buff,"__%s_arg%d",(yyvsp[(1) - (4)].charval), i + 1);
		     make_local_vector(buff);
		     (void)copy_vector(buff,(yyvsp[(3) - (4)].t_list)->i_list[i]->vec);
		  }
		  add_marg(i + 1,buff);
	       } else {
		  msg_1d("Unknown type on t_list: %d\n",(yyvsp[(3) - (4)].t_list)->i_type[i]);
		  add_marg(i + 1,"unknown");
	       }
	    }
	    freelist((yyvsp[(3) - (4)].t_list));
	    
	    recurse_lvl++;
	    push(mtext,S_MACRO);
	    yyparse();			/* execute macro _now_ */
	    get_vector((yyvsp[(1) - (4)].charval),&(yyval.vector));
	    free_vector((yyvsp[(1) - (4)].charval));
	 }
    break;

  case 146:
/* #line 1817 "control.y" */
    {
	    int i,j;
	    VECTOR *temp;

	    if((yyvsp[(3) - (4)].vector).type == VEC_STRING) {
	       msg_1s("Vector %s is not arithmetic\n",(yyvsp[(3) - (4)].vector).name);
	       (yyval.vector).type = VEC_NULL;
	       vec_free(&(yyvsp[(3) - (4)].vector));
	       (yyval.vector).name = "(undefined[])";
	       break;
	    }

	    vec_convert_long(&(yyvsp[(3) - (4)].vector));

	    if((temp = get_vector_ptr((yyvsp[(1) - (4)].charval))) == NULL ||
			make_anon_vector(&(yyval.vector),(yyvsp[(3) - (4)].vector).dimen,temp->type) != 0) {
	       (yyval.vector).type = VEC_NULL;
	       vec_free(&(yyval.vector));
	       (yyval.vector).name = "(undefined[])";
	       vec_free(&(yyvsp[(3) - (4)].vector));
	       break;
	    }

	    for(j = 0;j < (yyvsp[(3) - (4)].vector).dimen;j++) {
	       i = (yyvsp[(3) - (4)].vector).vec.l[j];
	       if(i >= 0 && i < temp->dimen) {
		  if(temp->type == VEC_FLOAT) {
		     (yyval.vector).vec.f[j] = temp->vec.f[i];
		  } else if(temp->type == VEC_LONG) {
		     (yyval.vector).vec.l[j] = temp->vec.l[i];
		  } else {
		     strcpy((yyval.vector).vec.s.s[j],temp->vec.s.s[i]);
		  }
	       } else {
		  msg_1d("Subscript %d ",i);
		  msg_1s("for %s is out of range ",(yyvsp[(1) - (4)].charval));
		  msg_1d("[0,%d]\n",temp->dimen-1);
		  if((yyval.vector).type == VEC_STRING) {
		     (yyval.vector).vec.s.s[j][0] = '\0';
		  } else if((yyval.vector).type == VEC_FLOAT) {
		     (yyval.vector).vec.f[j] = 0;
		  } else if((yyval.vector).type == VEC_LONG) {
		     (yyval.vector).vec.l[j] = 0;
		  }
	       }
	    }
	    vec_free(&(yyvsp[(3) - (4)].vector));
	 }
    break;

  case 147:
/* #line 1866 "control.y" */
    { (yyval.vector) = (yyvsp[(2) - (3)].vector); }
    break;

  case 148:
/* #line 1868 "control.y" */
    {
	    VECTOR zero;		/* scalar with value 0 */

	    (void)vec_value(&zero,0.0);	/* set value of zero */
	    vec_subtract(&zero,&(yyvsp[(2) - (2)].vector),&(yyval.vector));
	 }
    break;

  case 149:
/* #line 1875 "control.y" */
    { vec_ternary(&(yyvsp[(1) - (5)].vector),&(yyvsp[(3) - (5)].vector),&(yyvsp[(5) - (5)].vector),&(yyval.vector)); }
    break;

  case 150:
/* #line 1877 "control.y" */
    { vec_abs(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 151:
/* #line 1879 "control.y" */
    { vec_acos(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 152:
/* #line 1881 "control.y" */
    { vec_asin(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 153:
/* #line 1883 "control.y" */
    { vec_atan(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 154:
/* #line 1885 "control.y" */
    { vec_atan2(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 155:
/* #line 1887 "control.y" */
    { vec_cos(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 156:
/* #line 1889 "control.y" */
    {
	    (yyval.vector).type = VEC_FLOAT;
	    vec_ctype(&(yyval.vector));
	 }
    break;

  case 157:
/* #line 1894 "control.y" */
    {
	    (yyval.vector).type = VEC_STRING;
	    vec_ctype(&(yyval.vector));
	 }
    break;

  case 158:
/* #line 1899 "control.y" */
    {
	    if(make_anon_vector(&(yyval.vector),0,VEC_NULL) != 0) {
	       break;
	    }
	    if(vec_do(&(yyval.vector), (yyvsp[(3) - (6)].floatval), (yyvsp[(5) - (6)].floatval), 1) < 0) {
	       break;
	    }
	 }
    break;

  case 159:
/* #line 1908 "control.y" */
    {
	    if(make_anon_vector(&(yyval.vector),0,VEC_NULL) != 0) {
	       break;
	    }
	    if(vec_do(&(yyval.vector), (yyvsp[(3) - (8)].floatval), (yyvsp[(5) - (8)].floatval), (yyvsp[(7) - (8)].floatval)) < 0) {
	       break;
	    }
	 }
    break;

  case 160:
/* #line 1917 "control.y" */
    { vec_exp(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 161:
/* #line 1919 "control.y" */
    { vec_add(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 162:
/* #line 1921 "control.y" */
    { vec_subtract(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 163:
/* #line 1923 "control.y" */
    { vec_multiply(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 164:
/* #line 1925 "control.y" */
    { vec_divide(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 165:
/* #line 1927 "control.y" */
    { vec_power(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 166:
/* #line 1929 "control.y" */
    { vec_mod(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 167:
/* #line 1931 "control.y" */
    { vec_bitand(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 168:
/* #line 1933 "control.y" */
    { vec_bitor(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 169:
/* #line 1935 "control.y" */
    { vec_bitshift(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector), 1); }
    break;

  case 170:
/* #line 1937 "control.y" */
    { vec_bitshift(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector), 0); }
    break;

  case 171:
/* #line 1939 "control.y" */
    { vec_eq(&(yyvsp[(1) - (4)].vector),&(yyvsp[(4) - (4)].vector),&(yyval.vector)); }
    break;

  case 172:
/* #line 1941 "control.y" */
    {
	    VECTOR zero;		/* scalar with value 0 */

	    (void)vec_value(&zero,0.0);	/* set value of zero */
	    vec_eq(&zero,&(yyvsp[(2) - (2)].vector),&(yyval.vector));
	 }
    break;

  case 173:
/* #line 1948 "control.y" */
    { vec_ne(&(yyvsp[(1) - (4)].vector),&(yyvsp[(4) - (4)].vector),&(yyval.vector)); }
    break;

  case 174:
/* #line 1950 "control.y" */
    { vec_and(&(yyvsp[(1) - (4)].vector),&(yyvsp[(4) - (4)].vector),&(yyval.vector)); }
    break;

  case 175:
/* #line 1952 "control.y" */
    { vec_or(&(yyvsp[(1) - (4)].vector),&(yyvsp[(4) - (4)].vector),&(yyval.vector)); }
    break;

  case 176:
/* #line 1954 "control.y" */
    { vec_gt(&(yyvsp[(1) - (3)].vector),&(yyvsp[(3) - (3)].vector),&(yyval.vector)); }
    break;

  case 177:
/* #line 1956 "control.y" */
    { vec_ge(&(yyvsp[(1) - (4)].vector),&(yyvsp[(4) - (4)].vector),&(yyval.vector)); }
    break;

  case 178:
/* #line 1958 "control.y" */
    { vec_gt(&(yyvsp[(3) - (3)].vector),&(yyvsp[(1) - (3)].vector),&(yyval.vector)); }
    break;

  case 179:
/* #line 1960 "control.y" */
    { vec_ge(&(yyvsp[(4) - (4)].vector),&(yyvsp[(1) - (4)].vector),&(yyval.vector)); }
    break;

  case 180:
/* #line 1962 "control.y" */
    { vec_float(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 181:
/* #line 1964 "control.y" */
    { vec_cast_float(&(yyvsp[(3) - (4)].vector), &(yyval.vector)); }
    break;

  case 182:
/* #line 1966 "control.y" */
    { vec_gamma(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 183:
/* #line 1968 "control.y" */
    { vec_hist(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 184:
/* #line 1970 "control.y" */
    { vec_interp(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 185:
/* #line 1972 "control.y" */
    { vec_get_image_from_index(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 186:
/* #line 1974 "control.y" */
    { vec_get_image_from_index(NULL,&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 187:
/* #line 1976 "control.y" */
    { vec_get_image_from_index(&(yyvsp[(3) - (6)].vector),NULL,&(yyval.vector)); }
    break;

  case 188:
/* #line 1978 "control.y" */
    { vec_get_image_from_index(NULL,NULL,&(yyval.vector)); }
    break;

  case 189:
/* #line 1980 "control.y" */
    { vec_index(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 190:
/* #line 1982 "control.y" */
    { vec_int(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 191:
/* #line 1984 "control.y" */
    { vec_length(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 192:
/* #line 1986 "control.y" */
    { vec_lg(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 193:
/* #line 1988 "control.y" */
    { vec_ln(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 194:
/* #line 1990 "control.y" */
    {
	    if(number_is_int) {
	       (void)vec_ivalue(&(yyval.vector), intval);
	    } else {
	       (void)vec_value(&(yyval.vector), (yyvsp[(1) - (1)].floatval));
	    } 
	 }
    break;

  case 195:
/* #line 1998 "control.y" */
    { (void)vec_value(&(yyval.vector),Pi); }
    break;

  case 196:
/* #line 2000 "control.y" */
    { vec_random((int)(yyvsp[(3) - (4)].floatval),&(yyval.vector)); }
    break;

  case 197:
/* #line 2002 "control.y" */
    { vec_sin(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 198:
/* #line 2004 "control.y" */
    {
	    int dimen = (yyvsp[(3) - (4)].vector).dimen;
	    int i;
	    
	    if((yyvsp[(3) - (4)].vector).type == VEC_LONG) {
	       if(sm_verbose > 1) {
		  msg_1s("You cannot sort on an integer vector %s; converting to arithmetic\n",
			 (yyvsp[(3) - (4)].vector).name);
	       }
	       vec_convert_float(&(yyvsp[(3) - (4)].vector));
	    }
	    if((yyvsp[(3) - (4)].vector).type == VEC_FLOAT) {
	       sort_flt((yyvsp[(3) - (4)].vector).vec.f, (yyvsp[(3) - (4)].vector).dimen);
	    } else if((yyvsp[(3) - (4)].vector).type == VEC_STRING) {
	       int *sorted;
	       VECTOR temp_s;		/* temp vector for rearranging */

	       if((sorted = malloc((unsigned)(yyvsp[(3) - (4)].vector).dimen*sizeof(int))) == NULL) {
		  msg("malloc returns NULL for SORT\n");
		  break;
	       }
	       
	       temp_s.type = VEC_STRING;
	       if(vec_malloc(&temp_s,dimen) == -1) {
		  msg("malloc returns NULL for SORT\n");
		  free((char *)sorted);
		  break;
	       }

	       sort_str_inds((yyvsp[(3) - (4)].vector).vec.s.s,sorted,dimen);

	       (void)memcpy((Void *)temp_s.vec.s.s_s,
			    (Const Void *)(yyvsp[(3) - (4)].vector).vec.s.s_s,dimen*VEC_STR_SIZE);
	       
	       for(i = 0;i < dimen;i++) {		/* restore it sorted */
		  strcpy((yyvsp[(3) - (4)].vector).vec.s.s[i],temp_s.vec.s.s[sorted[i]]);
	       }
	       
	       free((char *)sorted);
	       vec_free(&temp_s);
	    } else if((yyvsp[(3) - (4)].vector).type == VEC_NULL) {
	       msg_1s("I don't know how to sort vector %s of type NULL\n",
		      (yyvsp[(3) - (4)].vector).name);
	    } else {
	       msg("You can't get here. SORT.\n");
	    }

	    (yyval.vector).dimen = (yyvsp[(3) - (4)].vector).dimen;
	    (yyval.vector).type = (yyvsp[(3) - (4)].vector).type;
	    (yyval.vector).name = (yyvsp[(3) - (4)].vector).name;
	    (yyval.vector).vec = (yyvsp[(3) - (4)].vector).vec;
	 }
    break;

  case 199:
/* #line 2057 "control.y" */
    { vec_sprintf(&(yyvsp[(3) - (6)].vector),&(yyvsp[(5) - (6)].vector),&(yyval.vector)); }
    break;

  case 200:
/* #line 2059 "control.y" */
    { vec_sqrt(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 201:
/* #line 2061 "control.y" */
    { vec_string(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 202:
/* #line 2063 "control.y" */
    {
	    char *q;				/* pointer to a ' */
	    char tmp[2*VEC_STR_SIZE];		/* quoted version of element */
	    char *tptr = tmp;			/* pointer to tmp */
	    char *eptr = (yyvsp[(3) - (4)].charval);

	    if(make_anon_vector(&(yyval.vector),1,VEC_STRING) != 0) {
	       (yyval.vector).type = VEC_NULL;
	       break;
	    }

	    if((q = strchr(eptr, '\'')) == NULL) {
	       (void)strcpy((yyval.vector).vec.s.s[0], (yyvsp[(3) - (4)].charval));
	    } else {			/* quote the quotes */
	       do {
		  strncpy(tptr, eptr, q - eptr);
		  tptr += q - eptr;
		  *tptr++ = '\\';
		  *tptr++ = '\'';
		  *tptr = '\0';
		  
		  eptr = q + 1;
	       } while((q = strchr(eptr, '\'')) != NULL);
	       strcpy(tptr, eptr);	/* get end of string */
	       
	       tmp[VEC_STR_SIZE - 1] = '\0';
 	       (void)strcpy((yyval.vector).vec.s.s[0], tmp);
	    }
	 }
    break;

  case 203:
/* #line 2093 "control.y" */
    { vec_strlen(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 204:
/* #line 2095 "control.y" */
    { vec_substr(&(yyvsp[(3) - (8)].vector),&(yyvsp[(5) - (8)].vector),&(yyvsp[(7) - (8)].vector),&(yyval.vector)); }
    break;

  case 205:
/* #line 2097 "control.y" */
    { vec_tan(&(yyvsp[(3) - (4)].vector),&(yyval.vector)); }
    break;

  case 206:
/* #line 2101 "control.y" */
    { (yyval.t_list) = (yyvsp[(2) - (3)].t_list); }
    break;

  case 207:
/* #line 2103 "control.y" */
    { (yyval.t_list) = (yyvsp[(2) - (3)].t_list); }
    break;

  case 208:
/* #line 2107 "control.y" */
    { (yyval.strval) = (yyvsp[(2) - (3)].strval); }
    break;

  case 209:
/* #line 2109 "control.y" */
    { (yyval.strval) = (yyvsp[(2) - (3)].strval); }
    break;

  case 210:
/* #line 2113 "control.y" */
    { (yyval.intval) = 1; }
    break;

  case 211:
/* #line 2115 "control.y" */
    { (yyval.intval) = 2; }
    break;

  case 212:
/* #line 2117 "control.y" */
    { (yyval.intval) = -2; }
    break;

  case 213:
/* #line 2121 "control.y" */
    { (yyval.intval) = '!'; }
    break;

  case 214:
/* #line 2123 "control.y" */
    { (yyval.intval) =  ' '; }
    break;

  case 215:
/* #line 2127 "control.y" */
    { (yyval.t_list) = (yyvsp[(2) - (3)].t_list); }
    break;

  case 216:
/* #line 2129 "control.y" */
    { (yyval.t_list) = (yyvsp[(1) - (1)].t_list); }
    break;

  case 217:
/* #line 2131 "control.y" */
    {
	    int i;
	    VECTOR *v;

	    if(((yyval.t_list) = getlist((TOK_LIST *)NULL)) == NULL) {
	       break;
	    }
	    
	    if((v = get_vector_ptr((yyvsp[(1) - (1)].charval))) == NULL) {
	       break;
	    }
	    if(v->type != VEC_FLOAT && v->type != VEC_LONG &&
	       v->type != VEC_STRING) {
	       msg_1s("Vector %s is neither arithmetic or string valued ",
		      v->name);
	       msg_1d("(it's %d)\n",v->type);
	       break;
	    }
	    
	    for(i = 0;i < v->dimen;i++) {
	       if((yyval.t_list)->nitem >= (yyval.t_list)->nmax) { /* get some more space */
		  (yyval.t_list) = getlist((yyval.t_list));
	       }
	       
	       if(v->type == VEC_FLOAT) {
		  
		  sprintf((yyval.t_list)->i_list[(yyval.t_list)->nitem++]->str,"%.10g",v->vec.f[i]);
	       } else if(v->type == VEC_LONG) {
		  char *dl[] = { "", "%d", "%ld" };	/* do we need a %l format? */
		  assert(sizeof(LONG)/4 < 3);

		  sprintf((yyval.t_list)->i_list[(yyval.t_list)->nitem++]->str,dl[sizeof(LONG)/4],v->vec.l[i]);
	       } else if(v->type == VEC_STRING) {
		  (void)strncpy((yyval.t_list)->i_list[(yyval.t_list)->nitem++]->str,v->vec.s.s[i],CHARMAX);
	       } else {
		  msg_1s("You cannot get here! (foreach %s ...)\n",v->name);
		  break;
	       }
	    }
	    if(i != v->dimen) { break; } /* error in loop */
	 }
    break;

  case 218:
/* #line 2176 "control.y" */
    { (void)sm_axis( (yyvsp[(2) - (10)].floatval), (yyvsp[(3) - (10)].floatval), (yyvsp[(4) - (10)].floatval), (yyvsp[(5) - (10)].floatval), (yyvsp[(6) - (10)].intval), (yyvsp[(7) - (10)].intval), (yyvsp[(8) - (10)].intval), (yyvsp[(9) - (10)].intval), (yyvsp[(10) - (10)].intval) ); }
    break;

  case 219:
/* #line 2178 "control.y" */
    { vec_axis( (yyvsp[(2) - (10)].floatval), (yyvsp[(3) - (10)].floatval), &(yyvsp[(4) - (10)].vector), &(yyvsp[(5) - (10)].vector), (VECTOR *)NULL, (yyvsp[(6) - (10)].intval), (yyvsp[(7) - (10)].intval), (yyvsp[(8) - (10)].intval), (yyvsp[(9) - (10)].intval), (yyvsp[(10) - (10)].intval) ); }
    break;

  case 220:
/* #line 2181 "control.y" */
    {
	    VECTOR *lab;
	    
	    if((lab = get_vector_ptr((yyvsp[(6) - (11)].charval))) == NULL) {
	       break;
	    }
	    if(lab->type != VEC_STRING) {
	       msg_1s("Error: %s is not a string vector\n",(yyvsp[(6) - (11)].charval));
	       YYERROR;
	    }
	    if(lab->dimen != (yyvsp[(5) - (11)].vector).dimen && lab->dimen != 1) {
	       msg_2s("The dimensions of %s and %s must be the same\n",
		      (yyvsp[(5) - (11)].vector).name,(yyvsp[(6) - (11)].charval));
	       YYERROR;
	    }
	    vec_axis( (yyvsp[(2) - (11)].floatval), (yyvsp[(3) - (11)].floatval), &(yyvsp[(4) - (11)].vector), &(yyvsp[(5) - (11)].vector), lab, (yyvsp[(7) - (11)].intval), (yyvsp[(8) - (11)].intval), (yyvsp[(9) - (11)].intval), (yyvsp[(10) - (11)].intval), (yyvsp[(11) - (11)].intval) );
	 }
    break;

  case 221:
/* #line 2199 "control.y" */
    { sm_box(1,2,0,0); }
    break;

  case 222:
/* #line 2201 "control.y" */
    { sm_box((yyvsp[(2) - (3)].intval),(yyvsp[(3) - (3)].intval),0,0); }
    break;

  case 223:
/* #line 2203 "control.y" */
    { sm_box((yyvsp[(2) - (5)].intval),(yyvsp[(3) - (5)].intval),(yyvsp[(4) - (5)].intval),(yyvsp[(5) - (5)].intval)); }
    break;

  case 224:
/* #line 2205 "control.y" */
    { (void)sm_contour(); }
    break;

  case 225:
/* #line 2207 "control.y" */
    {
	    set_color(&(yyvsp[(3) - (3)].vector));
	    vec_free(&(yyvsp[(3) - (3)].vector));
	 }
    break;

  case 226:
/* #line 2212 "control.y" */
    { sm_ctype_i((yyvsp[(2) - (2)].intval)); }
    break;

  case 227:
/* #line 2214 "control.y" */
    { sm_ctype((yyvsp[(2) - (2)].charval)); }
    break;

  case 228:
/* #line 2216 "control.y" */
    { sm_dot(); }
    break;

  case 229:
/* #line 2218 "control.y" */
    { sm_draw((yyvsp[(2) - (3)].floatval),(yyvsp[(3) - (3)].floatval)); }
    break;

  case 230:
/* #line 2220 "control.y" */
    { gdraw((yyvsp[(3) - (5)].floatval),(yyvsp[(4) - (5)].floatval)); }
    break;

  case 231:
/* #line 2222 "control.y" */
    {
	     int raise_on_erase;
	     char *roe = print_var("raise_on_erase");
	     raise_on_erase = (*roe == '\0') || atoi(roe);

	     (*devices[devnum].dev_erase)(raise_on_erase); /* saying ERASE() won't work */
	  }
    break;

  case 232:
/* #line 2230 "control.y" */
    {
	     REAL *temp = NULL;
	     int i,npoint;

	     vec_convert_float(&(yyvsp[(4) - (5)].vector));

	     if((yyvsp[(2) - (5)].vector).dimen < (yyvsp[(3) - (5)].vector).dimen) {
	        msg_2s("%s contains fewer points than %s\n",(yyvsp[(2) - (5)].vector).name,(yyvsp[(3) - (5)].vector).name);
	        npoint = (yyvsp[(2) - (5)].vector).dimen;
	     } else if((yyvsp[(3) - (5)].vector).dimen < (yyvsp[(2) - (5)].vector).dimen) {
	        msg_2s("%s contains fewer points than %s\n",(yyvsp[(3) - (5)].vector).name,(yyvsp[(2) - (5)].vector).name);
	        npoint = (yyvsp[(3) - (5)].vector).dimen;
	     } else {
	        npoint = (yyvsp[(2) - (5)].vector).dimen;
	     }

	     if((yyvsp[(4) - (5)].vector).dimen == 1) {
		if((temp = (REAL *)malloc((unsigned)npoint*sizeof(REAL)))
								== NULL) {
		   msg("Can't allocate space in errorbar\n");
		   vec_free(&(yyvsp[(2) - (5)].vector)); vec_free(&(yyvsp[(3) - (5)].vector)); vec_free(&(yyvsp[(4) - (5)].vector));
		   break;
		}
		for(i = 0;i < npoint;i++) {
		   temp[i] = (yyvsp[(4) - (5)].vector).vec.f[0];
		}
		free((char *)((yyvsp[(4) - (5)].vector).vec.f));
		(yyvsp[(4) - (5)].vector).vec.f = temp;
	     } else if((yyvsp[(4) - (5)].vector).dimen < npoint) {
		msg_2s("%s is smaller than %s ",(yyvsp[(4) - (5)].vector).name,(yyvsp[(2) - (5)].vector).name);
		msg_1s("or %s, truncating\n",(yyvsp[(3) - (5)].vector).name);
		npoint = (yyvsp[(4) - (5)].vector).dimen;
	     } else if((yyvsp[(4) - (5)].vector).dimen > npoint) {
		msg_2s("%s is larger than %s ",(yyvsp[(4) - (5)].vector).name,(yyvsp[(2) - (5)].vector).name);
		msg_1s("or %s\n",(yyvsp[(3) - (5)].vector).name);
	     }

	     (void)sm_errorbar((yyvsp[(2) - (5)].vector).vec.f,(yyvsp[(3) - (5)].vector).vec.f,(yyvsp[(4) - (5)].vector).vec.f,(yyvsp[(5) - (5)].intval),npoint);
	     vec_free(&(yyvsp[(2) - (5)].vector)); vec_free(&(yyvsp[(3) - (5)].vector)); vec_free(&(yyvsp[(4) - (5)].vector));
	  }
    break;

  case 233:
/* #line 2271 "control.y" */
    { sm_grid((yyvsp[(2) - (3)].intval),(yyvsp[(3) - (3)].intval)); }
    break;

  case 234:
/* #line 2273 "control.y" */
    {
	    if(*mgets(buff,MACROSIZE) != '\0') {
	       sm_label(&buff[1]);
	    } else {
	       msg("Can't get label\n");
	    }
	 }
    break;

  case 235:
/* #line 2281 "control.y" */
    { sm_ltype( (int)(yyvsp[(2) - (2)].floatval) ); }
    break;

  case 236:
/* #line 2283 "control.y" */
    { sm_ltype( 10 ); }
    break;

  case 237:
/* #line 2285 "control.y" */
    {
	    if((yyvsp[(3) - (3)].floatval) <= 0) {
	       msg_1f("Illegal expand ltype: %g\n", (yyvsp[(3) - (3)].floatval));
	       break;
	    }
	    sm_set_ltype_expand((yyvsp[(3) - (3)].floatval));
	 }
    break;

  case 238:
/* #line 2293 "control.y" */
    { (*devices[devnum].dev_page)(); }
    break;

  case 239:
/* #line 2295 "control.y" */
    {
	    int npoint;

	    if((yyvsp[(3) - (4)].vector).dimen < (yyvsp[(4) - (4)].vector).dimen) {
	       msg_2s("%s contains fewer points than %s\n",(yyvsp[(3) - (4)].vector).name,(yyvsp[(4) - (4)].vector).name);
	       npoint = (yyvsp[(3) - (4)].vector).dimen;
	    } else if((yyvsp[(4) - (4)].vector).dimen < (yyvsp[(3) - (4)].vector).dimen) {	
	       msg_2s("%s contains fewer points than %s\n",(yyvsp[(4) - (4)].vector).name,(yyvsp[(3) - (4)].vector).name);
	       npoint = (yyvsp[(4) - (4)].vector).dimen;
	    } else {
	       npoint = (yyvsp[(3) - (4)].vector).dimen;
	    }

	    (void)sm_histogram( (yyvsp[(3) - (4)].vector).vec.f, (yyvsp[(4) - (4)].vector).vec.f, -npoint );
	 }
    break;

  case 240:
/* #line 2311 "control.y" */
    {
	    int npoint;

	    if((yyvsp[(2) - (3)].vector).dimen < (yyvsp[(3) - (3)].vector).dimen) {
	       msg_2s("%s contains fewer points than %s\n",(yyvsp[(2) - (3)].vector).name,(yyvsp[(3) - (3)].vector).name);
	       npoint = (yyvsp[(2) - (3)].vector).dimen;
	    } else if((yyvsp[(3) - (3)].vector).dimen < (yyvsp[(2) - (3)].vector).dimen) {	
	       msg_2s("%s contains fewer points than %s\n",(yyvsp[(3) - (3)].vector).name,(yyvsp[(2) - (3)].vector).name);
	       npoint = (yyvsp[(3) - (3)].vector).dimen;
	    } else {
	       npoint = (yyvsp[(2) - (3)].vector).dimen;
	    }

	    if((yyvsp[(1) - (3)].intval) == CONNECT) {
	       (void)sm_conn( (yyvsp[(2) - (3)].vector).vec.f, (yyvsp[(3) - (3)].vector).vec.f, npoint );
	    } else if((yyvsp[(1) - (3)].intval) == HISTOGRAM) {
	       (void)sm_histogram( (yyvsp[(2) - (3)].vector).vec.f, (yyvsp[(3) - (3)].vector).vec.f, npoint );
	    } else if((yyvsp[(1) - (3)].intval) == POINTS) {
	       sm_points( (yyvsp[(2) - (3)].vector).vec.f, (yyvsp[(3) - (3)].vector).vec.f, npoint );
	    } else {
	       msg("Unknown plotting command\n");
	    }
	    vec_free(&(yyvsp[(2) - (3)].vector)); vec_free(&(yyvsp[(3) - (3)].vector));
	 }
    break;

  case 241:
/* #line 2336 "control.y" */
    {
	    int npoint;

	    if((yyvsp[(2) - (7)].vector).dimen < (yyvsp[(3) - (7)].vector).dimen) {
	       msg_2s("%s contains fewer points than %s\n",(yyvsp[(2) - (7)].vector).name,(yyvsp[(3) - (7)].vector).name);
	       npoint = (yyvsp[(2) - (7)].vector).dimen;
	    } else if((yyvsp[(3) - (7)].vector).dimen < (yyvsp[(2) - (7)].vector).dimen) {
	       msg_2s("%s contains fewer points than %s\n",(yyvsp[(3) - (7)].vector).name,(yyvsp[(2) - (7)].vector).name);
	       npoint = (yyvsp[(3) - (7)].vector).dimen;
	    } else {
	       npoint = (yyvsp[(2) - (7)].vector).dimen;
	    }

	    if((yyvsp[(6) - (7)].vector).dimen != npoint) {
	       msg("Logical vector differs in length from data\n");
	       if(npoint > (yyvsp[(6) - (7)].vector).dimen) {
		  npoint = (yyvsp[(6) - (7)].vector).dimen;
	       }
	    }

	    if((yyvsp[(6) - (7)].vector).type == VEC_LONG) {
	       vec_convert_float(&(yyvsp[(6) - (7)].vector));
	    }

	    if((yyvsp[(1) - (7)].intval) == CONNECT) {
	       (void)sm_connect_if( (yyvsp[(2) - (7)].vector).vec.f, (yyvsp[(3) - (7)].vector).vec.f, (yyvsp[(6) - (7)].vector).vec.f, npoint );
	    } else if((yyvsp[(1) - (7)].intval) == HISTOGRAM) {
	       (void)sm_histogram_if( (yyvsp[(2) - (7)].vector).vec.f, (yyvsp[(3) - (7)].vector).vec.f, (yyvsp[(6) - (7)].vector).vec.f, npoint );
	    } else if((yyvsp[(1) - (7)].intval) == POINTS) {
	       sm_points_if( (yyvsp[(2) - (7)].vector).vec.f, (yyvsp[(3) - (7)].vector).vec.f, (yyvsp[(6) - (7)].vector).vec.f, npoint );
	    } else {
	       msg("Unknown plotting command\n");
	    }
	    vec_free(&(yyvsp[(6) - (7)].vector)); vec_free(&(yyvsp[(2) - (7)].vector)); vec_free(&(yyvsp[(3) - (7)].vector));
	 }
    break;

  case 242:
/* #line 2372 "control.y" */
    {
	    if(*mgets(buff,MACROSIZE) != '\0') {
	       sm_putlabel((yyvsp[(2) - (2)].intval),&buff[1]);
	    } else {
	       msg("Can't get label\n");
	    }
	  }
    break;

  case 243:
/* #line 2380 "control.y" */
    { sm_relocate((yyvsp[(2) - (3)].floatval),(yyvsp[(3) - (3)].floatval)); }
    break;

  case 244:
/* #line 2382 "control.y" */
    { sm_grelocate((yyvsp[(3) - (5)].floatval),(yyvsp[(4) - (5)].floatval)); }
    break;

  case 245:
/* #line 2384 "control.y" */
    {
	    int npoint;

	    npoint = (yyvsp[(3) - (4)].vector).dimen;
	    if(npoint != (yyvsp[(4) - (4)].vector).dimen) {
	       msg("dimension of vectors in shade must be equal\n");
	       npoint = (npoint < (yyvsp[(4) - (4)].vector).dimen) ? npoint : (yyvsp[(4) - (4)].vector).dimen;
	    }
	    (void)sm_shade((yyvsp[(2) - (4)].floatval),(yyvsp[(3) - (4)].vector).vec.f,(yyvsp[(4) - (4)].vector).vec.f,npoint,(yyvsp[(1) - (4)].intval));
	    vec_free(&(yyvsp[(3) - (4)].vector)); vec_free(&(yyvsp[(4) - (4)].vector));
	 }
    break;

  case 246:
/* #line 2396 "control.y" */
    { sm_draw_surface((yyvsp[(2) - (4)].intval),(yyvsp[(3) - (4)].floatval),(yyvsp[(4) - (4)].floatval),(REAL *)NULL,0,(REAL *)NULL,0); }
    break;

  case 247:
/* #line 2398 "control.y" */
    {
	    VECTOR *x,*y;
	    
	    if((x = get_vector_ptr((yyvsp[(5) - (6)].charval))) == NULL) {
	       break;
	    }
	    if(x->type == VEC_STRING) {
	       msg_1s("Error: %s is not an arithmetic vector\n",(yyvsp[(5) - (6)].charval));
	       YYERROR;
	    }
	    vec_convert_float(x);

	    if((y = get_vector_ptr((yyvsp[(6) - (6)].charval))) == NULL) {
	       break;
	    }
	    if(y->type == VEC_STRING) {
	       msg_1s("Error: %s is not an arithmetic vector\n",(yyvsp[(6) - (6)].charval));
	       YYERROR;
	    }
	    vec_convert_float(y);

	    sm_draw_surface((yyvsp[(2) - (6)].intval),(yyvsp[(3) - (6)].floatval),(yyvsp[(4) - (6)].floatval),x->vec.f,x->dimen,y->vec.f,y->dimen);
	 }
    break;

  case 248:
/* #line 2422 "control.y" */
    {
	    if(*mgets(buff,MACROSIZE) != '\0') {
	       sm_xlabel(&buff[1]);
	    } else {
	       msg("Can't get xlabel\n");
	    }
	 }
    break;

  case 249:
/* #line 2430 "control.y" */
    {
	    if(*mgets(buff,MACROSIZE) != '\0') {
	       sm_ylabel(&buff[1]);
	    } else {
	       msg("Can't get ylabel\n");
	    }
	 }
    break;

  case 250:
/* #line 2440 "control.y" */
    { (yyval.intval) = (yyvsp[(1) - (1)].intval); }
    break;

  case 251:
/* #line 2442 "control.y" */
    { (yyval.intval) = -(yyvsp[(2) - (2)].intval); }
    break;

  case 252:
/* #line 2446 "control.y" */
    { (yyval.intval) = (yyvsp[(1) - (1)].intval); }
    break;

  case 253:
/* #line 2448 "control.y" */
    { (yyval.intval) = 0; }
    break;

  case 254:
/* #line 2452 "control.y" */
    {
	    int i;
	    float min,max;
	    VECTOR *tmp = &(yyvsp[(1) - (1)].vector);

	    vec_convert_float(tmp);

	    min = 1e30; max = -1e30;
	    for(i = 0;i < tmp->dimen;i++) {
	       if(tmp->vec.f[i] < NO_VALUE) { /* not a bad point */
		  if(tmp->vec.f[i] > max) {
		     max = tmp->vec.f[i];
		  }
		  if(tmp->vec.f[i] < min) {
		     min = tmp->vec.f[i];
		  }
	       }
	    }

	    if(fabs(xy_range) < 1e-20) { /* no range is set for this axis */
	       float diff = max - min;
	       
	       if(diff == 0) {
		  diff = min;
	       }
	       diff *= 0.05;
	       
	       (yyval.pairval).a = min - diff;
	       (yyval.pairval).b = max + diff;
	    } else if(fabs(max - min) < fabs(xy_range)) { /* max - min < range */
	       float mean = (min + max)/2;
	       (yyval.pairval).a = mean - xy_range/2;
	       (yyval.pairval).b = mean + xy_range/2;
	    } else {			/* we'll need to find the median */
	       float median;
	       
	       sort_flt(tmp->vec.f,tmp->dimen);
	       
	       for(i = tmp->dimen - 1;i >= 0;i--) { /* ignore bad points */
		  if(tmp->vec.f[i] < NO_VALUE) break;
	       }
	       if(i < 0) {
		  msg("No valid values to find limits from");
		  (yyval.pairval).a = (yyval.pairval).b = 0.0;
		  break;
	       }

	       if(i%2 == 0) {
		  median = tmp->vec.f[i/2];
	       } else {
		  median = (tmp->vec.f[i/2] + tmp->vec.f[i/2 + 1])/2;
	       }

	       (yyval.pairval).a = median - xy_range/2;
	       (yyval.pairval).b = median + xy_range/2;
	    }
	    
	    vec_free(&(yyvsp[(1) - (1)].vector));
	 }
    break;

  case 255:
/* #line 2512 "control.y" */
    {
	    if(fabs(xy_range) < 1e-20) { /* no range specified */
	       (yyval.pairval).a = (yyvsp[(1) - (2)].floatval);
	       (yyval.pairval).b = (yyvsp[(2) - (2)].floatval);
	    } else {
	       float mean = ((yyvsp[(1) - (2)].floatval) + (yyvsp[(2) - (2)].floatval))/2;
	       (yyval.pairval).a = mean - xy_range/2;
	       (yyval.pairval).b = mean + xy_range/2;
	    }
	 }
    break;

  case 256:
/* #line 2525 "control.y" */
    { (yyval.t_list) = getlist((TOK_LIST *)NULL); }
    break;

  case 257:
/* #line 2527 "control.y" */
    {
	    if((yyvsp[(1) - (2)].t_list) == NULL) {		/* couldn't get space */
	       break;
	    }
            if((yyvsp[(1) - (2)].t_list)->nitem >= (yyvsp[(1) - (2)].t_list)->nmax) {	/* get some more space */
	       (yyval.t_list) = getlist((yyvsp[(1) - (2)].t_list));
	    } else {
	       (yyval.t_list) = (yyvsp[(1) - (2)].t_list);
	    }
	    (void)strncpy((yyval.t_list)->i_list[(yyval.t_list)->nitem]->str,(yyvsp[(2) - (2)].charval),CHARMAX);
	    (yyval.t_list)->nitem++;
	 }
    break;

  case 258:
/* #line 2540 "control.y" */
    {
	    if((yyvsp[(1) - (2)].t_list) == NULL) {		/* couldn't get space */
	       break;
	    }
            if((yyvsp[(1) - (2)].t_list)->nitem >= (yyvsp[(1) - (2)].t_list)->nmax) {	/* get some more space */
	       (yyval.t_list) = getlist((yyvsp[(1) - (2)].t_list));
	    } else {
	       (yyval.t_list) = (yyvsp[(1) - (2)].t_list);
	    }
	    (void)strncpy((yyval.t_list)->i_list[(yyval.t_list)->nitem]->str,(yyvsp[(2) - (2)].charval),CHARMAX);
	    (yyval.t_list)->nitem++;
	 }
    break;

  case 259:
/* #line 2553 "control.y" */
    {
	    if((yyvsp[(1) - (2)].t_list) == NULL) {		/* couldn't get space */
	       break;
	    }
            if((yyvsp[(1) - (2)].t_list)->nitem >= (yyvsp[(1) - (2)].t_list)->nmax) {	/* get some more space */
	       (yyval.t_list) = getlist((yyvsp[(1) - (2)].t_list));
	    } else {
	       (yyval.t_list) = (yyvsp[(1) - (2)].t_list);
	    }
	    (void)strncpy((yyval.t_list)->i_list[(yyval.t_list)->nitem]->str,"\n",CHARMAX);
	    (yyval.t_list)->nitem++;
	 }
    break;

  case 260:
/* #line 2568 "control.y" */
    {
	    number_is_int = 0;
	    (yyval.floatval) = (yyvsp[(1) - (2)].intval) ? -(yyvsp[(2) - (2)].floatval) : (yyvsp[(2) - (2)].floatval);
	 }
    break;

  case 261:
/* #line 2573 "control.y" */
    {
	    number_is_int = 1;
	    (yyval.floatval) = intval = (yyvsp[(1) - (2)].intval) ? -(yyvsp[(2) - (2)].intval) : (yyvsp[(2) - (2)].intval);
	 }
    break;

  case 262:
/* #line 2578 "control.y" */
    {
	    number_is_int = 1;
	    (yyval.floatval) = intval = (yyvsp[(3) - (4)].vector).dimen;
	    vec_free(&(yyvsp[(3) - (4)].vector));
	 }
    break;

  case 263:
/* #line 2584 "control.y" */
    {
	    int i;
	    double val;			/* $$ is a float */

	    number_is_int = 0;
	    val = 0;
	    if((yyvsp[(3) - (4)].vector).type == VEC_STRING) {
	       msg_1s("Vector %s is string valued\n", (yyvsp[(3) - (4)].vector).name);
	       vec_free(&(yyvsp[(3) - (4)].vector));
	       break;
	    } else if((yyvsp[(3) - (4)].vector).type == VEC_LONG) {
	       for(i = 0;i < (yyvsp[(3) - (4)].vector).dimen;i++) {
		  val += (yyvsp[(3) - (4)].vector).vec.l[i];
	       }
	    } else {
	       for(i = 0;i < (yyvsp[(3) - (4)].vector).dimen;i++) {
		  val += (yyvsp[(3) - (4)].vector).vec.f[i];
	       }
	    }
	    (yyval.floatval) = val;
	    vec_free(&(yyvsp[(3) - (4)].vector));
	 }
    break;

  case 264:
/* #line 2607 "control.y" */
    {
	    int i,tok,vtype;
	    YYSTYPE lval;

	    i = 0;
	    if((yyvsp[(3) - (4)].charval)[0] == '-') {		/* could be part of -number */
	       if((yyvsp[(3) - (4)].charval)[1] == '.' || isdigit((yyvsp[(3) - (4)].charval)[1])) {
		  i = 1;		/* assume it is, this could be wrong */
	       }
	    }
	    push(&(yyvsp[(3) - (4)].charval)[i],S_NORMAL);
#if defined(YYBISON)		/* a bison later than 1.14 */
	    tok = yylex(&lval);		/* convert word to a token */
#else
	    tok = yylex(&lval,(Void *)NULL); /* convert word to a token */
#endif
	    unsave_str();		/* yylex will have saved it */
	    if(tok == INTEGER || tok == _FLOAT) {
	       i = 0;
	    } else {					/* a word */
	       i = 01;
	       if(get_macro((yyvsp[(3) - (4)].charval),(int *)NULL,(int *)NULL,(int *)NULL)
			         != NULL) i |= 02;	/* a macro */
	       if(exists_var((yyvsp[(3) - (4)].charval))) i |= 04;	/* a variable */
	       if((vtype = is_vector((yyvsp[(3) - (4)].charval))) != 0) {
		  i |= 010;		/* a vector */
		  if(vtype == VEC_FLOAT) {
		     i |= 040;
		  } else if(vtype == VEC_LONG) {
		     i |= 0200;
		  } else if(vtype == VEC_STRING) {
		     i |= 0100;
		  }
	       }
	       if(tok != WORD) i |= 020;		/* a keyword */
	    }
	    number_is_int = 1;
	    (yyval.floatval) = intval = i;
	 }
    break;

  case 265:
/* #line 2649 "control.y" */
    { (void)sprintf((yyval.charval),"%.10g",(yyvsp[(1) - (1)].floatval)); }
    break;

  case 266:
/* #line 2651 "control.y" */
    { (void)strcpy((yyval.charval),(yyvsp[(1) - (1)].charval)); }
    break;

  case 267:
/* #line 2655 "control.y" */
    { (yyval.floatval) = 1; }
    break;

  case 268:
/* #line 2657 "control.y" */
    { (yyval.floatval) = (yyvsp[(2) - (2)].floatval); }
    break;

  case 269:
/* #line 2661 "control.y" */
    {
	    int type;

	    if((type = get_vector((yyvsp[(1) - (1)].charval),&(yyval.vector))) < 0) {
	       break;
	    } else if(type == VEC_STRING) {
	       msg_1s("%s is not an arithmetic vector\n",(yyvsp[(1) - (1)].charval));
	       break;
	    }
	    vec_convert_float(&(yyval.vector));
	 }
    break;

  case 270:
/* #line 2673 "control.y" */
    {
	    
	    (yyval.vector) = (yyvsp[(2) - (3)].vector); (yyval.vector).name = "(expr)";
	    vec_convert_float(&(yyval.vector));
	 }
    break;

  case 271:
/* #line 2681 "control.y" */
    { (yyval.intval) = CONNECT; }
    break;

  case 272:
/* #line 2683 "control.y" */
    { (yyval.intval) = HISTOGRAM; }
    break;

  case 273:
/* #line 2685 "control.y" */
    { (yyval.intval) = POINTS; }
    break;

  case 274:
/* #line 2689 "control.y" */
    { (yyval.intval) = '+'; }
    break;

  case 275:
/* #line 2691 "control.y" */
    { (yyval.intval) =  ' '; }
    break;

  case 276:
/* #line 2695 "control.y" */
    {
	    if(((yyval.strval).start = malloc(1)) != NULL) {
	       (yyval.strval).start[0] = '\0';
	       (yyval.strval).end = (yyval.strval).start;
	    }
	 }
    break;

  case 277:
/* #line 2702 "control.y" */
    { (yyval.strval) = (yyvsp[(1) - (1)].strval); }
    break;

  case 278:
/* #line 2706 "control.y" */
    { (yyval.intval) = 1; }
    break;

  case 279:
/* #line 2708 "control.y" */
    { (yyval.intval) = 0; }
    break;

  case 280:
/* #line 2710 "control.y" */
    { (yyval.intval) = 0; }
    break;

  case 281:
/* #line 2714 "control.y" */
    {
	    if((yyvsp[(1) - (1)].vector).dimen <= 0) {
	       msg_1s("Vector %s has dimension <= 0\n",(yyvsp[(1) - (1)].vector).name);
	       YYERROR;
	    } else if((yyvsp[(1) - (1)].vector).dimen != 1 && sm_verbose > 1) {
	       msg_1s("Vector %s must be a scalar\n",(yyvsp[(1) - (1)].vector).name);
	    }
	    if((yyvsp[(1) - (1)].vector).type == VEC_FLOAT) {
	       (yyval.floatval) = (yyvsp[(1) - (1)].vector).vec.f[0];
	    } else if((yyvsp[(1) - (1)].vector).type == VEC_LONG) {
	       (yyval.floatval) = (yyvsp[(1) - (1)].vector).vec.l[0];
	    } else {
	       if(sm_verbose > 1) {
		  msg_1s("Error: %s is not an arithmetic vector\n",(yyvsp[(1) - (1)].vector).name);
		  vec_free(&(yyvsp[(1) - (1)].vector));
		  YYERROR;
	       }
	    }
	    vec_free(&(yyvsp[(1) - (1)].vector));
	 }
    break;

  case 282:
/* #line 2734 "control.y" */
    {
	 int c;
	 int lhs = (yyvsp[(1) - (2)].floatval);
	 int plevel = 1;		/* level of nesting of parentheses */
	 if(!lhs) {
	    save_str("(skipping expr)");
	    if(sm_verbose > 3) {
	       msg_1d("%d> (skipping expr)\n",noexpand);
	    }
	    
	    noexpand++;
	    while(!sm_interrupt) {
	       c = input();
	       if(c == '(') {
		  plevel++;
	       } else if(c == ')') {
		  plevel--;
		  if(plevel == 0) {
		     push("0) ", S_NORMAL);
		     break;
		  }
	       }
	    }
	    noexpand--;
	 }
      }
    break;

  case 283:
/* #line 2760 "control.y" */
    {
	    (yyval.floatval) = (yyvsp[(1) - (4)].floatval) && (yyvsp[(4) - (4)].floatval);
	 }
    break;

  case 284:
/* #line 2763 "control.y" */
    {
	 int c;
	 int lhs = (yyvsp[(1) - (2)].floatval);
	 int plevel = 1;		/* level of nesting of parentheses */
	 if(lhs) {
	    save_str("(skipping expr)");
	    if(sm_verbose > 3) {
	       msg_1d("%d> (skipping expr)\n",noexpand);
	    }
	    noexpand++;
	    while(!sm_interrupt) {
	       c = input();
	       if(c == '(') {
		  plevel++;
	       } else if(c == ')') {
		  plevel--;
		  if(plevel == 0) {
		     push("1) ", S_NORMAL);
		     break;
		  }
	       }
	    }
	    noexpand--;
	 }
      }
    break;

  case 285:
/* #line 2788 "control.y" */
    {
	    (yyval.floatval) = (yyvsp[(1) - (4)].floatval) || (yyvsp[(4) - (4)].floatval);
	 }
    break;

  case 286:
/* #line 2794 "control.y" */
    { (yyval.vector) = (yyvsp[(1) - (1)].vector); }
    break;

  case 287:
/* #line 2796 "control.y" */
    {
	    int i,j;

	    if((yyvsp[(4) - (5)].vector).dimen != (yyvsp[(1) - (5)].vector).dimen && (yyvsp[(4) - (5)].vector).dimen != 1) {
	       msg_1s("Setting %s: ",(yyvsp[(-1) - (5)].charval));
	       msg_2s("Logical vector %s has a different length from %s\n",
		      (yyvsp[(4) - (5)].vector).name, (yyvsp[(1) - (5)].vector).name);
	    }

	    if((yyvsp[(4) - (5)].vector).type == VEC_STRING) {
	       msg_1s("Vector %s is not arithmetical\n", (yyvsp[(4) - (5)].vector).name);
	    }
	    vec_convert_long(&(yyvsp[(4) - (5)].vector));

	    if((yyvsp[(4) - (5)].vector).dimen == 1) {
	       if((yyvsp[(4) - (5)].vector).vec.l[0]) {
		  j = (yyvsp[(1) - (5)].vector).dimen;		/* Keep everything */
	       } else {
		  j = 0;		/* Keep nothing */
	       }
	    } else {
	       for(i = 0,j = 0;i < (yyvsp[(1) - (5)].vector).dimen;i++) {
		  if(i >= (yyvsp[(4) - (5)].vector).dimen || (yyvsp[(4) - (5)].vector).vec.l[i]) { /* copy desired elements*/
		     if((yyvsp[(1) - (5)].vector).type == VEC_FLOAT) {
			(yyvsp[(1) - (5)].vector).vec.f[j] = (yyvsp[(1) - (5)].vector).vec.f[i];
		     } else if((yyvsp[(1) - (5)].vector).type == VEC_LONG) {
			(yyvsp[(1) - (5)].vector).vec.l[j] = (yyvsp[(1) - (5)].vector).vec.l[i];
		     } else if((yyvsp[(1) - (5)].vector).type == VEC_STRING) {
			(void)strncpy((yyvsp[(1) - (5)].vector).vec.s.s[j],(yyvsp[(1) - (5)].vector).vec.s.s[i],VEC_STR_SIZE);
		     }
		     j++;
		  }
	       }
	    }
	    vec_free(&(yyvsp[(4) - (5)].vector));

	    if(((yyvsp[(1) - (5)].vector).dimen = j) == 0 && sm_verbose > 0) {
	       msg_1s("Vector %s has no elements\n",(yyvsp[(-1) - (5)].charval));
	    }
	    if(vec_realloc(&(yyvsp[(1) - (5)].vector),(yyvsp[(1) - (5)].vector).dimen) < 0) {
	       msg_1s("Can't reclaim storage for %s\n",(yyvsp[(-1) - (5)].charval));
	       break;
	    }
	    (yyval.vector) = (yyvsp[(1) - (5)].vector);
	 }
    break;

  case 288:
/* #line 2842 "control.y" */
    {
	    if(make_anon_vector(&(yyval.vector),0,VEC_NULL) != 0) {
	       break;
	    }
	    if(vec_do(&(yyval.vector), (yyvsp[(1) - (4)].floatval), (yyvsp[(3) - (4)].floatval), (yyvsp[(4) - (4)].floatval)) < 0) {
	       break;
	    }
	 }
    break;

  case 289:
/* #line 2853 "control.y" */
    {
	    char c;
	    int i;
	    
	    while(c = input(), isspace(c)) continue;
	    (void)unput(c);			/* one too far */

	    for(i = 0;i < CHARMAX - 1;) {
	       if((c = input()) != ')' && !isspace(c)) {
	          (yyval.charval)[i++] = c;
	       } else {
		  (void)unput(c);
		  break;
	       }
	    }
	    (yyval.charval)[i] = '\0';
	    if(i == 0) {
	       msg("Error: empty name\n");
	       YYERROR;
	    }
	    save_str((yyval.charval));
            if(sm_verbose > 3) {
               msg_1d("%d> WORD     ",noexpand);
               msg_1s("%s\n",(yyval.charval));
	    }
	 }
    break;

  case 290:
/* #line 2882 "control.y" */
    {
	    (void)more((char *)NULL);	/* initialise more */
	    list_internal_vars();
         }
    break;

  case 291:
/* #line 2887 "control.y" */
    {
	    (void)more((char *)NULL);	/* initialise more */
	    list_image_vars();
	 }
    break;

  case 292:
/* #line 2892 "control.y" */
    {
	    (void)more((char *)NULL);	/* initialise more */
	    if(sm_verbose > 1) {
	       more("Internal variables:\n");
	       list_internal_vars();
	       more("\nUser variables:\n");
	    }
            (void)varlist(0,255);
            (void)unput('\n');
         }
    break;

  case 293:
/* #line 2903 "control.y" */
    {
	    (void)more((char *)NULL);	/* initialise more */
	    (void)varlist((yyvsp[(2) - (3)].charval)[0],(yyvsp[(3) - (3)].charval)[0]);
	 }
    break;

  case 294:
/* #line 2908 "control.y" */
    {
	    char *ptr;
	    
	    (void)mgets(buff,CHARMAX);	/* read rest of line */
	    for(ptr = buff;*ptr != '\0' && isspace(*ptr);ptr++) {
	       continue;
	    }
	    stg_list(ptr);
	 }
    break;

  case 295:
/* #line 2918 "control.y" */
    { list_edit(); }
    break;

  case 296:
/* #line 2920 "control.y" */
    {
            (void)macrolist('\0','\177');
            (void)unput('\n');
         }
    break;

  case 297:
/* #line 2925 "control.y" */
    { (void)macrolist((yyvsp[(2) - (3)].charval)[0],(yyvsp[(3) - (3)].charval)[0]); }
    break;

  case 298:
/* #line 2927 "control.y" */
    {
	    if(subtable < 0) {
	       msg("You don't have a current table\n");
	    } else {
	       if(subtable == 0) {
		  *word = '\0';
	       } else {
		  sprintf(word,"[%d]",subtable);
	       }
	       sprintf(buff,"Table %s%s, format %s:\n\n",
		       data_file,word,table_fmt);
	       more((char *)NULL);
	       more(buff);

	       list_table_cols(table_fmt);
	    }
	 }
    break;

  case 299:
/* #line 2945 "control.y" */
    { list_vectors(); }
    break;

  case 300:
/* #line 2949 "control.y" */
    {
	    char *ptr;			/* pointer to $$ */
	    int brace_level,		/* nesting of braces */
	        l_delim,r_delim;	/* left and right delimiters */
	    unsigned int size;		/* size allocated for $$ */

	    if((l_delim = *((yyvsp[(0) - (0)].charval))) == '{') {
	       r_delim = '}';
	    } else if(l_delim == '<') {
	       r_delim = '>';
	    } else {
	       msg_1d("Unknown delimiter %c\n",l_delim);
	       (yyval.strval).start = NULL;
	       break;
	    }

	    size = 500;
	    if(((yyval.strval).start = malloc(size + 1)) == NULL) { /* extra 1 for '\0' */
	       msg("Can't allocate storage for list\n");
	       break;
	    }

	    for(brace_level = 0,ptr = (yyval.strval).start;!sm_interrupt;ptr++) {
	       *ptr = input();
	       if(*ptr == r_delim) {
		  if(brace_level == 0) {
		     break;
		  } else {
		     brace_level--;
		  }
	       } else if(*ptr == l_delim) {
		  brace_level++;
	       }
	       if(ptr >= (yyval.strval).start + size - 1) {
		  size *= 2;
		  if(((yyval.strval).start = realloc((yyval.strval).start,size + 1)) == NULL) {
		     msg("Can't reallocate storage for do loop\n");
		     goto failed;
		  }
		  ptr = (yyval.strval).start + size/2 - 1;
	       }
	    }
	    (yyval.strval).end = ptr;
	    *((yyval.strval).end) = '\n';
	    *((yyval.strval).end + 1) = '\0';

	    (void)unput(r_delim);
	    save_str("(str_list)");
	    if(sm_verbose > 3) {
	       if(sm_verbose > 4) {
		  msg_1d("%d> (str_list :\n",noexpand);
		  msg_1s("\t%s",(yyval.strval).start);
	       } else {
		  msg_1d("%d> (str_list)\n",noexpand);
	       }
	    }
	    break;
	    failed: ;			/* break out after failed realloc */
	 }
    break;

  case 301:
/* #line 3010 "control.y" */
    {
	    char *ptr,*str;
	    
	    str = (yyvsp[(1) - (1)].charval); str++;		/* strip opening ' */
	    for(ptr = (yyval.charval);*str != '\0';) {
	       if(*str == '\\') {
		  str++;
		  switch (*str) {
		   case '\\': *ptr++ = '\\'; break;
		   case '\'': *ptr++ = '\''; break;
		   case 'n': *ptr++ = '\n'; break;
		   case 'r': *ptr++ = '\r'; break;
		   case 't': *ptr++ = '\t'; break;
		   default:
		     msg_1d("Unknown escape sequence in format: \\%c\n",*str);
		     *ptr++ = *str;
		     break;
		  }
		  if(*str != '\0') str++;
	       } else {
		  *ptr++ = *str++;
	       }
	    }
	    *(ptr - 1) = '\0';		/* strip closing ' */
	 }
    break;

  case 302:
/* #line 3036 "control.y" */
    {
	    VECTOR *temp;
		     
	    if((temp = get_vector_ptr((yyvsp[(3) - (4)].charval))) == NULL) {
	       break;
	    }
	    (yyval.charval)[CHARMAX - 1] = '\0';
	    strncpy((yyval.charval),temp->descrip,CHARMAX - 1);
	 }
    break;

  case 303:
/* #line 3048 "control.y" */
    { (yyval.charval)[0] = '\0'; }
    break;

  case 304:
/* #line 3050 "control.y" */
    { (void)strcpy((yyval.charval),(yyvsp[(1) - (1)].charval)); }
    break;

  case 305:
/* #line 3054 "control.y" */
    {
	    char c;
	    int i;
	    
	    while(c = input(), isspace(c)) continue;
	    (void)unput(c);			/* one too far */

	    for(i = 0;i < CHARMAX - 1;) {
	       if((c = input()) == '_' || isalnum(c)) {
	          variable_name[i++] = c;
	       } else {
		  (void)unput(c);
		  break;
	       }
	    }
	    variable_name[i] = '\0';
	    if(i == 0) {
	       msg("Error: empty variable name\n");
	       YYERROR;
	    }
	    save_str(variable_name);
            if(sm_verbose > 3) {
               msg_1d("%d> WORD     ",noexpand);
               msg_1s("%s\n",variable_name);
	    }
	 }
    break;

  case 306:
/* #line 3083 "control.y" */
    { if(variable_name[0] != '\0') setvar(variable_name,"delete"); }
    break;

  case 307:
/* #line 3085 "control.y" */
    { if(variable_name[0] != '\0') make_local_variable(variable_name); }
    break;

  case 308:
/* #line 3087 "control.y" */
    {
	    if((yyvsp[(1) - (1)].strval).start == NULL) break;
	    *((yyvsp[(1) - (1)].strval).end) = '\0';		/* remove '\n' */
	    if(variable_name[0] != '\0') setvar(variable_name,(yyvsp[(1) - (1)].strval).start);
            free((yyvsp[(1) - (1)].strval).start);
	 }
    break;

  case 309:
/* #line 3094 "control.y" */
    {
	    if((yyvsp[(1) - (6)].strval).start == NULL) break;
	    *((yyvsp[(1) - (6)].strval).end) = '\0';		/* remove '\n' */
	    if(variable_name[0] != '\0') {
	       int slen = strlen((yyvsp[(1) - (6)].strval).start);
	       int i0 = (yyvsp[(3) - (6)].intval), len = (yyvsp[(5) - (6)].intval);
	       if(i0 < 0) { i0 = slen - i0; }
	       if(len <= 0) { len = (slen - i0) + len; }

	       if(i0 < 0 || i0 > len || len < 0 || i0 + len > slen) {
		  msg_1d("Illegal range i0:len == %d:", i0);
		  msg_1d("%d", len);
		  msg_2s(" for define %s <%s>", variable_name, (yyvsp[(1) - (6)].strval).start);
		  msg_1d("[%d, ", (yyvsp[(3) - (6)].intval));
		  msg_1d("%d]\n", (yyvsp[(5) - (6)].intval));
		  
		  free((yyvsp[(1) - (6)].strval).start);
		  break;
	       }

	       memmove((yyvsp[(1) - (6)].strval).start, &(yyvsp[(1) - (6)].strval).start[i0], len);
	       (yyvsp[(1) - (6)].strval).start[len] = '\0';
	       
	       setvar(variable_name,(yyvsp[(1) - (6)].strval).start);
	    }
            free((yyvsp[(1) - (6)].strval).start);
	 }
    break;

  case 310:
/* #line 3122 "control.y" */
    {
	    if(variable_name[0] != '\0') {
	       setvar(variable_name,read_image_variable(variable_name));
	    }
	 }
    break;

  case 311:
/* #line 3128 "control.y" */
    {
	    char *temp;

	    if(variable_name[0] == '\0' ||
			      (temp = read_variable(data_file,(yyvsp[(2) - (2)].intval),0)) == NULL) {
	       break;
	    }
	    setvar(variable_name,temp);
	 }
    break;

  case 312:
/* #line 3138 "control.y" */
    {
	    char *temp;

	    if(variable_name[0] == '\0' ||
			     (temp = read_variable(data_file,(yyvsp[(2) - (3)].intval),(yyvsp[(3) - (3)].intval))) == NULL) {
	       break;
	    }
	    setvar(variable_name,temp);
	 }
    break;

  case 313:
/* #line 3148 "control.y" */
    { if(variable_name[0] != '\0') setvar(variable_name,(yyvsp[(1) - (1)].charval)); }
    break;

  case 314:
/* #line 3150 "control.y" */
    {
	    char *temp;

	    if(variable_name[0] != '\0') {
	       if((temp = get_val(variable_name)) != NULL) {
		  setvar(variable_name,temp);
	       } else {
		  if(sm_verbose > 1)
		     msg_1s("%s is not defined in the environment file\n",
								variable_name);
	       }
	    }
	 }
    break;

  case 315:
/* #line 3164 "control.y" */
    {
	    char *oldval;		/* old value of variable */

	    if(variable_name[0] == '\0' || (yyvsp[(2) - (2)].strval).start == NULL) {
	       if((yyvsp[(2) - (2)].strval).start != NULL) free((yyvsp[(2) - (2)].strval).start);
	       break;
	    }
	    *((yyvsp[(2) - (2)].strval).end) = '\0';		/* remove '\n' */
	    
	    if(graph_mode) { IDLE(); graph_mode = 0; }
	    
	    oldval = print_var(variable_name);
	    for(;;) {
	       if((yyvsp[(2) - (2)].strval).start[0] == '\0') {
		  printf("%s ? [%s] ",variable_name,oldval);
	       } else {			/* use prompt specified */
		  printf("%s [%s] ",(yyvsp[(2) - (2)].strval).start,oldval);
	       }
	       fflush(stdout);
	       (void)fgets(word,CHARMAX,stdin); word[strlen(word) - 1] = '\0';
	       if(logfil != NULL) fprintf(logfil,"%s\n",word);
	       if(word[0] != '\0') {	/* new value */
		  setvar(variable_name,word);
		  break;
	       } else if(oldval[0] == '\0') {
		  printf("There is no default value for %s\n",variable_name);
		  fflush(stdout);
	       } else {			/* keep old value */
		  break;
	       }
	    }
	    free((yyvsp[(2) - (2)].strval).start);
	    if(in_graphics) { ENABLE(); graph_mode = 1; }
	 }
    break;

  case 316:
/* #line 3199 "control.y" */
    {
	    int i;
	    
	    if(variable_name[0] != '\0') {
	       if((i = index_variable(variable_name)) < 0) {
		  msg_1s("%s is not a valid internal variable\n",variable_name);
		  break;
	       }
	       setvar(variable_name,get_variable(i));
	    }
	 }
    break;

  case 317:
/* #line 3211 "control.y" */
    {
	    if(variable_name[0] != '\0') {
	       if((yyvsp[(2) - (3)].vector).dimen <= 0 || (yyvsp[(2) - (3)].vector).type == VEC_NULL) {
		  msg_1s("vector %s has no value\n",(yyvsp[(2) - (3)].vector).name);
		  break;
	       }
	       if((yyvsp[(2) - (3)].vector).type == VEC_FLOAT) {
		  (void)sprintf(buff,"%.10g",(yyvsp[(2) - (3)].vector).vec.f[0]);
		  setvar(variable_name,buff);
	       } else if((yyvsp[(2) - (3)].vector).type == VEC_LONG) {
		  char *dl[] = { "", "%d", "%ld" };	/* do we need a %l format? */
		  assert(sizeof(LONG)/4 < 3);
		  (void)sprintf(buff,dl[sizeof(LONG)/4],(yyvsp[(2) - (3)].vector).vec.l[0]);
		  setvar(variable_name,buff);
	       } else if((yyvsp[(2) - (3)].vector).type == VEC_STRING) {
		  setvar(variable_name,(yyvsp[(2) - (3)].vector).vec.s.s[0]);
	       } else {
		  msg_1s("vector %s has unknown type",(yyvsp[(2) - (3)].vector).name);
		  msg_1d("%d\n",(yyvsp[(2) - (3)].vector).type);
	       }
	       vec_free(&(yyvsp[(2) - (3)].vector));
	    }
	 }
    break;

  case 318:
/* #line 3237 "control.y" */
    { (yyval.charval)[0] = '\0'; }
    break;

  case 319:
/* #line 3239 "control.y" */
    { (void)strcpy((yyval.charval),(yyvsp[(1) - (1)].charval)); }
    break;

  case 320:
/* #line 3243 "control.y" */
    { (yyval.charval)[0] = '\0'; }
    break;

  case 321:
/* #line 3245 "control.y" */
    { sprintf((yyval.charval), "%d", (yyvsp[(1) - (1)].intval)); }
    break;

  case 322:
/* #line 3247 "control.y" */
    { (void)strcpy((yyval.charval),(yyvsp[(1) - (1)].charval)); }
    break;


/* Line 1267 of yacc.c.  */
/* #line 6836 "y.tab.c" */
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


/* #line 3250 "control.y" */
					/* start of programmes */

void
yyerror(s)
char s[];
{
   char *cmacro,			/* which macro are we in? */
	*lline;				/* pointer to last line */
   int i,
       offset;				/* offset of last token in line */

   if(strcmp(s,"syntax error") != 0 &&			/* Yacc message */
		 	strcmp(s,"parse error") != 0 &&	/* Bison message */
		 	strcmp(s,"misc error") != 0 &&	/* our message */
		 	strcmp(s,"show where") != 0) {	/* display command */
      msg_1s("%s in control.y\n",s);
   } else {				/* Syntax Error */
      if(graph_mode) { IDLE(); graph_mode = 0; }
      lline = get_line(&offset);
      if(!strcmp(s,"misc error")) {	/* a private (not yacc) message */
	 fprintf(stderr,"Error at \"%s\"",&lline[offset]);
      } else if(!strcmp(s,"show where")) { /* just print current command */
	 if(!sm_verbose) {
	    fprintf(stderr,"\n");
	    return;
	 }
	 fprintf(stderr," at \"%s\"",&lline[offset]);
      } else if(strcmp(lline,"<user abort>") == 0) { /* a deliberate error */
	 if(*print_var("traceback") != '\0') {
	    dump_stack();
	 }
	 return;
      } else {
	 fprintf(stderr,"Syntax error at \"%s\"",&lline[offset]);
      }
      if((cmacro = current_macro()) == NULL) {
	 fprintf(stderr,"\n");
      } else {
	 fprintf(stderr," in macro %s\n",cmacro);
      }
      fprintf(stderr,"%s\n",lline);
      for(i = 0;i < offset;i++) (void)putc(' ',stderr);
      while(lline[i++] != '\0') (void)putc('^',stderr);
      (void)putc('\n',stderr);
      if(*print_var("traceback") != '\0') {
 	 dump_stack();
      }
      if(in_graphics) { ENABLE(); graph_mode = 1; }
   }
}

/*****************************************************************************/
/*
 * enable/disable graphics, setting graph_mode and in_graphics correctly
 *
 * Judicious use of these functions can significantly reduce mode switching
 */
void
sm_enable()
{
   if(!graph_mode) {
      graph_mode = 1;
      in_graphics = 1;
      ENABLE();
   }
}

void
sm_disable()
{
   if(graph_mode) {
      graph_mode = 0;
      in_graphics = 0;
      IDLE();
   }
}

/****************************************************/
/*
 * Print a string on stdout, after dealing with graph mode
 */
void
msg(fmt)
Const char *fmt;			/* message to print */
{
   if(graph_mode) { IDLE(); graph_mode = 0; }
   puts(fmt); fflush(stdout);
   if(in_graphics) { ENABLE(); graph_mode = 1; }
}

/*
 * Print a string on stdout, with one string argument
 */
void
msg_1s(fmt,s)
Const char *fmt,			/* message to print */
     *s;
{
   if(graph_mode) { IDLE(); graph_mode = 0; }
   printf(fmt,s); fflush(stdout);
   if(in_graphics) { ENABLE(); graph_mode = 1; }
}


/*
 * Print a string on stdout, with two string arguments
 */
void
msg_2s(fmt,s1,s2)
Const char *fmt,			/* message to print */
     *s1,*s2;
{
   if(graph_mode) { IDLE(); graph_mode = 0; }
   printf(fmt,s1,s2); fflush(stdout);
   if(in_graphics) { ENABLE(); graph_mode = 1; }
}

/*
 * Print a string on stdout, with one int argument
 */
void
msg_1d(fmt,i)
Const char *fmt;			/* message to print */
int i;
{
   if(graph_mode) { IDLE(); graph_mode = 0; }
   printf(fmt,i); fflush(stdout);
   if(in_graphics) { ENABLE(); graph_mode = 1; }
}

/*
 * Print a string on stdout, with one float argument
 */
void
msg_1f(fmt,x)
Const char *fmt;			/* message to print */
double x;
{
   if(graph_mode) { IDLE(); graph_mode = 0; }
   printf(fmt,x); fflush(stdout);
   if(in_graphics) { ENABLE(); graph_mode = 1; }
}

/*
 * Parse a qualifer: e.g. `2.s' -> VEC_STRING
 */
int
parse_qualifier(str)
char *str;
{
   char *ptr;
   
   if((ptr = strrchr(str,'.')) == NULL) {
      for(ptr = str; isdigit(*ptr); ptr++) continue;
      
      if(*ptr == '\0') {
	 return(VEC_FLOAT);
      } else if(*ptr == '-') {
	 if(parse_qualifier(ptr + 1) == VEC_FLOAT) {
	    return(VEC_FLOAT);
	 }
      }
   } else {
      switch (*(ptr + 1)) {
       case 'd': case 'i': case 'o': case 'x':
	 return(VEC_LONG);
       case 'f': case 'g':
	 return(VEC_FLOAT);
       case 's':
	 return(VEC_STRING);
       default:
	 break;
      }
   }

   msg_1s("unknown type specification for vector: %s\n",str);
   return(VEC_FLOAT);
}

