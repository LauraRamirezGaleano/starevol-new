/*
 * Copyright (C) 1987 -- 2006 Robert Lupton and Patricia Monger
 * 
 * This programme is not public domain, except where specifically stated to the
 * contrary, either in the code, the file "COPYING", or in the manual. If you
 * have a legally acquired copy you may use it on any computer "on the same
 * site", but you may NOT give it away or sell it.  Note that the COPYING
 * document does state that the SM libraries are covered by a variation of the
 * GNU GPL
 * 
 * There is no warranty for this code, and we accept no responsibility.
 * If you find any bugs, or wish to suggest any enhancements, please send
 * mail to one of the authors (monger@mcmaster.ca or rhl@astro.princeton.edu).
 */
