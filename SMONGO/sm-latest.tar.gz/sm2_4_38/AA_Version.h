/*
 * This file is used to keep tabs on patching, and is included in src/main.c
 * It must be in this directory for patch's "Prereq:" to work properly
 *
 * Makers of patch files should ensure that the patch level is updated
 */
static char version_name[] = "$Name: sm2_4_38 $";
static char version_date[] = "$Date: 2009/09/08 23:02:36 $";
