The incorporation of this package in the stellar evolution code
should be relatively easy.

First, the data files (G* files) contain BOTH CONDUCTIVE (Hubbard et al)
and RADIATIVE (from OPAL)  opacities. 

To get the opacity at a given shell k, use the kappa.f routine and 
   call kappa(kap,kapr,kapt,kapx,kapy,error)

the outputs are :
    kap = kappa
    kapr = d kappa/dro
    kapt = d kappa/dT
    kapx = d kappa/dX  (X = H mass fraction)
    kapy = d kappa/dY  (Y = He mass fraction)
(kapx1 and kapy1 may be required in case of diffusion)

error is a variable that tells us where the crash occurred
so we can find the best way to overcome the problem

You also need to transmit (through common block in our case)
- zkint which represents the metallicity of the ZAMS model. This value
must be kept constant throughout the entire evolution 
- the chemical composition of the shell (vector x = mass fraction)
- the temperature of the shell : tk
- the density of the shell : rok

You must also keep the common :
      common /extopac/ opact,dopact,dopacr,dopactd,ftredge

For this package to work, you will need to link with 
 - livopaint.f (a subroutine provided by OPAL that interpolate and smooths
 the opacity and its derivatives) and 
 - lthopa.f (block data for low temperature opacity from Fergusson 2005). 
 - interlin.f (linear interpolation routine). 


Finally, in your main program, you must tell the interpolation routine
(livopaint) where the data files  (the G* files) are :

      call set_opal_dir( '/home/siess/EVOL/OPACITY/LIB' )


and this is it ... well hopefully

don't hesitate to contact me in case of pb

cheers
lionel
